global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global B0 K0 
global xiAH xiBH xiAN xiBN barzH barzN gzH gzN gz gzH0 gzN0 aAH aBH aAN aBN

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

DEU_CD; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% BENCH IML KAC TOT- epsilon = 0.75, sigmaL=0.4, kH>kN    %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigmaH_0     = 0.642;
sigmaN_0     = 0.987;
gammaH_0     = sLH_DEU_0CD*( sLH_DEU_0CD + (1-sLH_DEU_0CD)*(kH_DEU_0CD^((1-sigmaH_0)/sigmaH_0)) )^(-1);
gammaN_0     = sLN_DEU_0CD*( sLN_DEU_0CD + (1-sLN_DEU_0CD)*(kN_DEU_0CD^((1-sigmaN_0)/sigmaN_0)) )^(-1);
ZH_0         = (YH_DEU_0CD/LH_DEU_0CD)*( gammaH_0 + (1-gammaH_0)*(kH_DEU_0CD^((sigmaH_0 - 1)/sigmaH_0)) )^(sigmaH_0/(1-sigmaH_0));
ZN_0         = (YN_DEU_0CD/LN_DEU_0CD)*( gammaN_0 + (1-gammaN_0)*(kN_DEU_0CD^((sigmaN_0 - 1)/sigmaN_0)) )^(sigmaN_0/(1-sigmaN_0));
AH_0         = ZH_0;
AN_0         = ZN_0;
BH_0         = ZH_0;
BN_0         = ZN_0;

omegaG       = 0.192;
omegaGN      = 0.911;
omegaGH      = 1;
sigmaL_0     = 1.6;
gammaL       = 1;
sigmaC_0     = 2;
phi_0        = 0.577;
varphi_0     = alphaC_DEU_0CD*( alphaC_DEU_0CD + (1-alphaC_DEU_0CD)*((PN_DEU_0CD/PT_DEU_0CD)^(phi_0 -1)) )^(-1);  %0.52; %0.535;
rho_0        = 0.67;
varphiH_0    = alphaH_DEU_0CD*( alphaH_DEU_0CD + (1-alphaH_DEU_0CD)*((PH_DEU_0CD)^(1-rho_0)) )^(-1); %0.858; %0.84;
epsilon_0    = 1.012;
vartheta_0   = (1-alphaL_DEU_0CD)*( alphaL_DEU_0CD*((WH_DEU_0CD/WN_DEU_0CD)^(1+epsilon_0)) + (1-alphaL_DEU_0CD) )^(-1); % 0.4;
phiI_0       = 1.00000000001;
iota_0       = 0.354;
rhoI_0       = 1.57;
iotaH_0      = alphaIH_DEU_0CD*( alphaIH_DEU_0CD + (1-alphaIH_DEU_0CD)*((PH_DEU_0CD)^(1-rhoI_0)) )^(-1); %0.584; %0.55;
kappa        = 17;
nuX          = 1.473;
ex           = omegaXHY_DEU_0CD*Y_DEU_0CD*(PH_DEU_0CD)^(nuX-1);

r            = 0.04;
beta         = r;
deltaK       = (omegaI_DEU_0CD/PI_DEU_0CD)*(Y_DEU_0CD/K_DEU_0CD);

B0           = Y_DEU_0CD*(omegaC_DEU_0CD+omegaI_DEU_0CD+omegaG-1)/r; %2.0;
K0           = K_DEU_0CD + ((B0 - B_DEU_0CD)/H1_DEU_0CD);  

ZH           = ZH_0;       
ZN           = ZN_0; 
AH           = AH_0;       
AN           = AN_0;  
BH           = BH_0;       
BN           = BN_0;
gammaH       = gammaH_0;   
gammaN       = gammaN_0;  
sigmaH       = sigmaH_0;   
sigmaN       = sigmaN_0;    
sigmaC       = sigmaC_0;  
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0;                            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.024   ; % Consumption 
L_ini        = 1.035   ; % Labor supply 
kH_ini       = 5.084   ; % Capital-labor ratio in sector H
WH_ini       = 1.725   ; % Wage rate in sector H
WN_ini       = 1.568   ; % Wage rate in sector N
W_ini        = 1.616   ; % Aggregate wage index
kN_ini       = 2.971   ; % Capital-labor ratio in sector N
PN_ini       = 2.262   ; % Relative price of non tradables
K_ini        = 3.785   ; % Stock of capital
PH_ini       = 1.5     ; % Terms of trade
B_ini        = 0.0001  ; % Stock of traded Bonds
alphaL_ini   = 0.664   ; % Non tradable share of compensation of employees
PC_ini       = 1.186   ; % Aggregate consumption price index
PT_ini       = 1.186   ; % Consumption price index for tradables
CN_ini       = 0.299   ; % Consumption in non tradables 
CH_ini       = 0.589   ; % Consumption in tradables 
CF_ini       = 0.4     ; % Consumption in foreign goods 
alphaC_ini   = 0.430   ; % Tradable content of consumption expenditure
alphaH_ini   = 0.5     ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 1.486   ; % Aggregate investment price index
PIT_ini      = 1.000   ; % Investment price index for traded goods
IN_ini       = 0.235   ; % Non traded investment
IH_ini       = 0.2     ; % Home goods investment
IF_ini       = 0.2     ; % Foreign goods investment
alphaI_ini   = 0.430   ; % Tradable content of investment expenditure
alphaIH_ini  = 0.5     ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.322   ; % Labor in sector H
LN_ini       = 0.712   ; % Labor in sector N 
GF_ini       = 0.03    ; % Government spending in foreign goods
GH_ini       = 0.03    ; % Government spending in home goods
GN_ini       = 0.21    ; % Government spending in non tradables 
yH_ini       = 2       ; % Output of home traded goods per worker
YH_ini       = 2       ; % Output of home traded goods
yN_ini       = 1       ; % Output of non traded goods per worker
YN_ini       = 1       ; % Output of non traded goods
XH_ini       = 0.5     ; % Exports of home traded goods
MF_ini       = 0.5     ; % Imports of foreign goods
LH_WH_ini    = 0.195   ; % Partial derivative of LH=LH(lambda,WH,WN) 
LH_WN_ini    = -0.060  ; % Partial derivative of LH=LH(lambda,WH,WN) 
LN_WH_ini    = -0.060  ; % Partial derivative of LN=LN(lambda,WH,WN) 
LN_WN_ini    = 0.393   ; % Partial derivative of LN=LN(lambda,WH,WN) 
lambda_ini   = 0.967    ; % Intertemporal Solvency Condition          
                                                          
x0 =[C_ini L_ini kH_ini WH_ini WN_ini W_ini kN_ini PN_ini K_ini PH_ini B_ini alphaL_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini GF_ini GN_ini GH_ini yH_ini YH_ini yN_ini YN_ini XH_ini MF_ini LH_WH_ini LH_WN_ini LN_WH_ini LN_WN_ini lambda_ini];
[x,fval,exitflag]=fsolve('TECH_IML_CAC_TOT_CES_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
alphaC  = x(18) ; % Tradable content of consumption expenditure 
alphaH  = x(19) ; % Home goods content of consumption expenditure 
PI      = x(20) ; % Aggregate investment price index
PIT     = x(21) ; % Investment price index for tradables
IN      = x(22) ; % Non tradable investment
IH      = x(23) ; % Investment in home goods
IF      = x(24) ; % Investment in foreign goods
alphaI  = x(25) ; % Tradable content of investment expenditure
alphaIH = x(26) ; % Home goods content of investment expenditure
LH      = x(27) ; % Labor in sector H
LN      = x(28) ; % Labor in sector N 
GF      = x(29) ; % Government spending in foreign goods
GN      = x(30) ; % Government spending in non tradables 
GH      = x(31) ; % Government spending in home traded goods
yH      = x(32) ; % Output of home traded goods per worker
YH      = x(33) ; % Output of home traded goods
yN      = x(34) ; % Output of non traded goods per worker
YN      = x(35) ; % Output of non traded goods
XH      = x(36) ; % Exports of home traded goods
MF      = x(37) ; % Imports of foreign goods
LH_WH   = x(38) ; % Partial derivative of LH=LH(lambda,WH,WN)
LH_WN   = x(39) ; % Partial derivative of LH=LH(lambda,WH,WN)
LN_WH   = x(40) ; % Partial derivative of LN=LN(lambda,WH,WN)
LN_WN   = x(41) ; % Partial derivative of LN=LN(lambda,WH,WN) 
lambda  = x(42) ; % Intertemporal Solvency Condition   

% Sectoral outputs and sectoral profits   
KH  = LH*kH;  
RK  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Labor income share in the home traded good and non traded good sector
sLH = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 

% Partial derivatives of LH and LN
LH_1lamb   = sigmaL*LH/lambda; 
LN_1lamb   = sigmaL*LN/lambda;

% Solutions for kj = kj(PN,PH,KZH,ZN,lambda), Lj=Lj(PN,PH,KZH,ZN,lambda)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_lamb = ( (kH*LH_1lamb) + (kN*LN_1lamb) ); 

d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d13 = 0;
d14 = 0;
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = (1/sigmaN)*((1-sLN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

e11 = (1/PN); 
e12 = -(1/PH);
e13 = 0;
e14 = -(1/sigmaH)*(sLH/AH); 
e15 = -(1/sigmaH)*((sigmaH-sLH)/BH);
e16 = (1/sigmaN)*(sLN/AN); 
e17 = (1/sigmaN)*((sigmaN-sLN)/BN);
e18 = 0; 
e21 = 0; 
e22 = -(1/PH); 
e23 = 0;
e24 = -(1/sigmaH)*(((sigmaH-1)+sLH)/AH); 
e25 = -(1/sigmaH)*((1-sLH)/BH); 
e26 = 0;
e27 = 0; 
e28 = 0;
e31 = -(1/PN); 
e32 = 0; 
e33 = 0;
e34 = 0; 
e35 = 0; 
e36 = -(1/sigmaN)*(((sigmaN-1)+sLN)/AN); 
e37 = -(1/sigmaN)*((1-sLN)/BN); 
e38 = 0; 
e41 = 0; 
e42 = 0; 
e43 = 1; 
e44 = 0; 
e45 = 0;
e46 = 0;
e47 = 0; 
e48 = -Psi_lamb;
    
M = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X = [e11 e12 e13 e14 e15 e16 e17 e18; e21 e22 e23 e24 e25 e26 e27 e28; e31 e32 e33 e34 e35 e36 e37 e38; e41 e42 e43 e44 e45 e46 e47 e48];
JST = inv(M);
MST = JST*X;
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1K = MST(1,3); kH_1AH = MST(1,4); kH_1BH = MST(1,5); kH_1AN = MST(1,6); kH_1BN = MST(1,7); kH_1lambda = MST(1,8);
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1K = MST(2,3); kN_1AH = MST(2,4); kN_1BH = MST(2,5); kN_1AN = MST(2,6); kN_1BN = MST(2,7); kN_1lambda = MST(2,8);
WH_PN = MST(3,1); WH_PH = MST(3,2); WH_1K = MST(3,3); WH_1AH = MST(3,4); WH_1BH = MST(3,5); WH_1AN = MST(3,6); WH_1BN = MST(3,7); WH_1lambda = MST(3,8);
WN_PN = MST(4,1); WN_PH = MST(4,2); WN_1K = MST(4,3); WN_1AH = MST(4,4); WN_1BH = MST(4,5); WN_1AN = MST(4,6); WN_1BN = MST(4,7); WN_1lambda = MST(4,8);  

% Intermediate solutions for sectoral labor and sectoral output - Yj=Yj(PN,PH,K,AH,BH,AN,BN)
LH_PN = (LH_WH*WH_PN) + (LH_WN*WN_PN); 
LN_PN = (LN_WH*WH_PN) + (LN_WN*WN_PN); 
LH_PH = (LH_WH*WH_PH) + (LH_WN*WN_PH); 
LN_PH = (LN_WH*WH_PH) + (LN_WN*WN_PH);
LH_1K = (LH_WH*WH_1K) + (LH_WN*WN_1K); 
LN_1K = (LN_WH*WH_1K) + (LN_WN*WN_1K);

LH_1AH     = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LN_1AH     = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LH_1BH     = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LN_1BH     = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LH_1AN     = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LN_1AN     = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LH_1BN     = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);
LN_1BN     = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);
LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);

yH_PN  = (yH/kH)*(1-sLH)*kH_PN;   
yN_PN  = (yN/kN)*(1-sLN)*kN_PN;
yH_PH  = (yH/kH)*(1-sLH)*kH_PH;   
yN_PH  = (yN/kN)*(1-sLN)*kN_PH;   
yH_1K  = (yH/kH)*(1-sLH)*kH_1K;   
yN_1K  = (yN/kN)*(1-sLN)*kN_1K; 
yH_1AH = (yH/AH)*sLH + (yH/kH)*(1-sLH)*kH_1AH;   
yN_1AH = (yN/kN)*(1-sLN)*kN_1AH;
yH_1BH =  yH*(1-sLH)*( (1/BH) + (kH_1BH/kH) );   
yN_1BH = (yN/kN)*(1-sLN)*kN_1BH;
yH_1AN =  (yH/kH)*(1-sLH)*kH_1AN;   
yN_1AN = (yN/AN)*sLN + (yN/kN)*(1-sLN)*kN_1AN;
yH_1BN =  (yH/kH)*(1-sLH)*kH_1BN;   
yN_1BN =  yN*(1-sLN)*( (1/BN) + (kN_1BN/kN) ); 
yH_1lambda  = (yH/kH)*(1-sLH)*kH_1lambda;   
yN_1lambda  = (yN/kN)*(1-sLN)*kN_1lambda; 

YH_PN = (LH*yH_PN) + (yH*LH_PN);
YN_PN = (LN*yN_PN) + (yN*LN_PN);
YH_PH = (LH*yH_PH) + (yH*LH_PH);
YN_PH = (LN*yN_PH) + (yN*LN_PH);
YH_1K = (LH*yH_1K) + (yH*LH_1K);
YN_1K = (LN*yN_1K) + (yN*LN_1K); 

YH_1AH = (LH*yH_1AH) + (yH*LH_1AH);
YN_1AH = (LN*yN_1AH) + (yN*LN_1AH);
YH_1BH = (LH*yH_1BH) + (yH*LH_1BH);
YN_1BH = (LN*yN_1BH) + (yN*LN_1BH);
YH_1AN = (LH*yH_1AN) + (yH*LH_1AN);
YN_1AN = (LN*yN_1AN) + (yN*LN_1AN);
YH_1BN = (LH*yH_1BN) + (yH*LH_1BN);
YN_1BN = (LN*yN_1BN) + (yN*LN_1BN);
YH_1lambda = (LH*yH_1lambda) + (yH*LH_1lambda);
YN_1lambda = (LN*yN_1lambda) + (yN*LN_1lambda);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

CH_1lambda = -(CH/lambda)*sigmaC; 
CN_1lambda = -(CN/lambda)*sigmaC;
CF_1lambda = -(CF/lambda)*sigmaC;

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,AH,BH,AN,BN,PN) -
% Intermediate Solution
PsiH_PH    = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN    = (YH_PN - CH_PN - JH_PN);
PH_PN      = -PsiH_PN/PsiH_PH; 
PH_1K      = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q      = JH_1Q/PsiH_PH; 
PH_1AH     = -YH_1AH/PsiH_PH; 
PH_1BH     = -YH_1BH/PsiH_PH;
PH_1AN     = -YH_1AN/PsiH_PH; 
PH_1BN     = -YH_1BN/PsiH_PH; 
PH_1lambda = -(YH_1lambda - CH_1lambda)/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,AH,BH,AN,BN)
PsiN_PH   = (YN_PH - CN_PH - JN_PH); 
PsiN_PN   = ((YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN));
PN_K      = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q      =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 
PN_AH     = -( YN_1AH + (PsiN_PH*PH_1AH) )/PsiN_PN; 
PN_BH     = -( YN_1BH + (PsiN_PH*PH_1BH) )/PsiN_PN; 
PN_AN     = -( YN_1AN + (PsiN_PH*PH_1AN) )/PsiN_PN;
PN_BN     = -( YN_1BN + (PsiN_PH*PH_1BN) )/PsiN_PN;
PN_lambda = -( YN_1lambda + (PsiN_PH*PH_1lambda) )/PsiN_PN;

% Solving for the price of home goods PH=PH(lambda,K,Q,AH,BH,AN,BN) - Final
% Solution
PH_K      = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q      = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 
PH_AH     = -( YH_1AH + (PsiH_PN*PN_AH) )/PsiH_PH; 
PH_BH     = -( YH_1BH + (PsiH_PN*PN_BH) )/PsiH_PH;
PH_AN     = -( YH_1AN + (PsiH_PN*PN_AN) )/PsiH_PH; 
PH_BN     = -( YH_1BN + (PsiH_PN*PN_BN) )/PsiH_PH; 
PH_lambda = -( (YH_1lambda-CH_1lambda) + (PsiH_PN*PN_lambda) )/PsiH_PH; 

% Solving for capital-labor ratios kj=kj(lambda,K,Q,AH,BH,AN,BN) - 
% sectoral labor Lj=Lj(lambda,K,Q,AH,BH,AN,BN) - sectoral output 
% Yj=Yj(lambda,K,Q,AH,BH,AN,BN) - Final Solutions
kH_K = kH_1K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = kN_1K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

kH_AH = kH_1AH + (kH_PH*PH_AH) + (kH_PN*PN_AH);
kH_BH = kH_1BH + (kH_PH*PH_BH) + (kH_PN*PN_BH);
kH_AN = kH_1AN + (kH_PH*PH_AN) + (kH_PN*PN_AN);
kH_BN = kH_1BN + (kH_PH*PH_BN) + (kH_PN*PN_BN);
kN_AH = kN_1AH + (kN_PH*PH_AH) + (kN_PN*PN_AH);
kN_BH = kN_1BH + (kN_PH*PH_BH) + (kN_PN*PN_BH);
kN_AN = kN_1AN + (kN_PH*PH_AN) + (kN_PN*PN_AN); 
kN_BN = kN_1BN + (kN_PH*PH_BN) + (kN_PN*PN_BN);

kH_lambda = kH_1lambda + (kH_PH*PH_lambda) + (kH_PN*PN_lambda);  
kN_lambda = kN_1lambda + (kN_PH*PH_lambda) + (kN_PN*PN_lambda);  

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

LH_AH = LH_1AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_1BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_1AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_1BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);
LN_AH = LN_1AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_1BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_1AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_1BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);

LH_lambda = LH_1lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda);   
LN_lambda = LN_1lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda);   

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

YH_AH = YH_1AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_1BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_1AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_1BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YN_AH = YN_1AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_1BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_1AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_1BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);

YH_lambda = YH_1lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);  
YN_lambda = YN_1lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda);  

% Solving for consumption Cj=Cj(lambda,K,Q,AH,BH,AN,BN), investment inputs 
% Jj=Jj(K,Q,AH,BH,AN,BN), imports MF=MF(lambda,K,Q,AH,BH,AN,BN), exports 
%XH=XH(lambda,K,Q,AH,BH,AN,BN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CH_AH     = (CH_PH*PH_AH) + (CH_PN*PN_AH);
CH_BH     = (CH_PH*PH_BH) + (CH_PN*PN_BH);
CH_AN     = (CH_PH*PH_AN) + (CH_PN*PN_AN);
CH_BN     = (CH_PH*PH_BN) + (CH_PN*PN_BN);
CH_lambda = CH_1lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda); 

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CN_AH     = (CN_PH*PH_AH) + (CN_PN*PN_AH);
CN_BH     = (CN_PH*PH_BH) + (CN_PN*PN_BH);
CN_AN     = (CN_PH*PH_AN) + (CN_PN*PN_AN);   
CN_BN     = (CN_PH*PH_BN) + (CN_PN*PN_BN); 
CN_lambda = CN_1lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);  

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q); 
CF_AH     = (CF_PH*PH_AH) + (CF_PN*PN_AH);
CF_BH     = (CF_PH*PH_BH) + (CF_PN*PN_BH);
CF_AN     = (CF_PH*PH_AN) + (CF_PN*PN_AN); 
CF_BN     = (CF_PH*PH_BN) + (CF_PN*PN_BN);
CF_lambda = CF_1lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);  

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda); 

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN); 
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);  

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN);
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda); 

XH_K      = XH_PH*PH_K; 
XH_Q      = XH_PH*PH_Q; 
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K); 
MF_Q      = (CF_Q + JF_Q); 
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);
MF_lambda = (CF_lambda + JF_lambda); 

% Solving for sectoral wages - Wj=Wj(lambda,K,Q,AH,BH,AN,BN)
WH_K      = WH_1K + (WH_PH*PH_K) + (WH_PN*PN_K); 
WH_Q      = (WH_PH*PH_Q) + (WH_PN*PN_Q); 
WH_AH     = WH_1AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);
WH_BH     = WH_1BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);
WH_AN     = WH_1AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);
WH_BN     = WH_1BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);
WH_lambda = WH_1lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);

WN_K      = WN_1K + (WN_PH*PH_K) + (WN_PN*PN_K);                 
WN_Q      = (WN_PH*PH_Q) + (WN_PN*PN_Q);                         
WN_AH     = WN_1AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);   
WN_BH     = WN_1BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);
WN_AN     = WN_1AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);  
WN_BN     = WN_1BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);
WN_lambda = WN_1lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda); 

% Solution for W as function W=W(lambda,K,Q,AH,BH,AN,BN) 
W_WH      = (W/WH)*(1-alphaL); 
W_WN      = (W/WN)*alphaL; 
W_K       = (W_WH*WH_K) + (W_WN*WN_K); 
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);
W_AH      = (W_WH*WH_AH) + (W_WN*WN_AH); 
W_BH      = (W_WH*WH_BH) + (W_WN*WN_BH);
W_AN      = (W_WH*WH_AN) + (W_WN*WN_AN);
W_BN      = (W_WH*WH_BN) + (W_WN*WN_BN);
W_lambda  = (W_WH*WH_lambda) + (W_WN*WN_lambda);
 
% Solution for L as function L=L(lambda,K,Q,AH,BH,AN,BN)
L_1lambda = sigmaL*(L/lambda);
L_W  = sigmaL*(L/W); 
L_WH = sigmaL*L*(1-alphaL)/WH; 
L_WN = sigmaL*L*alphaL/WN; 
L_K  = (L_WH*WH_K) + (L_WN*WN_K); 
L_Q  = (L_WH*WH_Q) + (L_WN*WN_Q);
L_AH = (L_WH*WH_AH) + (L_WN*WN_AH); 
L_BH = (L_WH*WH_BH) + (L_WN*WN_BH);
L_AN = (L_WH*WH_AN) + (L_WN*WN_AN);
L_BN = (L_WH*WH_BN) + (L_WN*WN_BN);
L_lambda  = L_1lambda + (L_WH*WH_lambda) + (L_WN*WN_lambda);

% Solution for C as function C=C(lambda,K,Q,AH,BH,AN,BN) 
C_1lambda  = -sigmaC*(C/lambda); 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_AH       = (C_PH*PH_AH) + (C_PN*PN_AH);
C_BH       = (C_PH*PH_BH) + (C_PN*PN_BH);
C_AN       = (C_PH*PH_AN) + (C_PN*PN_AN);
C_BN       = (C_PH*PH_BN) + (C_PN*PN_BN);
C_lambda   = C_1lambda + (C_PH*PH_lambda) + (C_PN*PN_lambda);

% Solution for PC=PC(PH,PN) - PC = PC(lambda,K,Q,ZH,ZF)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_AH      = (PC/PH)*alphaC*alphaH*PH_AH + (PC/PN)*(1-alphaC)*PN_AH;
PC_BH      = (PC/PH)*alphaC*alphaH*PH_BH + (PC/PN)*(1-alphaC)*PN_BH;
PC_AN      = (PC/PH)*alphaC*alphaH*PH_AN + (PC/PN)*(1-alphaC)*PN_AN;
PC_BN      = (PC/PH)*alphaC*alphaH*PH_BN + (PC/PN)*(1-alphaC)*PN_BN;
PC_lambda  = (PC/PH)*alphaC*alphaH*PH_lambda + (PC/PN)*(1-alphaC)*PN_lambda;

% Solution for PI=PI(PH,PN) - PI = PI(lambda,K,Q,ZH,ZF)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_AH      = (PI/PH)*alphaI*alphaIH*PH_AH + (PI/PN)*(1-alphaI)*PN_AH;
PI_BH      = (PI/PH)*alphaI*alphaIH*PH_BH + (PI/PN)*(1-alphaI)*PN_BH;
PI_AN      = (PI/PH)*alphaI*alphaIH*PH_AN + (PI/PN)*(1-alphaI)*PN_AN;
PI_BN      = (PI/PH)*alphaI*alphaIH*PH_BN + (PI/PN)*(1-alphaI)*PN_BN;
PI_lambda  = (PI/PH)*alphaI*alphaIH*PH_lambda + (PI/PN)*(1-alphaI)*PN_lambda;

% Solution for G=G(PH,PN) - G= G(lambda,K,Q,ZH,ZF)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_AH       = (PH_AH*GH) + (PN_AH*GN);
G_BH       = (PH_BH*GH) + (PN_BH*GN);
G_AN       = (PH_AN*GH) + (PN_AN*GN);
G_BN       = (PH_BN*GH) + (PN_BN*GN);
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Capital rental rates
RKH = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
RKN = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN));

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(lambda,K,Q,ZH,ZF); 
P    = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_AH = (P/PN)*PN_AH - (P/PH)*PH_AH;
P_BH = (P/PN)*PN_BH - (P/PH)*PH_BH;
P_AN = (P/PN)*PN_AN - (P/PH)*PH_AN;
P_BN = (P/PN)*PN_BN - (P/PH)*PH_BN;

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,AH,BH,AN,BN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_AH      = (PH_AH*YH) + (PH*YH_AH) + (PN_AH*YN) + (PN*YN_AH);
Y_BH      = (PH_BH*YH) + (PH*YH_BH) + (PN_BH*YN) + (PN*YN_BH);
Y_AN      = (PH_AN*YH) + (PH*YH_AN) + (PN_AN*YN) + (PN*YN_AN);
Y_BN      = (PH_BN*YH) + (PH*YH_BN) + (PN_BN*YN) + (PN*YN_BN);
Y_lambda  = (PH_lambda*YH) + (PH*YH_lambda) + (PN_lambda*YN) + (PN*YN_lambda);

% Marginal revenue of capital R = PN*partial YN/partial KN
RK   = PI*(r+deltaK); 
R_K  = (RK/PN)*PN_K - (RK/kN)*(sLN/sigmaN)*kN_K; 
R_Q  = (RK/PN)*PN_Q - (RK/kN)*(sLN/sigmaN)*kN_Q;  
R_AH = (RK/PN)*PN_AH - (RK/kN)*(sLN/sigmaN)*kN_AH;  
R_BH = (RK/PN)*PN_BH - (RK/kN)*(sLN/sigmaN)*kN_BH;
R_AN = (RK/AN)*(sLN/sigmaN) + (RK/PN)*PN_AN - (RK/kN)*(sLN/sigmaN)*kN_AN;
R_BN = (RK/BN)*((sigmaN-sLN)/sigmaN) + (RK/PN)*PN_BN - (RK/kN)*(sLN/sigmaN)*kN_BN;
R_lambda = (RK/PN)*PN_lambda - (RK/kN)*(sLN/sigmaN)*kN_lambda; 

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(lambda,K,Q,AH,BH,AN,BN) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/G; 
omegaGF = GF/G; 

% TFP
ZH = ((AH)^(sLH))*((BH)^(1-sLH)); 
ZN = ((AN)^(sLN))*((BN)^(1-sLN)); 
a  = (1/((1-alphaI) + alphaI*(sLH/sLN))); 
b  = a*(sLH/sLN); 
Z  = (ZH^a)/(ZN^b); 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = G/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RK;                               
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RK;                             
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                                   
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (benchmark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');
disp('Partial derivatives CH and CN');
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));
disp(sprintf('CN_AH       :   %7.3f  CH_AH     : %9.3f',CN_AH,CH_AH));
disp(sprintf('CN_BH       :   %7.3f  CH_BH     : %9.3f',CN_BH,CH_BH));
disp(sprintf('CN_AN       :   %7.3f  CH_AN     : %9.3f',CN_AN,CH_AN));
disp(sprintf('CN_BN       :   %7.3f  CH_BN     : %9.3f',CN_BN,CH_BN));

disp('Partial derivatives LH and LN');
disp(sprintf('LN_WH       :   %7.3f  LH_WH      : %9.3f',LN_WH,LH_WH));
disp(sprintf('LN_WN       :   %7.3f  LH_WN      : %9.3f',LN_WN,LH_WN));
disp(sprintf('LN_lamb     :   %7.3f  LH_lamb    : %9.3f',LN_lambda,LH_lambda));
disp(sprintf('LN_AH       :   %7.3f  LH_AH      : %9.3f',LN_AH,LH_AH));
disp(sprintf('LN_BH       :   %7.3f  LH_BH      : %9.3f',LN_BH,LH_BH));
disp(sprintf('LN_AN       :   %7.3f  LH_AN      : %9.3f',LN_AN,LH_AN));
disp(sprintf('LN_BN       :   %7.3f  LH_BN      : %9.3f',LN_BN,LH_BN));

disp('Partial derivatives kH and kN');
disp(sprintf('kN_Q       :   %7.6f  kH_Q       : %9.6f',kN_Q,kH_Q));   
disp(sprintf('kN_K       :   %7.6f  kH_K       : %9.6f',kN_K,kH_K));  
disp(sprintf('kN_lambda  :   %7.3f  kH_lambda  : %9.3f',kN_lambda,kH_lambda));  
disp(sprintf('kN_AH      :   %7.6f  kH_AH      : %9.6f',kN_AH,kH_AH));
disp(sprintf('kN_BH      :   %7.6f  kH_BH      : %9.6f',kN_BH,kH_BH));
disp(sprintf('kN_AN      :   %7.6f  kH_AN      : %9.6f',kN_AN,kH_AN));
disp(sprintf('kN_BN      :   %7.6f  kH_BN      : %9.6f',kN_BN,kH_BN));

disp('Partial derivatives WH and WN');
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));     
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));    
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda)); 
disp(sprintf('WN_AH      :   %7.6f  WH_AH      : %9.6f',WN_AH,WH_AH));
disp(sprintf('WN_BH      :   %7.6f  WH_BH      : %9.6f',WN_BH,WH_BH));
disp(sprintf('WN_AN      :   %7.6f  WH_AN      : %9.6f',WN_AN,WH_AN));
disp(sprintf('WN_BN      :   %7.6f  WH_BN      : %9.6f',WN_BN,WH_BN));

disp('Partial derivatives LH and LN');
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));
disp(sprintf('LN_AH      :   %7.6f  LH_AH      : %9.6f',LN_AH,LH_AH));
disp(sprintf('LN_BH      :   %7.6f  LH_BH      : %9.6f',LN_BH,LH_BH));
disp(sprintf('LN_AN      :   %7.6f  LH_AN      : %9.6f',LN_AN,LH_AN));
disp(sprintf('LN_BN      :   %7.6f  LH_BN      : %9.6f',LN_BN,LH_BN));

disp('Partial derivatives C');
disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));
disp(sprintf('YN_AH      :   %7.6f  YH_AH      : %9.6f',YN_AH,YH_AH));
disp(sprintf('YN_BH      :   %7.6f  YH_BH      : %9.6f',YN_BH,YH_BH));
disp(sprintf('YN_AN      :   %7.6f  YH_AN      : %9.6f',YN_AN,YH_AN));
disp(sprintf('YN_BN      :   %7.6f  YH_BN      : %9.6f',YN_BN,YH_BN));

disp('Partial derivatives of Y');
disp(sprintf('Y_Q        :   %7.3f  Y_K        : %9.3f',Y_Q,Y_K));
disp(sprintf('Y_AH       :   %7.3f  Y_BH       : %9.3f',Y_AH,Y_BH));
disp(sprintf('Y_AN       :   %7.3f  Y_BN       : %9.3f',Y_AN,Y_BN));
disp(sprintf('Y_lambda   : %9.3f',Y_lambda));

disp('Partial derivatives of L');
disp(sprintf('L_H        :   %7.3f  L_N        : %9.3f',L_H,L_N));

disp('Partial derivatives of L');
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));
disp(sprintf('L_AH       :   %7.3f  L_BH       : %9.3f',L_AH,L_BH));
disp(sprintf('L_AN       :   %7.3f  L_BN       : %9.3f',L_AN,L_BN));
disp(sprintf('L_lambda   :   %7.3f  W_lambda   : %9.3f',L_lambda,W_lambda));

disp('Partial derivatives of W');
disp(sprintf('W_WH       :   %7.3f  W_WN       : %9.3f',W_WH,W_WN));
disp(sprintf('W_Q        :   %7.3f  W_K        : %9.3f',W_Q,W_K));
disp(sprintf('W_AH       :   %7.3f  W_BH       : %9.3f',W_AH,W_BH));
disp(sprintf('W_AN       :   %7.3f  W_BN       : %9.3f',W_AN,W_BN));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');
disp('Linearization');
disp(sprintf('R_lambda  :  %5.4f  R_K       : %5.4f   R_Q     : %5.4f',R_lambda,R_K,R_Q));
disp(sprintf('R_AH      :  %5.4f  R_BH      : %5.4f',R_AH,R_BH));
disp(sprintf('R_AN      :  %5.4f  R_BN      : %5.4f',R_AN,R_BN));
disp(sprintf('P_K       : %5.4f   P_Q       : %5.4f',P_K,P_Q));
disp(sprintf('P_AH      :  %5.4f  P_BH      : %5.4f',P_AH,P_BH));
disp(sprintf('P_AN      :  %5.4f  P_BN      : %5.4f',P_AN,P_BN));
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));
disp(sprintf('v_AH      :  %5.4f  v_BH      : %5.4f',v_AH,v_BH));
disp(sprintf('v_AN      :  %5.4f  v_BN      : %5.4f',v_AN,v_BN));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));

kH_0 = kH;  kN_0 = kN; PN_0 = PN; LH_0 = LH; K_0 = K; C_0 = C;  
LN_0  = LN; L_0 = L; W_0 = W; P_0 = P; 
YH_0  = YH; YN_0  = YN; Y_0  = Y; KH_0  = KH; KN_0  = KN; G_0 = G;     
PC_0 = PC; alphaC_0 = alphaC; CN_0 = CN; CH_0 = CH;  
ZH_0 = ZH; ZN_0 = ZN; 
AH_0 = AH; BH_0 = BH; AN_0 = AN; BN_0 = BN; Z_0 = Z; GH_0 = GH; GN_0 = GN; 
LH_0 = LH; LN_0 = LN; KH_0 = KH; KN_0 = KN; WH_0 = WH; WN_0 = WN; 
Omega_0 = Omega; YHYN_0 = YHYN; LHLN_0 = LHLN;
IF_0 = IF; CF_0 = CF; XH_0 = XH; MF_0 = MF; GF_0 = GF; PH_0 = PH; 
PT_0 = PT; PIT_0 = PIT; CT_0 = CT; IT_0 = IT; GT_0 = GT; 

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IH_0 = IH; PI_0 = PI; alphaI_0 = alphaI; EI_0 = EI; 
WPC_0 = WPC; WHPC_0 = WHPC; WNPC_0 = WNPC; alphaL_0 = alphaL; RK_0 = RK; 
yH_0 = yH; yN_0 = yN; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaIHYH_0 = omegaIHYH; omega_IFYH_0 = omegaIFYH; omegaGHYH_0 = omegaGHYH; 
omegaGFYH_0 = omegaGFYH; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYH_0 = omegaYH; omegaYN_0 = omegaYN; omegaLH_0 = omegaLH; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; 
omegaIFYH_0 = omegaIFYH; omegaGFYH_0 = omegaGFYH; omegaIH_0 = omegaIH; 
omegaCH_0 = omegaCH; omegaIF_0 = omegaIF; omegaCF_0 = omegaCF; 
omegaGT_0 = omegaGT; omegaGH_0 = omegaGH; omegaGF_0 = omegaGF; 
omegaKY_0 = omegaKY; omegaIH_0 = omegaIH; omegaIF_0 = omegaIF;
omegaXHY_0 = omegaXHY; omegaXHYH_0 = omegaXHYH; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; 
alphaI_0 = alphaI; alphaH_0 = alphaH; alphaIH_0 = alphaIH; 
sLH_0 = sLH; sLN_0 = sLN; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Permanent Technology Shock                      %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GH       = GH_0; 
GN       = GN_0; 
GF       = GF_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Endogenous response of the ratio ZH/ZN to an exogenous technology shock
filename = 'Calibration-file'; 
sheet    = 21;
xlRange  = 'B22:I39';
datac = xlsread(filename,sheet,xlRange)
param_DEU  = [datac(05,8)/100  datac(05,4)/100 datac(05,7)/100 datac(05,3)/100 datac(05,1) datac(05,2)]; 
parameters = param_DEU;
gz       = parameters(1);           
gzH      = parameters(2);    
gzN      = ((a*gzH)-gz)/b;   
gz0      = parameters(3);  
gzH0     = parameters(4);    
gzN0     = ((a*gzH0)-gz0)/b; 
barzN    = gzN - gzN0;       
barzH    = gzH - gzH0;    
xiAH     = parameters(5);                
xiBH     = parameters(5);                
xiAN     = parameters(6);                
xiBN     = parameters(6);      
AH       = AH_0*(1+gzH);      
BH       = BH_0*(1+gzH);      
AN       = AN_0*(1+gzN);      
BN       = BN_0*(1+gzN);      
aAH      = -AH_0*barzH;       
aBH      = -BH_0*barzH;       
aAN      = -AN_0*barzN;       
aBN      = -BN_0*barzN;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x0 =[C_0 L_0 kH_0 WH_0 WN_0 W_0 kN_0 PN_0 K_0 PH_0 B_0 alphaL_0 PC_0 PT_0 CN_0 CH_0 CF_0 PI_0 PIT_0 IN_0 IH_0 IF_0 LH_0 LN_0 yH_0 YH_0 yN_0 YN_0 XH_0 MF_0 lambda_0];
[x,fval,exitflag]=fsolve('TECH_IML_CAC_TOT_CES_perm',x0,optimset('display','off','TolFun',1e-011));
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
PI      = x(18) ; % Aggregate investment price index
PIT     = x(19) ; % Investment price index for tradables
IN      = x(20) ; % Non tradable investment
IH      = x(21) ; % Investment in home goods
IF      = x(22) ; % Investment in foreign goods
LH      = x(23) ; % Labor in sector H
LN      = x(24) ; % Labor in sector N 
yH      = x(25) ; % Output of home traded goods per worker
YH      = x(26) ; % Output of home traded goods
yN      = x(27) ; % Output of non traded goods per worker
YN      = x(28) ; % Output of non traded goods
XH      = x(29) ; % Exports of home traded goods
MF      = x(30) ; % Imports of foreign goods
lambda  = x(31) ; % Marginal utility of wealth lambda

% Shares
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);
alphaL  = ((1-vartheta)*(WN)^(epsilon+1))/( vartheta*(WH)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) ); 

% Labor income share in the home traded good and non traded good sector
sLH = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 

% Intertemporal solvency condition - lambda 
% Partial derivatives LH(WH,WN), LN(WH,WN)
LH_WH = (LH/WH)*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LH_WN = (LH/WN)*alphaL*(sigmaL-epsilon); 
LN_WH = (LN/WH)*(1-alphaL)*(sigmaL-epsilon); 
LN_WN = (LN/WN)*( epsilon*(1-alphaL) + (sigmaL*alphaL) ); 

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC)));

% Sectoral outputs and sectoral profits   
RK  = PI*(r+deltaK);
KH  = LH*kH;   
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;  
PiN = (PN*YN) - (RK*KN) - (WN*LN);
 
% Capital rental rates
RKH = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
RKN = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN)); 

% GDP and shares in real terms
Y  = (PH*YH) + (PN*YN); 
YR = (PH_0*YH) + (PN_0*YN);
omegaYHR = (PH_0*YH)/YR; 
omegaYNR = (PN_0*YN)/YR; 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/G; 
omegaGF = GF/G;  

% TFP
ZH = ((AH)^(sLH_0))*((BH)^(1-sLH_0)); 
ZN = ((AN)^(sLN_0))*((BN)^(1-sLN_0)); 
a  = (1/((1-alphaI_0) + alphaI_0*(sLH_0/sLN_0))); 
b  = a*(sLH_0/sLN_0); 
Z  = (ZH^a)/(ZN^b); 

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Investment 
I        = deltaK*K; 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF; 
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Solutions for kj = kj(PN,PH,K,AH,BH,AN,BN,lambda), Lj=Lj(PN,PH,K,AH,BH,AN,BN,lambda)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );

d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d13 = 0;
d14 = 0;
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = (1/sigmaN)*((1-sLN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

e11 = (1/PN); 
e12 = -(1/PH);
e13 = 0;
e14 = -(1/sigmaH)*(sLH/AH); 
e15 = -(1/sigmaH)*((sigmaH-sLH)/BH);
e16 = (1/sigmaN)*(sLN/AN); 
e17 = (1/sigmaN)*((sigmaN-sLN)/BN);
e21 = 0; 
e22 = -(1/PH); 
e23 = 0;
e24 = -(1/sigmaH)*(((sigmaH-1)+sLH)/AH); 
e25 = -(1/sigmaH)*((1-sLH)/BH); 
e26 = 0;
e27 = 0; 
e31 = -(1/PN); 
e32 = 0; 
e33 = 0;
e34 = 0; 
e35 = 0; 
e36 = -(1/sigmaN)*(((sigmaN-1)+sLN)/AN); 
e37 = -(1/sigmaN)*((1-sLN)/BN); 
e41 = 0; 
e42 = 0; 
e43 = 1; 
e44 = 0; 
e45 = 0;
e46 = 0;
e47 = 0; 
                                                                                                                                                                               
M = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];                     
X = [e11 e12 e13 e14 e15 e16 e17; e21 e22 e23 e24 e25 e26 e27; e31 e32 e33 e34 e35 e36 e37; e41 e42 e43 e44 e45 e46 e47];   
JST = inv(M);                                                                                 
MST = JST*X;                                                                                  
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1K = MST(1,3); kH_1AH = MST(1,4); kH_1BH = MST(1,5); kH_1AN = MST(1,6); kH_1BN = MST(1,7); 
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1K = MST(2,3); kN_1AH = MST(2,4); kN_1BH = MST(2,5); kN_1AN = MST(2,6); kN_1BN = MST(2,7); 
WH_PN = MST(3,1); WH_PH = MST(3,2); WH_1K = MST(3,3); WH_1AH = MST(3,4); WH_1BH = MST(3,5); WH_1AN = MST(3,6); WH_1BN = MST(3,7); 
WN_PN = MST(4,1); WN_PH = MST(4,2); WN_1K = MST(4,3); WN_1AH = MST(4,4); WN_1BH = MST(4,5); WN_1AN = MST(4,6); WN_1BN = MST(4,7);  
    
% Intermediate solutions for sectoral labor and sectoral output - Yj=Yj(PN,PH,K,AH,BH,AN,BN)
LH_PN = (LH_WH*WH_PN) + (LH_WN*WN_PN); 
LN_PN = (LN_WH*WH_PN) + (LN_WN*WN_PN); 
LH_PH = (LH_WH*WH_PH) + (LH_WN*WN_PH); 
LN_PH = (LN_WH*WH_PH) + (LN_WN*WN_PH);
LH_1K = (LH_WH*WH_1K) + (LH_WN*WN_1K); 
LN_1K = (LN_WH*WH_1K) + (LN_WN*WN_1K);
LH_1AH = (LH_WH*WH_1AH) + (LH_WN*WN_1AH);
LN_1AH = (LN_WH*WH_1AH) + (LN_WN*WN_1AH);
LH_1BH = (LH_WH*WH_1BH) + (LH_WN*WN_1BH);
LN_1BH = (LN_WH*WH_1BH) + (LN_WN*WN_1BH);
LH_1AN = (LH_WH*WH_1AN) + (LH_WN*WN_1AN);
LN_1AN = (LN_WH*WH_1AN) + (LN_WN*WN_1AN);
LH_1BN = (LH_WH*WH_1BN) + (LH_WN*WN_1BN);
LN_1BN  = (LN_WH*WH_1BN) + (LN_WN*WN_1BN);

yH_PN  = (yH/kH)*(1-sLH)*kH_PN;   
yN_PN  = (yN/kN)*(1-sLN)*kN_PN;
yH_PH  = (yH/kH)*(1-sLH)*kH_PH;   
yN_PH  = (yN/kN)*(1-sLN)*kN_PH;   
yH_1K  = (yH/kH)*(1-sLH)*kH_1K;   
yN_1K  = (yN/kN)*(1-sLN)*kN_1K; 
yH_1AH = (yH/AH)*sLH + (yH/kH)*(1-sLH)*kH_1AH;   
yN_1AH = (yN/kN)*(1-sLN)*kN_1AH;
yH_1BH =  yH*(1-sLH)*( (1/BH) + (kH_1BH/kH) );   
yN_1BH = (yN/kN)*(1-sLN)*kN_1BH;
yH_1AN =  (yH/kH)*(1-sLH)*kH_1AN;   
yN_1AN = (yN/AN)*sLN + (yN/kN)*(1-sLN)*kN_1AN;
yH_1BN =  (yH/kH)*(1-sLH)*kH_1BN;   
yN_1BN =  yN*(1-sLN)*( (1/BN) + (kN_1BN/kN) );

YH_PN = (LH*yH_PN) + (yH*LH_PN);
YN_PN = (LN*yN_PN) + (yN*LN_PN);
YH_PH = (LH*yH_PH) + (yH*LH_PH);
YN_PH = (LN*yN_PH) + (yN*LN_PH);
YH_1K = (LH*yH_1K) + (yH*LH_1K);
YN_1K = (LN*yN_1K) + (yN*LN_1K); 
YH_1AH = (LH*yH_1AH) + (yH*LH_1AH);
YN_1AH = (LN*yN_1AH) + (yN*LN_1AH);
YH_1BH = (LH*yH_1BH) + (yH*LH_1BH);
YN_1BH = (LN*yN_1BH) + (yN*LN_1BH);
YH_1AN = (LH*yH_1AN) + (yH*LH_1AN);
YN_1AN = (LN*yN_1AN) + (yN*LN_1AN);
YH_1BN = (LH*yH_1BN) + (yH*LH_1BN);
YN_1BN = (LN*yN_1BN) + (yN*LN_1BN);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,AH,BH,AN,BN,PN) -
% Intermediate Solution
PsiH_PH    = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN    = (YH_PN - CH_PN - JH_PN);
PH_PN      = -PsiH_PN/PsiH_PH; 
PH_1K      = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q      = JH_1Q/PsiH_PH; 
PH_1AH     = -YH_1AH/PsiH_PH; 
PH_1BH     = -YH_1BH/PsiH_PH;
PH_1AN     = -YH_1AN/PsiH_PH; 
PH_1BN     = -YH_1BN/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,AH,BH,AN,BN)
PsiN_PH   = (YN_PH - CN_PH - JN_PH); 
PsiN_PN   = (YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN);
PN_K      = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q      =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 
PN_AH     = -( YN_1AH + (PsiN_PH*PH_1AH) )/PsiN_PN; 
PN_BH     = -( YN_1BH + (PsiN_PH*PH_1BH) )/PsiN_PN; 
PN_AN     = -( YN_1AN + (PsiN_PH*PH_1AN) )/PsiN_PN;
PN_BN     = -( YN_1BN + (PsiN_PH*PH_1BN) )/PsiN_PN;

% Solving for the price of home goods PH=PH(lambda,K,Q,AH,BH,AN,BN) - Final
% Solution
PH_K      = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q      = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 
PH_AH     = -( YH_1AH + (PsiH_PN*PN_AH) )/PsiH_PH; 
PH_BH     = -( YH_1BH + (PsiH_PN*PN_BH) )/PsiH_PH;
PH_AN     = -( YH_1AN + (PsiH_PN*PN_AN) )/PsiH_PH; 
PH_BN     = -( YH_1BN + (PsiH_PN*PN_BN) )/PsiH_PH;  

% Solving for capital-labor ratios kj=kj(lambda,K,Q,AH,BH,AN,BN) - 
% sectoral labor Lj=Lj(lambda,K,Q,AH,BH,AN,BN) - sectoral output 
% Yj=Yj(lambda,K,Q,AH,BH,AN,BN) - Final Solutions
kH_K = kH_1K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = kN_1K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 
kH_AH = kH_1AH + (kH_PH*PH_AH) + (kH_PN*PN_AH);
kH_BH = kH_1BH + (kH_PH*PH_BH) + (kH_PN*PN_BH);
kH_AN = kH_1AN + (kH_PH*PH_AN) + (kH_PN*PN_AN);
kH_BN = kH_1BN + (kH_PH*PH_BN) + (kH_PN*PN_BN);
kN_AH = kN_1AH + (kN_PH*PH_AH) + (kN_PN*PN_AH);
kN_BH = kN_1BH + (kN_PH*PH_BH) + (kN_PN*PN_BH);
kN_AN = kN_1AN + (kN_PH*PH_AN) + (kN_PN*PN_AN); 
kN_BN = kN_1BN + (kN_PH*PH_BN) + (kN_PN*PN_BN);

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LH_AH = LH_1AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_1BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_1AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_1BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);
LN_AH = LN_1AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_1BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_1AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_1BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

YH_AH = YH_1AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_1BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_1AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_1BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YN_AH = YN_1AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_1BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_1AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_1BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);

% Solving for consumption Cj=Cj(lambda,K,Q,AH,BH,AN,BN), investment inputs 
% Jj=Jj(K,Q,AH,BH,AN,BN), imports MF=MF(lambda,K,Q,AH,BH,AN,BN), exports 
%XH=XH(lambda,K,Q,AH,BH,AN,BN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CH_AH     = (CH_PH*PH_AH) + (CH_PN*PN_AH);
CH_BH     = (CH_PH*PH_BH) + (CH_PN*PN_BH);
CH_AN     = (CH_PH*PH_AN) + (CH_PN*PN_AN);
CH_BN     = (CH_PH*PH_BN) + (CH_PN*PN_BN);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CN_AH     = (CN_PH*PH_AH) + (CN_PN*PN_AH);
CN_BH     = (CN_PH*PH_BH) + (CN_PN*PN_BH);
CN_AN     = (CN_PH*PH_AN) + (CN_PN*PN_AN);   
CN_BN     = (CN_PH*PH_BN) + (CN_PN*PN_BN);                       

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q); 
CF_AH     = (CF_PH*PH_AH) + (CF_PN*PN_AH);
CF_BH     = (CF_PH*PH_BH) + (CF_PN*PN_BH);
CF_AN     = (CF_PH*PH_AN) + (CF_PN*PN_AN); 
CF_BN     = (CF_PH*PH_BN) + (CF_PN*PN_BN);                       
 
JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);         

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN);        

XH_K      = XH_PH*PH_K; 
XH_Q      = XH_PH*PH_Q; 
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;

MF_K      = (CF_K + JF_K); 
MF_Q      = (CF_Q + JF_Q); 
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);

% Solving for sectoral wages - Wj=Wj(lambda,K,Q,AH,BH,AN,BN)
WH_K      = WH_1K + (WH_PH*PH_K) + (WH_PN*PN_K); 
WH_Q      = (WH_PH*PH_Q) + (WH_PN*PN_Q); 
WH_AH     = WH_1AH + (WH_PH*PH_AH) + (WH_PN*PN_AH);
WH_BH     = WH_1BH + (WH_PH*PH_BH) + (WH_PN*PN_BH);
WH_AN     = WH_1AN + (WH_PH*PH_AN) + (WH_PN*PN_AN);
WH_BN     = WH_1BN + (WH_PH*PH_BN) + (WH_PN*PN_BN);

WN_K      = WN_1K + (WN_PH*PH_K) + (WN_PN*PN_K);                 
WN_Q      = (WN_PH*PH_Q) + (WN_PN*PN_Q);                         
WN_AH     = WN_1AH + (WN_PH*PH_AH) + (WN_PN*PN_AH);   
WN_BH     = WN_1BH + (WN_PH*PH_BH) + (WN_PN*PN_BH);
WN_AN     = WN_1AN + (WN_PH*PH_AN) + (WN_PN*PN_AN);  
WN_BN     = WN_1BN + (WN_PH*PH_BN) + (WN_PN*PN_BN);

% Solution for W as function W=W(lambda,K,Q,AH,BH,AN,BN) 
W_WH      = (W/WH)*(1-alphaL); 
W_WN      = (W/WN)*alphaL; 
W_K       = (W_WH*WH_K) + (W_WN*WN_K); 
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);
W_AH      = (W_WH*WH_AH) + (W_WN*WN_AH); 
W_BH      = (W_WH*WH_BH) + (W_WN*WN_BH);
W_AN      = (W_WH*WH_AN) + (W_WN*WN_AN);
W_BN      = (W_WH*WH_BN) + (W_WN*WN_BN);

% Solution for L as function L=L(lambda,K,Q,AH,BH,AN,BN)
L_W  = sigmaL*(L/W); 
L_WH = sigmaL*L*(1-alphaL)/WH; 
L_WN = sigmaL*L*alphaL/WN; 
L_K  = (L_WH*WH_K) + (L_WN*WN_K); 
L_Q  = (L_WH*WH_Q) + (L_WN*WN_Q);
L_AH = (L_WH*WH_AH) + (L_WN*WN_AH); 
L_BH = (L_WH*WH_BH) + (L_WN*WN_BH);
L_AN = (L_WH*WH_AN) + (L_WN*WN_AN);
L_BN = (L_WH*WH_BN) + (L_WN*WN_BN);

% Solution for C as function C=C(lambda,K,Q,AH,BH,AN,BN) 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_AH       = (C_PH*PH_AH) + (C_PN*PN_AH);
C_BH       = (C_PH*PH_BH) + (C_PN*PN_BH);
C_AN       = (C_PH*PH_AN) + (C_PN*PN_AN);
C_BN       = (C_PH*PH_BN) + (C_PN*PN_BN);

% Solution for Y as function Y=Y(K,Q,lambda,AH,BH,AN,BN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_AH      = (PH_AH*YH) + (PH*YH_AH) + (PN_AH*YN) + (PN*YN_AH);
Y_BH      = (PH_BH*YH) + (PH*YH_BH) + (PN_BH*YN) + (PN*YN_BH);
Y_AN      = (PH_AN*YH) + (PH*YH_AN) + (PN_AN*YN) + (PN*YN_AN);
Y_BN      = (PH_BN*YH) + (PH*YH_BN) + (PN_BN*YN) + (PN*YN_BN);

% Marginal revenue of capital R = PN*partial YN/partial KN
R_K  = (RK/PN)*PN_K - (RK/kN)*(sLN/sigmaN)*kN_K; 
R_Q  = (RK/PN)*PN_Q - (RK/kN)*(sLN/sigmaN)*kN_Q;  
R_AH = (RK/PN)*PN_AH - (RK/kN)*(sLN/sigmaN)*kN_AH;  
R_BH = (RK/PN)*PN_BH - (RK/kN)*(sLN/sigmaN)*kN_BH;
R_AN = (RK/AN)*(sLN/sigmaN) + (RK/PN)*PN_AN - (RK/kN)*(sLN/sigmaN)*kN_AN;
R_BN = (RK/BN)*((sigmaN-sLN)/sigmaN) + (RK/PN)*PN_BN - (RK/kN)*(sLN/sigmaN)*kN_BN;

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(lambda,K,Q,AH,BH,AN,BN) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);

% Eigenvalues and Eigenvectors 
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + (alphaI*phiI*I)*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + (alphaI*phiI*I)*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Upsilon_AH = (I/IN)*(YN_AH-CN_AH) + (alphaI*phiI*I)*( (PN_AH/PN) - (alphaIH/PH)*PH_AH );
Upsilon_BH = (I/IN)*(YN_BH-CN_BH) + (alphaI*phiI*I)*( (PN_BH/PN) - (alphaIH/PH)*PH_BH );
Upsilon_AN = (I/IN)*(YN_AN-CN_AN) + (alphaI*phiI*I)*( (PN_AN/PN) - (alphaIH/PH)*PH_AN );
Upsilon_BN = (I/IN)*(YN_BN-CN_BN) + (alphaI*phiI*I)*( (PN_BN/PN) - (alphaIH/PH)*PH_BN );
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 
Sigma_AH   = -( R_AH + (PI*kappa*v_AH*deltaK) ); 
Sigma_BH   = -( R_BH + (PI*kappa*v_BH*deltaK) ); 
Sigma_AN   = -( R_AN + (PI*kappa*v_AN*deltaK) ); 
Sigma_BN   = -( R_BN + (PI*kappa*v_BN*deltaK) );
 
x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x13   = Upsilon_AH; 
x14   = Upsilon_BH;
x15   = Upsilon_AN; 
x16   = Upsilon_BN;
x21   = Sigma_K;                        
x22   = Sigma_Q;
x23   = Sigma_AH; 
x24   = Sigma_BH;
x25   = Sigma_AN; 
x26   = Sigma_BN;
x31   = 0; 
x32   = 0; 
x33   = -xiAH; 
x34   = 0; 
x35   = 0; 
x36   = 0; 
x41   = 0; 
x42   = 0; 
x43   = 0; 
x44   = -xiBH;    
x45   = 0; 
x46   = 0; 
x51   = 0; 
x52   = 0; 
x53   = 0; 
x54   = 0;    
x55   = -xiAN; 
x56   = 0; 
x61   = 0; 
x62   = 0; 
x63   = 0; 
x64   = 0;    
x65   = 0; 
x66   = -xiBN;     

J = [x11 x12 x13 x14 x15 x16; x21 x22 x23 x24 x25 x26; x31 x32 x33 x34 x35 x36; x41 x42 x43 x44 x45 x46; x51 x52 x53 x54 x55 x56; ; x61 x62 x63 x64 x65 x66];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
nu_1 = nu(1,1);             
nu_2 = nu(2,2);             
nu_3 = nu(3,3);             
nu_4 = nu(4,4);   
nu_5 = nu(5,5);             
nu_6 = nu(6,6);
                            
omega_11 = V(1,1)/V(1,1);   
omega_21 = V(2,1)/V(1,1);   
omega_31 = V(3,1)/V(1,1);   
omega_41 = V(4,1)/V(1,1);  
omega_51 = V(5,1)/V(1,1);   
omega_61 = V(6,1)/V(1,1);
                            
omega_12 = V(1,2)/V(1,2);   
omega_22 = V(2,2)/V(1,2);   
omega_32 = V(3,2)/V(1,2);   
omega_42 = V(4,2)/V(1,2);  
omega_52 = V(5,2)/V(1,2);   
omega_62 = V(6,2)/V(1,2);
                            
omega_13 = V(1,3)/V(3,3);   
omega_23 = V(2,3)/V(3,3);   
omega_33 = V(3,3)/V(3,3);   
omega_43 = V(4,3)/V(3,3);   
omega_53 = V(5,3)/V(3,3);   
omega_63 = V(6,3)/V(3,3); 
                            
omega_14 = V(1,4)/V(4,4);   
omega_24 = V(2,4)/V(4,4);   
omega_34 = V(3,4)/V(4,4);   
omega_44 = V(4,4)/V(4,4); 
omega_54 = V(5,4)/V(4,4);   
omega_64 = V(6,4)/V(4,4);

omega_15 = V(1,5)/V(5,5);    
omega_25 = V(2,5)/V(5,5);    
omega_35 = V(3,5)/V(5,5);    
omega_45 = V(4,5)/V(5,5);    
omega_55 = V(5,5)/V(5,5);    
omega_65 = V(6,5)/V(5,5);    
                             
omega_16 = V(1,6)/V(6,6);    
omega_26 = V(2,6)/V(6,6);    
omega_36 = V(3,6)/V(6,6);    
omega_46 = V(4,6)/V(6,6);    
omega_56 = V(5,6)/V(6,6);    
omega_66 = V(6,6)/V(6,6);    

TrJ = trace(J); 
DetJ = det(J); 

J1 = [x11 x12; x21 x22];
TrJ1 = trace(J1); 
DetJ1 = det(J1);

% Check for Eigenvectors
omega13 = -( x13*(x22+xiAH) - (x12*x23) )/( (nu_1+xiAH)*(nu_2+xiAH) );
omega14 = -( x14*(x22+xiBH) - (x12*x24) )/( (nu_1+xiBH)*(nu_2+xiBH) );
omega15 = -( x15*(x22+xiAN) - (x12*x25) )/( (nu_1+xiAN)*(nu_2+xiAN) );
omega16 = -( x16*(x22+xiBN) - (x12*x26) )/( (nu_1+xiBN)*(nu_2+xiBN) );
                                                                      
omega23 = ( (x13*x21) - (x11+xiAH)*x23 )/( (nu_1+xiAH)*(nu_2+xiAH) ); 
omega24 = ( (x14*x21) - (x11+xiBH)*x24 )/( (nu_1+xiBH)*(nu_2+xiBH) ); 
omega25 = ( (x15*x21) - (x11+xiAN)*x25 )/( (nu_1+xiAN)*(nu_2+xiAN) ); 
omega26 = ( (x16*x21) - (x11+xiBN)*x26 )/( (nu_1+xiBN)*(nu_2+xiBN) ); 

% Solve for Arbitrary Constants 
D3 = aAH; 
D4 = aBH; 
D5 = aAN; 
D6 = aBN;
D1 = (K0 - K) - (omega_13*D3) - (omega_14*D4) - (omega_15*D5) - (omega_16*D6); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q,AH,BH,AN,BN);
% Xi_Q=0
B_K          = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_AH         = (PH_AH*XH) + (PH*XH_AH) - MF_AH; 
B_BH         = (PH_BH*XH) + (PH*XH_BH) - MF_BH; 
B_AN         = (PH_AN*XH) + (PH*XH_AN) - MF_AN;
B_BN         = (PH_BN*XH) + (PH*XH_BN) - MF_BN;
N1           = (B_K + (B_Q*omega_21)); 
N2           = ((B_K*omega_13) + (B_Q*omega_23) + B_AH); 
N3           = ((B_K*omega_14) + (B_Q*omega_24) + B_BH); 
N4           = ((B_K*omega_15) + (B_Q*omega_25) + B_AN); 
N5           = ((B_K*omega_16) + (B_Q*omega_26) + B_BN); 
wB1          = N1/(r-nu_1); 
wBAH         = N2/(r+xiAH); 
wBBH         = N3/(r+xiBH);
wBAN         = N4/(r+xiAN);
wBBN         = N5/(r+xiBN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(lambda,K,Q,ZH,ZF); 
P    = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_AH = (P/PN)*PN_AH - (P/PH)*PH_AH;
P_BH = (P/PN)*PN_BH - (P/PH)*PH_BH;
P_AN = (P/PN)*PN_AN - (P/PH)*PH_AN;
P_BN = (P/PN)*PN_BN - (P/PH)*PH_BN;

% Solution for PC=PC(PH,PN) - PC = PC(lambda,K,Q,ZH,ZF)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_AH      = (PC/PH)*alphaC*alphaH*PH_AH + (PC/PN)*(1-alphaC)*PN_AH;
PC_BH      = (PC/PH)*alphaC*alphaH*PH_BH + (PC/PN)*(1-alphaC)*PN_BH;
PC_AN      = (PC/PH)*alphaC*alphaH*PH_AN + (PC/PN)*(1-alphaC)*PN_AN;
PC_BN      = (PC/PH)*alphaC*alphaH*PH_BN + (PC/PN)*(1-alphaC)*PN_BN;

% Solution for PI=PI(PH,PN) - PI = PI(lambda,K,Q,ZH,ZF)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_AH      = (PI/PH)*alphaI*alphaIH*PH_AH + (PI/PN)*(1-alphaI)*PN_AH;
PI_BH      = (PI/PH)*alphaI*alphaIH*PH_BH + (PI/PN)*(1-alphaI)*PN_BH;
PI_AN      = (PI/PH)*alphaI*alphaIH*PH_AN + (PI/PN)*(1-alphaI)*PN_AN;
PI_BN      = (PI/PH)*alphaI*alphaIH*PH_BN + (PI/PN)*(1-alphaI)*PN_BN;

% Solution for G=G(PH,PN) - G= G(lambda,K,Q,ZH,ZF)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_AH       = (PH_AH*GH) + (PN_AH*GN);
G_BH       = (PH_BH*GH) + (PN_BH*GN);
G_AN       = (PH_AN*GH) + (PN_AN*GN);
G_BN       = (PH_BN*GH) + (PN_BN*GN);

% Capital rental rates
RKH = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH)); 
RKN = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN));

% Solution for the stock of financial wealth
A0        = B0 + (PI*K0); 
A_K       = (W_K*L) + (W*L_K) - G_K - (PC_K*C) - (PC*C_K); 
A_Q       = (W_Q*L) + (W*L_Q) - G_Q - (PC_Q*C) - (PC*C_Q); 
A_AH      = (W_AH*L) + (W*L_AH) - G_AH - (PC_AH*C) - (PC*C_AH);
A_BH      = (W_BH*L) + (W*L_BH) - G_BH - (PC_BH*C) - (PC*C_BH);
A_AN      = (W_AN*L) + (W*L_AN) - G_AN - (PC_AN*C) - (PC*C_AN);
A_BN      = (W_BN*L) + (W*L_BN) - G_BN - (PC_BN*C) - (PC*C_BN);
M1        = A_K + (A_Q*omega_21); 
M2        = ((A_K*omega_13) + (A_Q*omega_23) + A_AH); 
M3        = ((A_K*omega_14) + (A_Q*omega_24) + A_BH); 
M4        = ((A_K*omega_15) + (A_Q*omega_25) + A_AN); 
M5        = ((A_K*omega_16) + (A_Q*omega_26) + A_BN);
wA1       = M1/(r-nu_1); 
wAAH      = M2/(r+xiAH); 
wABH      = M3/(r+xiBH);
wAAN      = M4/(r+xiAN);
wABN      = M5/(r+xiBN);
A         = A0 + (wA1*D1) + (wAAH*D3) + (wABH*D4) + (wAAN*D5) + (wABN*D6); 

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH = IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L;

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GH+PN*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
cond1  = PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((YH/KH)^(1/sigmaH))-RK;                               
cond2  = PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((YN/KN)^(1/sigmaN))-RK;                             
cond3  = PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH))-WH;                                   
cond4  = PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN))-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;  
cond9  = (B - B0) - (wB1*D1) - (wBAH*aAH) - (wBBH*aBH) - (wBAN*aAN) - (wBBN*aBN);
cond10 = DetJ1 - (nu_1*nu_2);
cond11 = TrJ1 - (nu_1+nu_2); 
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                               
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL); 
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = omega_13 - omega13; 
cond31 = omega_14 - omega14; 
cond32 = omega_15 - omega15;
cond33 = omega_16 - omega16;
cond34 = omega_23 - omega23; 
cond35 = omega_24 - omega24; 
cond36 = omega_25 - omega25; 
cond37 = omega_26 - omega26;
cond38 = nu_3 + xiAH; 
cond39 = nu_4 + xiBH; 
cond40 = nu_5 + xiAN; 
cond41 = nu_6 + xiBN; 

% Define New steady-state values
kH_deu = kH; kN_deu = kN; PN_deu = PN; LH_deu = LH; K_deu = K; C_deu = C;  
LN_deu = LN; L_deu  = L; W_deu = W; P_deu = P; 
YH_deu = YH; YN_deu = YN; Y_deu = Y; KH_deu  = KH; KN_deu  = KN; G_deu = G;     
PC_deu = PC; alphaC_deu = alphaC; CN_deu = CN; CH_deu = CH;  
GH_deu = GH; GN_deu = GN; ZH_deu = ZH; ZN_deu = ZN; Z_deu = Z; 
AH_deu = AH; BH_deu = BH; AN_deu = AN; BN_deu = BN;
LH_deu = LH; LN_deu = LN; KH_deu = KH; KN_deu = KN; WH_deu = WH; WN_deu = WN; 
Omega_deu = Omega; WPC_deu = WPC; WHPC_deu = WHPC; WNPC_deu = WNPC;
IF_deu = IF; CF_deu = CF; XH_deu = XH; MF_deu = MF; GF_deu = GF; PH_deu = PH; 
PT_deu = PT; PIT_deu = PIT; CT_deu = CT; IT_deu = IT; GT_deu = GT; 

YHYN_deu = YHYN; LHLN_deu = LHLN; IH_deu = IH; IN_deu = IN; PI_deu = PI; 
EI_deu = EI; CA_deu = CA; Sav_deu = Sav; NX_deu = NX; I_deu = I; A_deu = A; 
B_deu = B; lambda_deu  = lambda; RK_deu = RK; YR_deu = YR; 
yH_deu = yH; yN_deu = yN; 

omegaL_deu = omegaL; omegaK_deu = omegaK; omegaI_deu = omegaI; omegaINYN_deu = omegaINYN;
omegaIHYH_deu = omegaIHYH; omega_IFYH_deu = omegaIFYH; omegaGHYH_deu = omegaGHYH; 
omegaGFYH_deu = omegaGFYH; omegaGNYN_deu = omegaGNYN; omegaGN_deu = omegaGN;
omegaYH_deu = omegaYH; omegaYN_deu = omegaYN; omegaLH_deu = omegaLH; omegaLN_deu = omegaLN; 
omegaC_deu =omegaC; omegaNX_deu =omegaNX; omegaG_deu =omegaG; omegaB_deu =omegaB; 
omegaKY_deu = omegaKY; omegaIH_deu = omegaIH; omegaIF_deu = omegaIF; 
omegaGT_deu = omegaGT; omegaGH_deu = omegaGH; omegaGF_deu = omegaGF;
alphaL_deu = alphaL; alphaK_deu = alphaK; alphaC_deu = alphaC; 
alphaI_deu = alphaI; alphaH_deu = alphaH; alphaIH_deu = alphaIH;
omegaYHR_deu = omegaYHR; omegaYNR_deu = omegaYNR;
sLH_deu = sLH, sLN_deu = sLN; 
% Steady-State Changes
dC       = C_deu - C_0; % Steady-state change of real consumption 
dK       = K_deu - K_0; % Steady-state change of real capital 
dL       = L_deu - L_0; % Steady-state change of employment 
dPN      = PN_deu - PN_0; % Steady-state change of non traded good prices
dPH      = PH_deu - PH_0; % Steady-state change of terms of trade (price of exports in terms if imports)
dP       = P_deu - P_0; % Steady-state change of non traded goods prices relative to tradable home goods prices
dB       = B_deu - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_deu - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = ( (PH_deu*YH_deu) + (PN_deu*YN_deu) ) - Y_0; % Steady-state change of GDP 
dY_check = Y_deu - Y_0; % Steady-state change of GDP - Check
dYR      = YR_deu - Y_0; % Steady-state change of real GDP 
dA       = A_deu - A_0; % Steady-state change of financial wealth 
dW       = W_deu - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_deu - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_deu - Omega_0; % Steady-state change of the sector wage ratio

dCH   = CH_deu - CH_0; % Steady-state change of CH
dCN   = CN_deu - CN_0; % Steady-state change of CN
dLH   = LH_deu - LH_0; % Steady-state change of real capital 
dLN   = LN_deu - LN_0; % Steady-state change of employment 
dKH   = KH_deu - KH_0; % Steady-state change of real capital 
dKN   = KN_deu - KN_0; % Steady-state change of employment 
dYH   = YH_deu - YH_0; % Steady-state change of YH
dYN   = YN_deu - YN_0; % Steady-state change of YN
dWH   = WH_deu - WH_0; % Steady-state change of WH
dWN   = WN_deu - WN_0; % Steady-state change of WN
dWHPC = WHPC_deu - WHPC_0; % Steady-state change of WH/PC
dWNPC = WNPC_deu - WNPC_0; % Steady-state change of WN/PC
dkH   = kH_deu - kH_0; % Steady-state change of kH 
dkN   = kN_deu - kN_0; % Steady-state change of kN
dLHLN = LHLN_deu - LHLN_0; % Steady-state change of LH/LN
dYHYN = YHYN_deu - YHYN_0; % Steady-state change of LH/LN
dsLH  = sLH_deu - sLH_0; % Steady-state change of labor income share in the home traded good sector
dsLN  = sLN_deu - sLN_0; % Steady-state change of labor income share in the non traded good sector

dZH   = ZH_deu - ZH_0; 
dZN   = ZN_deu - ZN_0; 
dAH   = AH_deu - AH_0; 
dBH   = BH_deu - BH_0;
dAN   = AN_deu - AN_0; 
dBN   = BN_deu - BN_0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% Solution for investment PI*K,
EK_1   = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*V1(t) + EK2*X2(t)
EK_AH  = (PI*omega_13) + (K*omega_23);
EK_BH  = (PI*omega_14) + (K*omega_24);
EK_AN  = (PI*omega_15) + (K*omega_25);
EK_BN  = (PI*omega_16) + (K*omega_26);

% Solution for the Consumption Price index PC=PC(lambda,K,Q,AH,BH,AN,BN)
wPC_1   =  PC_K + (PC_Q*omega_21);
wPC_AH  = (PC_K*omega_13) + (PC_Q*omega_23) + PC_AH;
wPC_BH  = (PC_K*omega_14) + (PC_Q*omega_24) + PC_BH;
wPC_AN  = (PC_K*omega_15) + (PC_Q*omega_25) + PC_AN;
wPC_BN  = (PC_K*omega_16) + (PC_Q*omega_26) + PC_BN;

% Solution for the Investment Price index PI=PI(lambda,K,Q,AH,BH,AN,BN)
wPI_1   =  PI_K + (PI_Q*omega_21);
wPI_AH  = (PI_K*omega_13) + (PI_Q*omega_23) + PI_AH;
wPI_BH  = (PI_K*omega_14) + (PI_Q*omega_24) + PI_BH;
wPI_AN  = (PI_K*omega_15) + (PI_Q*omega_25) + PI_AN;
wPI_BN  = (PI_K*omega_16) + (PI_Q*omega_26) + PI_BN;

% Solution for the Relative Price of Non tradables PN=PN(lambda,K,Q,AH,BH,AN,BN);
wPN_1   =  PN_K + (PN_Q*omega_21); ;
wPN_AH  = (PN_K*omega_13) + (PN_Q*omega_23) + PN_AH;
wPN_BH  = (PN_K*omega_14) + (PN_Q*omega_24) + PN_BH;
wPN_AN  = (PN_K*omega_15) + (PN_Q*omega_25) + PN_AN;
wPN_BN  = (PN_K*omega_16) + (PN_Q*omega_26) + PN_BN;

% Solution for the Terms of Trade PH=PH(lambda,K,Q,AH,BH,AN,BN)
wPH_1   =  PH_K + (PH_Q*omega_21);
wPH_AH  = (PH_K*omega_13) + (PH_Q*omega_23) + PH_AH;
wPH_BH  = (PH_K*omega_14) + (PH_Q*omega_24) + PH_BH;
wPH_AN  = (PH_K*omega_15) + (PH_Q*omega_25) + PH_AN;
wPH_BN  = (PH_K*omega_16) + (PH_Q*omega_26) + PH_BN;

% Solution for the Price of non tradables in terms of home tradable goods P=P(lambda,K,Q,AH,BH,AN,BN)
wP_1   = (P/PN)*wPN_1 - (P/PH)*wPH_1;
wP_AH  = (P/PN)*wPN_AH - (P/PH)*wPH_AH;
wP_BH  = (P/PN)*wPN_BH - (P/PH)*wPH_BH;
wP_AN  = (P/PN)*wPN_AN - (P/PH)*wPH_AN;
wP_BN  = (P/PN)*wPN_BN - (P/PH)*wPH_BN;

% Solution for Q(t)/PI(P(t))
wQPI_1  = (omega_21/PI) - (wPI_1/PI);
wQPI_AH = (omega_23/PI) - (wPI_AH/PI);
wQPI_BH = (omega_24/PI) - (wPI_BH/PI);
wQPI_AN = (omega_25/PI) - (wPI_AN/PI);
wQPI_BN = (omega_26/PI) - (wPI_BN/PI);

% Solution for Consumption C=C(lambda,P)
wC_1 =  C_K + (C_Q*omega_21);
wC_AH = (C_K*omega_13) + (C_Q*omega_23) + C_AH;
wC_BH = (C_K*omega_14) + (C_Q*omega_24) + C_BH;
wC_AN = (C_K*omega_15) + (C_Q*omega_25) + C_AN;
wC_BN = (C_K*omega_16) + (C_Q*omega_26) + C_BN;

% Solution for the Aggregate Wage Index W=W(K,Q,AH,BH,AN,BN)
wW_1  =  W_K + (W_Q*omega_21);
wW_AH  = (W_K*omega_13) + (W_Q*omega_23) + W_AH;
wW_BH  = (W_K*omega_14) + (W_Q*omega_24) + W_BH;
wW_AN  = (W_K*omega_15) + (W_Q*omega_25) + W_AN;
wW_BN  = (W_K*omega_16) + (W_Q*omega_26) + W_BN;

% Solution for the Capital Rental Rate RK=R(K,Q,AH,BH,AN,BN)
wR_1  =  R_K + (R_Q*omega_21);
wR_AH  = (R_K*omega_13) + (R_Q*omega_23) + R_AH;
wR_BH  = (R_K*omega_14) + (R_Q*omega_24) + R_BH;
wR_AN  = (R_K*omega_15) + (R_Q*omega_25) + R_AN;
wR_BN  = (R_K*omega_16) + (R_Q*omega_26) + R_BN;

% Solution for the Real Consumption Wage W(K,Q,AH,BH,AN,BN)/PC(P)
wWPC_1  = WPC*( (wW_1/W) - (wPC_1/PC) );
wWPC_AH = WPC*( (wW_AH/W) - (wPC_AH/PC) );
wWPC_BH = WPC*( (wW_BH/W) - (wPC_BH/PC) );
wWPC_AN = WPC*( (wW_AN/W) - (wPC_AN/PC) );
wWPC_BN = WPC*( (wW_BN/W) - (wPC_BN/PC) );

% Solution for Labor L=L(lambda,W)=L(lambda,K,Q,AH,BH,AN,BN)
wL_1  =  L_K + (L_Q*omega_21);
wL_AH = (L_K*omega_13) + (L_Q*omega_23) + L_AH;
wL_BH = (L_K*omega_14) + (L_Q*omega_24) + L_BH;
wL_AN = (L_K*omega_15) + (L_Q*omega_25) + L_AN;
wL_BN = (L_K*omega_16) + (L_Q*omega_26) + L_BN;

% Solutions for the Sectoral Labor kj=kj(lambda,K,Q,AH,BH,AN,BN)
wkH_1   =  kH_K + (kH_Q*omega_21);
wkH_AH  = (kH_K*omega_13) + (kH_Q*omega23) + kH_AH;
wkH_BH  = (kH_K*omega_14) + (kH_Q*omega_24) + kH_BH;
wkH_AN  = (kH_K*omega_15) + (kH_Q*omega23) + kH_AN;
wkH_BN  = (kH_K*omega_16) + (kH_Q*omega_26) + kH_BN;

wkN_1   =  kN_K + (kN_Q*omega_21);
wkN_AH  = (kN_K*omega_13) + (kN_Q*omega23) + kN_AH;
wkN_BH  = (kN_K*omega_14) + (kN_Q*omega_24) + kN_BH;
wkN_AN  = (kN_K*omega_15) + (kN_Q*omega23) + kN_AN;
wkN_BN  = (kN_K*omega_16) + (kN_Q*omega_26) + kN_BN;

% Solutions for the Sectoral Labor Lj=Lj(lambda,K,Q,AH,BH,AN,BN)
wLH_1   =  LH_K + (LH_Q*omega_21);
wLH_AH  = (LH_K*omega_13) + (LH_Q*omega_23) + LH_AH;
wLH_BH  = (LH_K*omega_14) + (LH_Q*omega_24) + LH_BH;
wLH_AN  = (LH_K*omega_15) + (LH_Q*omega_25) + LH_AN;
wLH_BN  = (LH_K*omega_16) + (LH_Q*omega_26) + LH_BN;

wLN_1   =  LN_K + (LN_Q*omega_21);
wLN_AH  = (LN_K*omega_13) + (LN_Q*omega_23) + LN_AH;
wLN_BH  = (LN_K*omega_14) + (LN_Q*omega_24) + LN_BH;
wLN_AN  = (LN_K*omega_15) + (LN_Q*omega_25) + LN_AN;
wLN_BN  = (LN_K*omega_16) + (LN_Q*omega_26) + LN_BN;

% Solution for GDP Y=Y(lambda,K,Q,AH,BH,AN,BN)
wY_1    = Y_K + (Y_Q*omega_21);
wY_AH   = (Y_K*omega_13) + (Y_Q*omega_23) + Y_AH;
wY_BH   = (Y_K*omega_14) + (Y_Q*omega_24) + Y_BH;
wY_AN   = (Y_K*omega_15) + (Y_Q*omega_25) + Y_AN;
wY_BN   = (Y_K*omega_16) + (Y_Q*omega_26) + Y_BN;

wYR_1   = (PH_0*YH_K) + (PN_0*YN_K) + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_21;
wYR_AH  = ((PH_0*YH_K) + (PN_0*YN_K))*omega_13 + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_23 + ((PH_0*YH_AH) + (PN_0*YN_AH));
wYR_BH  = ((PH_0*YH_K) + (PN_0*YN_K))*omega_14 + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_24 + ((PH_0*YH_BH) + (PN_0*YN_BH));
wYR_AN  = ((PH_0*YH_K) + (PN_0*YN_K))*omega_15 + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_25 + ((PH_0*YH_AN) + (PN_0*YN_AN));
wYR_BN  = ((PH_0*YH_K) + (PN_0*YN_K))*omega_16 + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_26 + ((PH_0*YH_BN) + (PN_0*YN_BN));

% Solutions for the Sectoral Output Yj=Yj(lambda,K,Q,AH,BH,AN,BN)
wYH_1   = YH_K + (YH_Q*omega_21);
wYH_AH  = (YH_K*omega_13) + (YH_Q*omega_23) + YH_AH;
wYH_BH  = (YH_K*omega_14) + (YH_Q*omega_24) + YH_BH;
wYH_AN  = (YH_K*omega_15) + (YH_Q*omega_25) + YH_AN;
wYH_BN  = (YH_K*omega_16) + (YH_Q*omega_26) + YH_BN;

wYN_1   = YN_K + (YN_Q*omega_21);
wYN_AH  = (YN_K*omega_13) + (YN_Q*omega_23) + YN_AH;
wYN_BH  = (YN_K*omega_14) + (YN_Q*omega_24) + YN_BH;
wYN_AN  = (YN_K*omega_15) + (YN_Q*omega_25) + YN_AN;
wYN_BN  = (YN_K*omega_16) + (YN_Q*omega_26) + YN_BN;

% Solutions for the Sectoral Wages Wj=Wj(K,Q,AH,BH,AN,BN)
wWH_1   = WH_K + (WH_Q*omega_21);
wWH_AH  = (WH_K*omega_13) + (WH_Q*omega_23) + WH_AH;
wWH_BH  = (WH_K*omega_14) + (WH_Q*omega_24) + WH_BH;
wWH_AN  = (WH_K*omega_15) + (WH_Q*omega_25) + WH_AN;
wWH_BN  = (WH_K*omega_16) + (WH_Q*omega_26) + WH_BN;

wWN_1   = WN_K + (WN_Q*omega_21);
wWN_AH  = (WN_K*omega_13) + (WN_Q*omega_23) + WN_AH;
wWN_BH  = (WN_K*omega_14) + (WN_Q*omega_24) + WN_BH;
wWN_AN  = (WN_K*omega_15) + (WN_Q*omega_25) + WN_AN;
wWN_BN  = (WN_K*omega_16) + (WN_Q*omega_26) + WN_BN;

% Solutions for the Real Sectoral Wages Wj(K,P)/PC(P)
wWHPC_1  = WHPC*( (wWH_1/WH) - (wPC_1/PC) );
wWHPC_AH = WHPC*( (wWH_AH/WH) - (wPC_AH/PC) );
wWHPC_BH = WHPC*( (wWH_BH/WH) - (wPC_BH/PC) );
wWHPC_AN = WHPC*( (wWH_AN/WH) - (wPC_AN/PC) );
wWHPC_BN = WHPC*( (wWH_BN/WH) - (wPC_BN/PC) );

wWNPC_1  = WNPC*( (wWN_1/WN) - (wPC_1/PC) );
wWNPC_AH = WNPC*( (wWN_AH/WN) - (wPC_AH/PC) );
wWNPC_BH = WNPC*( (wWN_BH/WN) - (wPC_BH/PC) );
wWNPC_AN = WNPC*( (wWN_AN/WN) - (wPC_AN/PC) );
wWNPC_BN = WNPC*( (wWN_BN/WN) - (wPC_BN/PC) );

% Solution for Omega = WN(K,P)/WH(K,P)
wOmega_1  = Omega*( (wWN_1/WN) - (wWH_1/WH) );
wOmega_AH = Omega*( (wWN_AH/WN) - (wWH_AH/WH) );
wOmega_BH = Omega*( (wWN_BH/WN) - (wWH_BH/WH) );
wOmega_AN = Omega*( (wWN_AN/WN) - (wWH_AN/WH) );
wOmega_BN = Omega*( (wWN_BN/WN) - (wWH_BN/WH) );

% Solution for YH(lambda,K,Q,AH,BH,AN,BN)/YN(lambda,K,Q,AH,BH,AN,BN)
wYHYN_1  = YHYN*( (wYH_1/YH) - (wYN_1/YN) );
wYHYN_AH = YHYN*( (wYH_AH/YH) - (wYN_AH/YN) );
wYHYN_BH = YHYN*( (wYH_BH/YH) - (wYN_BH/YN) );
wYHYN_AN = YHYN*( (wYH_AN/YH) - (wYN_AN/YN) );
wYHYN_BN = YHYN*( (wYH_BN/YH) - (wYN_BN/YN) );

% Solution for LH(lambda,K,Q,AH,BH,AN,BN)/LN(lambda,K,Q,AH,BH,AN,BN)
wLHLN_1  = LHLN*( (wLH_1/LH) - (wLN_1/LN) );
wLHLN_AH = LHLN*( (wLH_AH/LH) - (wLN_AH/LN) );
wLHLN_BH = LHLN*( (wLH_BH/LH) - (wLN_BH/LN) );
wLHLN_AN = LHLN*( (wLH_AN/LH) - (wLN_AN/LN) );
wLHLN_BN = LHLN*( (wLH_BN/LH) - (wLN_BN/LN) );

% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(lambda,K,Q,AH,BH,AN,BN)
wYHS_1   = omegaYHR*( (wYH_1/YH) - (wYR_1/YR) );
wYHS_AH  = omegaYHR*( (wYH_AH/YH) - (wYR_AH/YR) );
wYHS_BH  = omegaYHR*( (wYH_BH/YH) - (wYR_BH/YR) );
wYHS_AN  = omegaYHR*( (wYH_AN/YH) - (wYR_AN/YR) );
wYHS_BN  = omegaYHR*( (wYH_BN/YH) - (wYR_BN/YR) );

wYNS_1   = omegaYNR*( (wYN_1/YN) - (wYR_1/YR) );
wYNS_AH  = omegaYNR*( (wYN_AH/YN) - (wYR_AH/YR) );
wYNS_BH  = omegaYNR*( (wYN_BH/YN) - (wYR_BH/YR) );
wYNS_AN  = omegaYNR*( (wYN_AN/YN) - (wYR_AN/YR) );
wYNS_BN  = omegaYNR*( (wYN_BN/YN) - (wYR_BN/YR) );

% Solutions for the employment shares Lj/L=(Lj/L)(lambda,K,Q,AH,BH,AN,BN)
wLHS_1   = omegaLH*((wLH_1/LH)-(wL_1/L));
wLHS_AH  = omegaLH*((wLH_AH/LH)-(wL_AH/L));
wLHS_BH  = omegaLH*((wLH_BH/LH)-(wL_BH/L));
wLHS_AN  = omegaLH*((wLH_AN/LH)-(wL_AN/L));
wLHS_BN  = omegaLH*((wLH_BN/LH)-(wL_BN/L));

wLNS_1   = omegaLN*((wLN_1/LN)-(wL_1/L));
wLNS_AH  = omegaLN*((wLN_AH/LN)-(wL_AH/L));
wLNS_BH  = omegaLN*((wLN_BH/LN)-(wL_BH/L));
wLNS_AN  = omegaLN*((wLN_AN/LN)-(wL_AN/L));
wLNS_BN  = omegaLN*((wLN_BN/LN)-(wL_BN/L));

% Solutions for the employment shares sLj=LISj(lambda,K,Q,AH,BH,AN,BN) -
% sLj = Wj*Lj/(Pj*Yj) - 

wLISH_1  = -((sigmaH-1)/sigmaH)*(1-sLH)*sLH*(wkH_1/kH); 
wLISH_AH =  ((sigmaH-1)/sigmaH)*(1-sLH)*sLH*( (1/AH) - (wkH_AH/kH) ); 
wLISH_BH = -((sigmaH-1)/sigmaH)*(1-sLH)*sLH*( (1/BH) + (wkH_BH/kH) );
wLISH_AN = -((sigmaH-1)/sigmaH)*(1-sLH)*sLH*(wkH_AN/kH); 
wLISH_BN = -((sigmaH-1)/sigmaH)*(1-sLH)*sLH*(wkH_BN/kH);

wLISN_1  = -((sigmaN-1)/sigmaN)*(1-sLN)*sLN*(wkN_1/kN);                     
wLISN_AH = -((sigmaN-1)/sigmaN)*(1-sLN)*sLN*(wkN_AH/kN);        
wLISN_BH = -((sigmaN-1)/sigmaN)*(1-sLN)*sLN*(wkN_BH/kN);        
wLISN_AN =  ((sigmaN-1)/sigmaN)*(1-sLN)*sLN*( (1/AN) - (wkN_AN/kN) );                    
wLISN_BN = -((sigmaN-1)/sigmaN)*(1-sLN)*sLN*( (1/BN) + (wkN_BN/kN) );                    

% Transitional Paths 
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdZH0    = (ZH_0 - ZH_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathdZ0     = (Z_0 - Z_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdLHL0   = (LN_0 - LN_0) + 0*time0;
pathdLNL0   = (LH_0 - LH_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWH0    = (WH_0 - WH_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYHYN0  = (YHYN_0 - YHYN_0) + 0*time0;
pathdLHLN0  = (LHLN_0 - LHLN_0) + 0*time0;
pathdIHY0   = (IN_0 - IN_0) + 0*time0;
pathdINY0   = (IH_0 - IH_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0;  
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLISH0  = (sLH_0 - sLH_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..10]
V1           = D1*exp(nu_1*time1); 
VAH          = aAH*exp(-xiAH*time1);
VBH          = aBH*exp(-xiBH*time1);
VAN          = aAN*exp(-xiAN*time1);
VBN          = aBN*exp(-xiBN*time1);
%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pathdAH1     = (( (AH_deu-AH_0) +  VAH )/AH_0)*100;
pathdBH1     = (( (BH_deu-BH_0) +  VBH )/BH_0)*100;
pathdAN1     = (( (AN_deu-AN_0) +  VAN )/AN_0)*100;
pathdBN1     = (( (BN_deu-BN_0) +  VBN )/BN_0)*100;
pathdZH1     = ( sLH_0*(( (AH_deu-AH_0) +  VAH )/AH_0) + (1-sLH_0)*(( (BH_deu-BH_0) +  VBH )/BH_0) )*100;
pathdZN1     = ( sLN_0*(( (AN_deu-AN_0) +  VAN )/AN_0) + (1-sLN_0)*(( (BN_deu-BN_0) +  VBN )/BN_0) )*100;
pathdZ1      = ( a*( sLH_0*(( (AH_deu-AH_0) +  VAH )/AH_0) + (1-sLH_0)*(( (BH_deu-BH_0) +  VBH )/BH_0) ) - b*( sLN_0*(( (AN_deu-AN_0) +  VAN )/AN_0) + (1-sLN_0)*(( (BN_deu-BN_0) +  VBN )/BN_0) ) )*100;
 
pathdQ1      = (((PI_deu-PI_0) + (omega_21*V1) + (omega_23*VAH) + (omega_24*VBH) + (omega_25*VAN) + (omega_26*VBN) )/PI_0)*100;
pathdPH1     = (((PH_deu-PH_0) + (wPH_1*V1) + (wPH_AH*VAH) + (wPH_BH*VBH) + (wPH_AN*VAN) + (wPH_BN*VBN) )/PH_0)*100;
pathdPN1     = (((PN_deu-PN_0) + (wPN_1*V1) + (wPN_AH*VAH) + (wPN_BH*VBH)+ (wPN_AN*VAN) + (wPN_BN*VBN) )/PN_0)*100;
pathdP1      = (((P_deu-P_0) + (wP_1*V1) + (wP_AH*VAH) + (wP_BH*VBH) + (wP_AN*VAN) + (wP_BN*VBN) )/P_0)*100;
pathCY1      = ( PC_0*((C_deu-C_0) + (wC_1*V1) + (wC_AH*VAH) + (wC_BH*VBH) + (wC_AN*VAN) + (wC_BN*VBN) )/Y_0 )*100;
pathdQPI1    = ( (wQPI_1*V1) + (wQPI_AH*VAH) + (wQPI_BH*VBH) + (wQPI_AN*VAN) + (wQPI_BN*VBN) )*100;
pathdL1      = (((L_deu-L_0)  + (wL_1*V1) + (wL_AH*VAH) + (wL_BH*VBH) + (wL_AN*VAN) + (wL_BN*VBN) )/L_0)*100;
pathdLHL1    = ( (1-alphaL_0)*((LH_deu-LH_0) + (wLH_1*V1) + (wLH_AH*VAH) + (wLH_BH*VBH) + (wLH_AN*VAN) + (wLH_BN*VBN) )/LH_0)*100;
pathdLNL1    = ( alphaL_0*((LN_deu-LN_0) + (wLN_1*V1) + (wLN_AH*VAH) + (wLN_BH*VBH) + (wLN_AN*VAN) + (wLN_BN*VBN) )/LN_0)*100;
pathdkHK1    = ( LH_0*((kH_deu-kH_0) + (wkH_1*V1) + (wkH_AH*VAH) + (wkH_BH*VBH) + (wkH_AN*VAN) + (wkH_BN*VBN) )/K_0)*100;
pathdkNK1    = ( LN_0*((kN_deu-kN_0) + (wkN_1*V1) + (wkN_AH*VAH) + (wkN_BH*VBH) + (wkN_AN*VAN) + (wkN_BN*VBN) )/K_0)*100;
pathdW1      = (((W_deu-W_0) + (wW_1*V1) + (wW_AH*VAH) + (wW_BH*VBH) + (wW_AN*VAN) + (wW_BN*VBN) )/W_0)*100;
pathdR1      = (((RK_deu-RK_0) + (wR_1*V1) + (wR_AH*VAH) + (wR_BH*VBH) + (wR_AN*VAN) + (wR_BN*VBN) )/RK_0)*100;
pathdWPC1    = (((WPC_deu-WPC_0) + (wWPC_1*V1) + (wWPC_AH*VAH) + (wWPC_BH*VBH) + (wWPC_AN*VAN) + (wWPC_BN*VBN) )/WPC_0)*100;
pathdY1      = (((Y_deu-Y_0) + (wY_1*V1) + (wY_AH*VAH) + (wY_BH*VBH) + (wY_AN*VAN) + (wY_BN*VBN) )/Y_0)*100;
pathdYR1     = (((YR_deu-Y_0) + (wYR_1*V1) + (wYR_AH*VAH) + (wYR_BH*VBH) + (wYR_AN*VAN) + (wYR_BN*VBN) )/Y_0)*100;
pathdYHY1    = (PH_0*((YH_deu-YH_0) + (wYH_1*V1) + (wYH_AH*VAH) + (wYH_BH*VBH)  + (wYH_AN*VAN) + (wYH_BN*VBN) )/Y_0)*100;
pathdYNY1    = (PN_0*((YN_deu-YN_0) + (wYN_1*V1) + (wYN_AH*VAH) + (wYN_BH*VBH) + (wYN_AN*VAN) + (wYN_BN*VBN) )/Y_0)*100;
pathdWH1     = (((WH_deu-WH_0) + (wWH_1*V1) + (wWH_AH*VAH) + (wWH_BH*VBH) + (wWH_AN*VAN) + (wWH_BN*VBN) )/WH_0)*100;
pathdWN1     = (((WN_deu-WN_0) + (wWN_1*V1) + (wWN_AH*VAH) + (wWN_BH*VBH) + (wWN_AN*VAN) + (wWN_BN*VBN) )/WN_0)*100;
pathdWHPC1   = (((WHPC_deu-WHPC_0) + (wWHPC_1*V1) + (wWHPC_AH*VAH) + (wWHPC_BH*VBH) + (wWHPC_AN*VAN) + (wWHPC_BN*VBN) )/WHPC_0)*100;
pathdWNPC1   = (((WNPC_deu-WNPC_0) + (wWNPC_1*V1) + (wWNPC_AH*VAH) + (wWNPC_BH*VBH) + (wWNPC_AN*VAN) + (wWNPC_BN*VBN) )/WNPC_0)*100;

pathCAY1     = (( -(nu_1*wB1*V1) + (xiAH*wBAH*VAH) + (xiBH*wBBH*VBH)  + (xiAN*wBAN*VAN) + (xiBN*wBBN*VBN) )/Y_0 )*100;
pathSY1      = (( -(nu_1*wA1*V1) + (xiAH*wAAH*VAH) + (xiBH*wABH*VBH)  + (xiAN*wAAN*VAN) + (xiBN*wABN*VBN) )/Y_0 )*100;
pathIY1      = (( (nu_1*EK_1*V1) - (xiAH*EK_AH*VAH) - (xiBH*EK_BH*VBH) - (xiAN*EK_AN*VAN) - (xiBN*EK_BN*VBN) )/Y_0)*100;

pathdOmega1  = (((Omega_deu-Omega_0) + (wOmega_1*V1) + (wOmega_AH*VAH) + (wOmega_BH*VBH) + (wOmega_AN*VAN) + (wOmega_BN*VBN) )/Omega_0)*100;
pathdYHYN1   = (PH_0/PN_0)*( (YHYN_deu-YHYN_0) + (wYHYN_1*V1) + (wYHYN_AH*VAH) + (wYHYN_BH*VBH) + (wYHYN_AN*VAN) + (wYHYN_BN*VBN) )*100;
pathdLHLN1   = (WH_0/WN_0)*( (LHLN_deu-LHLN_0) + (wLHLN_1*V1) + (wLHLN_AH*VAH) + (wLHLN_BH*VBH) + (wLHLN_AN*VAN) + (wLHLN_BN*VBN) )*100;
pathdLHS1    = (1-alphaL_0)*(( (omegaLH_deu-omegaLH_0) + (wLHS_1*V1) + (wLHS_AH*VAH) + (wLHS_BH*VBH) + (wLHS_AN*VAN) + (wLHS_BN*VBN) )/omegaLH_0)*100;
pathdLNS1    = alphaL_0*(( (omegaLN_deu-omegaLN_0) + (wLNS_1*V1) + (wLNS_AH*VAH) + (wLNS_BH*VBH) + (wLNS_AN*VAN) + (wLNS_BN*VBN) )/omegaLN_0)*100;
pathdYHS1    = ( (omegaYHR_deu-omegaYH_0) + (wYHS_1*V1) + (wYHS_AH*VAH) + (wYHS_BH*VBH) + (wYHS_AN*VAN) + (wYHS_BN*VBN) )*100;
pathdYNS1    = ( (omegaYNR_deu-omegaYN_0) + (wYNS_1*V1) + (wYNS_AH*VAH) + (wYNS_BH*VBH) + (wYNS_AN*VAN) + (wYNS_BN*VBN) )*100;
pathdLISH1   = ( (sLH_deu-sLH_0) + (wLISH_1*V1) + (wLISH_AH*VAH) + (wLISH_BH*VBH) + (wLISH_AN*VAN) + (wLISH_BN*VBN) )*100;
pathdLISN1   = ( (sLN_deu-sLN_0) + (wLISN_1*V1) + (wLISN_AH*VAH) + (wLISN_BH*VBH) + (wLISN_AN*VAN) + (wLISN_BN*VBN) )*100;
 
% Temporal paths over entire period
timetemp = [time0 time1];
pathdZH_deu    = [pathdZH0  pathdZH1];
pathdZN_deu    = [pathdZN0  pathdZN1];
pathdZ_deu     = [pathdZ0   pathdZ1];
pathdQ_deu     = [pathdQ0  pathdQ1];
pathdQPI_deu   = [pathdQ0  pathdQPI1];
pathdPH_deu    = [pathdP0  pathdPH1];
pathdPN_deu    = [pathdP0  pathdPN1];
pathdP_deu     = [pathdP0  pathdP1]; 
pathCY_deu     = [pathCY0  pathCY1];                                             
pathdL_deu     = [pathdL0  pathdL1];                
pathdLHL_deu   = [pathdLHL0 pathdLHL1];             
pathdLNL_deu   = [pathdLNL0 pathdLNL1]; 
pathdkHK_deu   = [pathdLHL0 pathdkHK1];             
pathdkNK_deu   = [pathdLNL0 pathdkNK1]; 
pathdW_deu     = [pathdW0 pathdW1]; 
pathdR_deu     = [pathdR0 pathdR1]; 
pathdWPC_deu   = [pathdWPC0 pathdWPC1]; 
pathdY_deu     = [pathdY0 pathdY1]; 
pathdYR_deu    = [pathdY0 pathdYR1];
pathdYHY_deu   = [pathdY0 pathdYHY1];               
pathdYNY_deu   = [pathdY0 pathdYNY1];               
pathdWH_deu    = [pathdWH0  pathdWH1];              
pathdWN_deu    = [pathdWN0  pathdWN1]; 
pathdWHPC_deu  = [pathdWH0 pathdWHPC1];
pathdWNPC_deu  = [pathdWN0 pathdWNPC1];

pathIY_deu     = [pathIY0  pathIY1];                        
pathCAY_deu    = [pathCAY0 pathCAY1];               
pathSY_deu     = [pathSY0  pathSY1];

pathdOmega_deu = [pathdOmega0 pathdOmega1];         
pathdYHYN_deu  = [pathdYHYN0 pathdYHYN1];           
pathdLHLN_deu  = [pathdLHLN0 pathdLHLN1];
pathdLHS_deu   = [pathdLHL0 pathdLHS1];             
pathdLNS_deu   = [pathdLNL0 pathdLNS1];
pathdYHS_deu   = [pathdY0 pathdYHS1];             
pathdYNS_deu   = [pathdY0 pathdYNS1];
pathdLISH_deu  = [pathdLISH0 pathdLISH1];             
pathdLISN_deu  = [pathdLISN0 pathdLISN1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZH/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Impact Effects of an Unanticipated Rise in dZH(0) = aH and dZN(0) = aN
V10           = D1; 
VAH0          = aAH;
VBH0          = aBH;
VAN0          = aAN;
VBN0          = aBN;

pathAHtime0     = AH_deu +  VAH0;   % initial level of AH in home traded sector   
pathBHtime0     = BH_deu +  VBH0;   % initial level of BH in home traded sector   
pathANtime0     = AN_deu +  VAN0;   % initial level of AN in non traded sector    
pathBNtime0     = BN_deu +  VBN0;   % initial level of BN in non traded sector  

pathQtime0      = PI_deu + (omega_21*V10) + (omega_23*VAH0) + (omega_24*VBH0) + (omega_25*VAN0) + (omega_26*VBN0);  % initial level of the shadow value of investment            
pathCtime0      = C_deu + (wC_1*V10) + (wC_AH*VAH0) + (wC_BH*VBH0) + (wC_AN*VAN0) + (wC_BN*VBN0);  % initial level of real consumption                                           
pathLtime0      = L_deu  + (wL_1*V10) + (wL_AH*VAH0) + (wL_BH*VBH0) + (wL_AN*VAN0) + (wL_BN*VBN0); % initial level of employment                                                 
pathLHtime0     = LH_deu + (wLH_1*V10) + (wLH_AH*VAH0) + (wLH_BH*VBH0) + (wLH_AN*VAN0) + (wLH_BN*VBN0);  % initial level of employment in sector H                               
pathLNtime0     = LN_deu + (wLN_1*V10) + (wLN_AH*VAH0) + (wLN_BH*VBH0) + (wLN_AN*VAN0) + (wLN_BN*VBN0);  % initial level of employment in sector N                               
pathPHtime0     = PH_deu + (wPH_1*V10) + (wPH_AH*VAH0) + (wPH_BH*VBH0) + (wPH_AN*VAN0) + (wPH_BN*VBN0);  % initial level of  PH                                                  
pathPNtime0     = PN_deu + (wPN_1*V10) + (wPN_AH*VAH0) + (wPN_BH*VBH0) + (wPN_AN*VAN0) + (wPN_BN*VBN0);  % initial level of  PN                                                  
pathPtime0      = P_deu + (wP_1*V10) + (wP_AH*VAH0) + (wP_BH*VBH0) + (wP_AN*VAN0) + (wP_BN*VBN0);        % initial level of  PN/PH                                               
pathWtime0      = W_deu + (wW_1*V10) + (wW_AH*VAH0) + (wW_BH*VBH0) + (wW_AN*VAN0) + (wW_BN*VBN0);        % initial level of the wage rate                                        
pathWPCtime0    = WPC_deu + (wWPC_1*V10) + (wWPC_AH*VAH0) + (wWPC_BH*VBH0) + (wWPC_AN*VAN0) + (wWPC_BN*VBN0);            % initial level of W/PC                                 
pathYtime0      = Y_deu + (wY_1*V10) + (wY_AH*VAH0) + (wY_BH*VBH0) + (wY_AN*VAN0) + (wY_BN*VBN0);         % initial level of Y                                                   
pathYRtime0     = YR_deu + (wYR_1*V10) + (wYR_AH*VAH0) + (wYR_BH*VBH0) + (wYR_AN*VAN0) + (wYR_BN*VBN0);   % initial level of Y once non tradable inflation is controlled for     
pathYHtime0     = YH_deu + (wYH_1*V10) + (wYH_AH*VAH0) + (wYH_BH*VBH0)  + (wYH_AN*VAN0) + (wYH_BN*VBN0);  % initial level of YH                                                  
pathYNtime0     = YN_deu + (wYN_1*V10) + (wYN_AH*VAH0) + (wYN_BH*VBH0) + (wYN_AN*VAN0) + (wYN_BN*VBN0);   % initial level of YN                                                  
pathWHtime0     = WH_deu + (wWH_1*V10) + (wWH_AH*VAH0) + (wWH_BH*VBH0) + (wWH_AN*VAN0) + (wWH_BN*VBN0);    % initial level of WH                                                 
pathWNtime0     = WN_deu + (wWN_1*V10) + (wWN_AH*VAH0) + (wWN_BH*VBH0) + (wWN_AN*VAN0) + (wWN_BN*VBN0);    % initial level of WN                                                 
pathWHPCtime0   = WHPC_deu + (wWHPC_1*V10) + (wWHPC_AH*VAH0) + (wWHPC_BH*VBH0) + (wWHPC_AN*VAN0) + (wWHPC_BN*VBN0);  % initial level of WHPC                                     
pathWNPCtime0   = WNPC_deu + (wWNPC_1*V10) + (wWNPC_AH*VAH0) + (wWNPC_BH*VBH0) + (wWNPC_AN*VAN0) + (wWNPC_BN*VBN0);  % initial level of WNPC        
pathdkHKtime0   = kH_deu + (wkH_1*V10) + (wkH_AH*VAH0) + (wkH_BH*VBH0) + (wkH_AN*VAN0) + (wkH_BN*VBN0);
pathdkNKtime0   = kN_deu + (wkN_1*V10) + (wkN_AH*VAH0) + (wkN_BH*VBH0) + (wkN_AN*VAN0) + (wkN_BN*VBN0);
                                                                                                                                                                                  
pathOmegatime0  = Omega_deu + (wOmega_1*V10) + (wOmega_AH*VAH0) + (wOmega_BH*VBH0) + (wOmega_AN*VAN0) + (wOmega_BN*VBN0);    % initial level of the sector wage ratio            
pathYHYNtime0   = YHYN_deu + (wYHYN_1*V10) + (wYHYN_AH*VAH0) + (wYHYN_BH*VBH0) + (wYHYN_AN*VAN0) + (wYHYN_BN*VBN0);    % initial level of ratio YH/YN                           
pathLHLNtime0   = LHLN_deu + (wLHLN_1*V10) + (wLHLN_AH*VAH0) + (wLHLN_BH*VBH0) + (wLHLN_AN*VAN0) + (wLHLN_BN*VBN0);    % initial level of ratio LH/LN                           
                                                                                                                                                                                    
pathLHStime0    = omegaLH_deu + (wLHS_1*V10) + (wLHS_AH*VAH0) + (wLHS_BH*VBH0) + (wLHS_AN*VAN0) + (wLHS_BN*VBN0);  % Home traded labor share                                     
pathLNStime0    = omegaLN_deu + (wLNS_1*V10) + (wLNS_AH*VAH0) + (wLNS_BH*VBH0) + (wLNS_AN*VAN0) + (wLNS_BN*VBN0);  % Non traded labor share                                      
pathYHStime0    = omegaYHR_deu + (wYHS_1*V10) + (wYHS_AH*VAH0) + (wYHS_BH*VBH0) + (wYHS_AN*VAN0) + (wYHS_BN*VBN0); % Home traded output share                                    
pathYNStime0    = omegaYNR_deu + (wYNS_1*V10) + (wYNS_AH*VAH0) + (wYNS_BH*VBH0) + (wYNS_AN*VAN0) + (wYNS_BN*VBN0); % Non traded output share                                     
                                                                                                                                                                                    
pathLISHtime0   = sLH_deu + (wLISH_1*V10) + (wLISH_AH*VAH0) + (wLISH_BH*VBH0) + (wLISH_AN*VAN0) + (wLISH_BN*VBN0);  % Home traded labor income share                             
pathLISNtime0   = sLN_deu + (wLISN_1*V10) + (wLISN_AH*VAH0) + (wLISN_BH*VBH0) + (wLISN_AN*VAN0) + (wLISN_BN*VBN0);  % Non traded labor income share                              
                                                                                                                                                                                                                                                                                                                                       
dAHtime0_deu      = ((pathAHtime0 - AH_0)/AH_0)*100;  % initial response of AH in the home traded sector
dBHtime0_deu      = ((pathBHtime0 - BH_0)/BH_0)*100;  % initial response of BH in the home traded sector
dANtime0_deu      = ((pathANtime0 - AN_0)/AN_0)*100;  % initial response of AN in the non traded sector
dBNtime0_deu      = ((pathBNtime0 - BN_0)/BN_0)*100;  % initial response of BN in the non traded sector
dDHtime0_deu      =  dBHtime0_deu - dAHtime0_deu;   % initial response of technological change biased toward KH relative to LH
dDNtime0_deu      =  dBNtime0_deu - dANtime0_deu;   % initial response of technological change biased toward KN relative to LN
dZHtime0_deu      = (sLH_0*((pathAHtime0 - AH_0)/AH_0) + (1-sLH_0)*((pathBHtime0 - BH_0)/BH_0))*100;  % initial response of TFP in the home traded sector
dZNtime0_deu      = (sLN_0*((pathANtime0 - AN_0)/AN_0) + (1-sLN_0)*((pathBNtime0 - BN_0)/BN_0))*100;  % initial response of TFP in the non traded sector
dZtime0_deu       = (a*dZHtime0_deu) - (b*dZNtime0_deu);  % initial response of the productivity differential
dCYtime0_deu      = (PC_0*(pathCtime0 - C_0)/Y_0)*100;  % initial response of real consumption 
dLtime0_deu       = ((pathLtime0 - L_0)/L_0)*100; % initial response of employment
dLHtime0_deu      = ((1-alphaL_0)*(pathLHtime0 - LH_0)/LH_0)*100; % initial response of employment in sector H 
dLNtime0_deu      = (alphaL_0*(pathLNtime0 - LN_0)/LN_0)*100; % initial response of employment in sector N 
dLHLNtime0_deu    = (WH_0/WN_0)*(pathLHLNtime0 - LHLN_0)*100; % initial response of ratio LH/LN 
dPHtime0_deu      = ((pathPHtime0 - PH_0)/PH_0)*100; % initial response of PH
dPNtime0_deu      = ((pathPNtime0 - PN_0)/PN_0)*100; % initial response of PN
dPtime0_deu       = ((pathPtime0 - P_0)/P_0)*100; % initial response of PN/PH
dWtime0_deu       = ((pathWtime0 - W_0)/W_0)*100; % initial response of W 
dWPCtime0_deu     = ((pathWPCtime0 - WPC_0)/WPC_0)*100; % initial response of W/PC 
dYtime0_deu       = ((pathYtime0 - Y_0)/Y_0)*100; % initial response of Y
dYRtime0_deu      = ((pathYRtime0 - Y_0)/Y_0)*100; % initial response of real GDP 
dYHtime0_deu      = (PH_0*(pathYHtime0 - YH_0)/Y_0)*100; % initial response of YH
dYNtime0_deu      = (PN_0*(pathYNtime0 - YN_0)/Y_0)*100; % initial response of YN
dYHYNtime0_deu    = (PH_0/PN_0)*((pathYHYNtime0 - YHYN_0))*100; % initial response of ratio YH/YN 
dWHtime0_deu      = ((pathWHtime0 - WH_0)/WH_0)*100; % initial response of wage in sector H 
dWNtime0_deu      = ((pathWNtime0 - WN_0)/WN_0)*100; % initial response of wage in sector N 
dWHPCtime0_deu    = ((pathWHPCtime0 - WHPC_0)/WHPC_0)*100; % initial response of real wage in sector H 
dWNPCtime0_deu    = ((pathWNPCtime0 - WNPC_0)/WNPC_0)*100; % initial response of real wage in sector N 
dOmegatime0_deu   = ((pathOmegatime0 - Omega_0)/Omega_0)*100; % initial response of the sector wage ratio
dkHKtime0_deu     = (LH_0*(pathdkHKtime0-kH_0)/K_0)*100;
dkNKtime0_deu     = (LN_0*(pathdkNKtime0-kN_0)/K_0)*100;

dCAYtime0_deu     = (( -(nu_1*wB1*V10) + (xiAH*wBAH*VAH0) + (xiBH*wBBH*VBH0)  + (xiAN*wBAN*VAN0) + (xiBN*wBBN*VBN0) )/Y_0 )*100;   % initial response of current account dot{B}(0)
dSYtime0_deu      = (( -(nu_1*wA1*V10) + (xiAH*wAAH*VAH0) + (xiBH*wABH*VBH0)  + (xiAN*wAAN*VAN0) + (xiBN*wABN*VBN0) )/Y_0 )*100;   % initial response of saving dot{A}(0)
dIYtime0_deu      = (( (nu_1*EK_1*V10) - (xiAH*EK_AH*VAH0) - (xiBH*EK_BH*VBH0) - (xiAN*EK_AN*VAN0) - (xiBN*EK_BN*VBN0) )/Y_0)*100; % initial response of investment dot{Q*K}(0)

dCAYtime0_deu_check = dSYtime0_deu - dIYtime0_deu; 

dLHStime0_deu     = ((pathLHStime0-omegaLH_0)/omegaLH_0)*(1-alphaL_0)*100; % Initial response of LH/L
dLNStime0_deu     = ((pathLNStime0-omegaLN_0)/omegaLN_0)*alphaL_0*100; % Initial response of LN/L
dYHStime0_deu     = (pathYHStime0-omegaYH_0)*100; % Initial response of YH/Y
dYNStime0_deu     = (pathYNStime0-omegaYN_0)*100; % Initial response of YN/Y
dLISHtime0_deu    = (pathLISHtime0-sLH_0)*100; % Initial response of WH*LH/(PH*YH)
dLISNtime0_deu    = (pathLISNtime0-sLN_0)*100; % Initial response of WN*LN/(PN*YN)
dLISHtime0_growth_deu  = ((pathLISHtime0-sLH_0)/sLH_0)*100; % Initial response of WH*LH/(PH*YH) in growth rate
dLISNtime0_growth_deu  = ((pathLISNtime0-sLN_0)/sLN_0)*100; % Initial response of WN*LN/(PN*YN) in growth rate

hatkHtime0_deu    = ((pathdkHKtime0-kH_0)/kH_0)*100;
hatkNtime0_deu    = ((pathdkNKtime0-kN_0)/kN_0)*100;
hatSHtime0_deu    = ((pathLISHtime0-sLH_0)/(sLH_0*(1-sLH_0)))*100; % Initial response of sLH/(1-sLH) in growth rate
hatSNtime0_deu    = ((pathLISNtime0-sLN_0)/(sLN_0*(1-sLN_0)))*100; % Initial response of sLN/(1-sLN) in growth rate

% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_deu       = (dlambda/lambda_0)*100; 
dCoverY_deu         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
hatZN_deu           = (dZN/ZN_0)*100; % Rate of change of the TFP in the non traded sector
hatZH_deu           = (dZH/ZH_0)*100; % Rate of change of the TFP in the traded sector
hatDH_deu           =  ((dBH/BH_0) - (dAH/AH_0))*100;   % Long-run change of technological progress biased toward KH relative to LH
hatDN_deu           =  ((dBN/BN_0) - (dAN/AN_0))*100;   % Long-run change of technological progress biased toward KN relative to LN
hatZ_deu            = (a*(dZH/ZH_0) - b*(dZN/ZN_0)); % Rate of change of the productivity differential
hatL_deu            = (dL/L_0)*100; % Rate of change of employment
hatK_deu            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLHoverL_deu        = (dLH/LH_0)*(1-alphaL_0)*100; % Rate of change of LH
dLNoverL_deu        = (dLN/LN_0)*alphaL_0*100; % Rate of change of LN
dLHLN_deu           =  dLHLN*100; %  Change of LH/LN
hatPH_deu           = (dPH/PH_0)*100; % Rate of change of PH
hatPN_deu           = (dPN/PN_0)*100; % Rate of change of PN
hatP_deu            = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_deu         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_deu         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_deu            = (dW/W_0)*100; % Rate of change of wage
hatWPC_deu          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_deu            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_deu           = ((YR_deu-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYHoverY_deu        = (PH_0*dYH/Y_0)*100; % Rate of change of YH
dYNoverY_deu        = (PN_0*dYN/Y_0)*100; % Rate of change of YN
dYHYN_deu           = (dYHYN)*100; % Rate of change of YH/YN
hatWH_deu           = (dWH/WH_0)*100; % Rate of change of WH
hatWN_deu           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_deu        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWHPC_deu         = (dWHPC/WHPC_0)*100; % Rate of change of WH/PC
hatWNPC_deu         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkH_deu             = LH_0*(dkH/K_0)*100; % Rate of change of kH
dkN_deu             = LN_0*(dkN/K_0)*100; % Rate of change of kN
domegaLH_deu        = ((omegaLH_deu-omegaLH_0)/omegaLH_0)*(1-alphaL_0)*100; % change in  the labor share of T
domegaLN_deu        = ((omegaLN_deu-omegaLN_0)/omegaLN_0)*alphaL_0*100; % change in the labor share of NT
domegaYHS_deu       = (omegaYHR_deu-omegaYH_0)*100; % change in the output share of T
domegaYNS_deu       = (omegaYNR_deu-omegaYN_0)*100; % change in the output share of NT
dLISH_growth_deu    = ((sLH_deu-sLH_0)/sLH_0)*100; % Long-Run Change in WH*LH/(PH*YH) in growth rate
dLISN_growth_deu    = ((sLN_deu-sLN_0)/sLN_0)*100; % Long-Run Change in WN*LN/(PN*YN) in growth rate
dLISH_deu           = (sLH_deu-sLH_0)*100; % Long-Run Change in WH*LH/(PH*YH)
dLISN_deu           = (sLN_deu-sLN_0)*100; % Long-Run Change in WN*LN/(PN*YN)

hatkH_deu           = (dkH/kH_0)*100; % Rate of change of kH
hatkN_deu           = (dkN/kN_0)*100; % Rate of change of kN
hatSH_deu           = ((sLH_deu-sLH_0)/(sLH_0*(1-sLH_0)))*100; % Long-Run Change in sLH/(1-sLH) 
hatSN_deu           = ((sLN_deu-sLN_0)/(sLN_0*(1-sLN_0)))*100; % Long-Run Change in sLN/(1-sLN) 

disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp('The structural parameters (benchmark)');
disp(sprintf('sigmaH  : %5.2f   gammaH   : %5.2f',sigmaH,gammaH));
disp(sprintf('sigmaN  : %5.2f   gammaN   : %5.2f',sigmaN,gammaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('AH      : %5.2f   BH       : %5.2f',AH,BH));
disp(sprintf('AN      : %5.2f   BN       : %5.2f',AN,BN));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GH      : %5.2f   GN       : %5.2f',GH,GN));
disp(sprintf('GF      : %5.2f   G        : %5.2f',GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f IF     : %9.3f',IH,IN,IF));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('Sigma_AH  :  %5.4f  Sigma_AH  : %5.4f',Sigma_AH,Sigma_AH));
disp(sprintf('Sigma_AN  :  %5.4f  Sigma_AN  : %5.4f',Sigma_AN,Sigma_AN));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));
disp(sprintf('B_AH      :  %5.4f  B_BH      : %5.4f',B_AH,B_BH));
disp(sprintf('B_AN      :  %5.4f  B_BN      : %5.4f',B_AN,B_BN));
disp(sprintf('A_K       :  %5.4f  A_Q       : %5.4f',A_K,A_Q));
disp(sprintf('A_AH      :  %5.4f  A_BH      : %5.4f',A_AH,A_BH));
disp(sprintf('A_AN      :  %5.4f  A_BN      : %5.4f',A_AN,A_BN));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('nu3        :   %5.6f  nu4        : %5.6f',nu_3,nu_4));
disp(sprintf('nu5        :   %5.6f  nu6        : %5.6f',nu_5,nu_6));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));
disp(sprintf('TrJ1        :   %5.6f  DetJ1     : %5.6f',TrJ1,DetJ1));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));
disp(sprintf('omega13    :   %5.6f  omega14    : %5.6f',omega_13,omega_14));
disp(sprintf('omega15    :   %5.6f  omega16    : %5.6f',omega_15,omega_16));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega_21,omega_22));
disp(sprintf('omega23    :   %5.6f  omega24    : %5.6f',omega_23,omega_24));
disp(sprintf('omega25    :   %5.6f  omega26    : %5.6f',omega_25,omega_26));
disp(sprintf('omega31    :   %5.6f  omega32    : %5.6f',omega_31,omega_32));
disp(sprintf('omega33    :   %5.6f  omega34    : %5.6f',omega_33,omega_34));
disp(sprintf('omega35    :   %5.6f  omega36    : %5.6f',omega_35,omega_36));
disp(sprintf('omega41    :   %5.6f  omega42    : %5.6f',omega_41,omega_42));
disp(sprintf('omega43    :   %5.6f  omega44    : %5.6f',omega_43,omega_44));
disp(sprintf('omega45    :   %5.6f  omega46    : %5.6f',omega_45,omega_46));
disp(sprintf('omega51    :   %5.6f  omega52    : %5.6f',omega_51,omega_52));
disp(sprintf('omega53    :   %5.6f  omega54    : %5.6f',omega_53,omega_54));
disp(sprintf('omega55    :   %5.6f  omega56    : %5.6f',omega_55,omega_56));
disp(sprintf('omega61    :   %5.6f  omega62    : %5.6f',omega_61,omega_62));
disp(sprintf('omega63    :   %5.6f  omega64    : %5.6f',omega_63,omega_64));
disp(sprintf('omega65    :   %5.6f  omega66    : %5.6f',omega_65,omega_66));


disp('solutions at time t = 0 V10 X20');
disp(sprintf('V10       :   %5.3f  X20     : %5.3f VN0   : %5.3f',V10,VAH0,VBH0));
disp(sprintf('V10       :   %5.3f  X20',VAN0,VBN0));
disp(sprintf('D1        :   %5.3f  D3      : %5.3f D4    : %5.3f',D1,D3,D4));
disp(sprintf('D5        :   %5.3f  D6      : %5.3f',D5,D6));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PI*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));
disp(' ');
disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('omega_13 - omega13                : %9.16f   ',cond30));
disp(sprintf('omega_14 - omega14                : %9.16f   ',cond31));
disp(sprintf('omega_15 - omega15                : %9.16f   ',cond32));
disp(sprintf('omega_16 - omega16                : %9.16f   ',cond33));
disp(sprintf('omega_23 - omega23                : %9.16f   ',cond34));
disp(sprintf('omega_24 - omega24                : %9.16f   ',cond35));
disp(sprintf('omega_25 - omega25                : %9.16f   ',cond36));
disp(sprintf('omega_26 - omega26                : %9.16f   ',cond37));
disp(sprintf('nu_3 + xiAH                       : %9.16f   ',cond38));
disp(sprintf('nu_4 + xiBH                       : %9.16f   ',cond39));
disp(sprintf('nu_5 + xiAN                       : %9.16f   ',cond40));
disp(sprintf('nu_6 + xiBN                       : %9.16f   ',cond41));


disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_deu        :         |           |%10.3f',hatlambda_deu));
disp(sprintf('dZoverZ_deu          :         |           |%10.3f',hatZ_deu));
disp(sprintf('dZHoverZH_deu        :         |           |%10.3f',hatZH_deu));
disp(sprintf('dZNoverZN_deu        :         |           |%10.3f',hatZN_deu));
disp(sprintf('dDHoverDH_deu        :         |           |%10.3f',hatDH_deu));
disp(sprintf('dDNoverDN_deu        :         |           |%10.3f',hatDN_deu));
disp(sprintf('dCoverY_deu          :         |           |%10.3f',dCoverY_deu));
disp(sprintf('dLoverL_deu          :         |           |%10.3f',hatL_deu));
disp(sprintf('dYoverY_deu          :         |           |%10.3f',hatY_deu));
disp(sprintf('dYRoverY_deu         :         |           |%10.3f',hatYR_deu));
disp(sprintf('dKoverK_deu          :         |           |%10.3f',hatK_deu));
disp(sprintf('dLHoverL_deu         :         |           |%10.3f',dLHoverL_deu));
disp(sprintf('dLNover_deu          :         |           |%10.3f',dLNoverL_deu));
disp(sprintf('dLHLN_deu            :         |           |%10.3f',dLHLN_deu));
disp(sprintf('dYHoverY_deu         :         |           |%10.3f',dYHoverY_deu));
disp(sprintf('dYNoverY_deu         :         |           |%10.3f',dYNoverY_deu));
disp(sprintf('dYHYN_deu            :         |           |%10.3f',dYHYN_deu));
disp(sprintf('hatPH_deu            :         |           |%10.3f',hatPH_deu));
disp(sprintf('hatPN_deu            :         |           |%10.3f',hatPN_deu));
disp(sprintf('hatP_deu             :         |           |%10.3f',hatP_deu));
disp(sprintf('dBoverY_deu          :         |           |%10.3f',dBoverY_deu));
disp(sprintf('dAoverY_deu          :         |           |%10.3f',dAoverY_deu));
disp(sprintf('dWoverW_deu          :         |           |%10.3f',hatW_deu));
disp(sprintf('dWPCoverWPC_deu      :         |           |%10.3f',hatWPC_deu));
disp(sprintf('dWHoverWH_deu        :         |           |%10.3f',hatWH_deu));
disp(sprintf('dWNoverWN_deu        :         |           |%10.3f',hatWN_deu));
disp(sprintf('hatOmega_deu         :         |           |%10.3f',hatOmega_deu));
disp(sprintf('dWHPCoverWHPC_deu    :         |           |%10.3f',hatWHPC_deu));
disp(sprintf('dWNPCoverWNPC_deu    :         |           |%10.3f',hatWNPC_deu));
disp(sprintf('dkHoverK_deu         :         |           |%10.3f',dkH_deu));
disp(sprintf('dkNoverK_deu         :         |           |%10.3f',dkN_deu));
disp(sprintf('domegaLH_deu         :         |           |%10.3f',domegaLH_deu));
disp(sprintf('domegaLN_deu         :         |           |%10.3f',domegaLN_deu));
disp(sprintf('domegaYH_deu         :         |           |%10.3f',domegaYHS_deu));
disp(sprintf('domegaYN_deu         :         |           |%10.3f',domegaYNS_deu));
disp(sprintf('dLISH_deu            :         |           |%10.3f',dLISH_deu));
disp(sprintf('dLISN_deu            :         |           |%10.3f',dLISN_deu));
disp(sprintf('dLISH_growth_deu     :         |           |%10.3f',dLISH_growth_deu));
disp(sprintf('dLISN_growth_deu     :         |           |%10.3f',dLISN_growth_deu));

%disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dZtime0_deu         :                |                 |%10.3f',dZtime0_deu));
disp(sprintf('dDHtime0_deu        :                |                 |%10.3f',dDHtime0_deu));
disp(sprintf('dDNtime0_deu        :                |                 |%10.3f',dDNtime0_deu));
disp(sprintf('dZHtime0_deu        :                |                 |%10.3f',dZHtime0_deu));
disp(sprintf('dZNtime0_deu        :                |                 |%10.3f',dZNtime0_deu));
disp(sprintf('dCYtime0_deu        :                |                 |%10.3f',dCYtime0_deu));
disp(sprintf('dLtime0_deu         :                |                 |%10.3f',dLtime0_deu));
disp(sprintf('dLHtime0_deu        :                |                 |%10.3f',dLHtime0_deu));
disp(sprintf('dLNtime0_deu        :                |                 |%10.3f',dLNtime0_deu));
disp(sprintf('dLHLNtime0_deu      :                |                 |%10.3f',dLHLNtime0_deu));
disp(sprintf('dYtime0_deu         :                |                 |%10.3f',dYtime0_deu));
disp(sprintf('dYRtime0_deu        :                |                 |%10.3f',dYRtime0_deu));
disp(sprintf('dYHtime0_deu        :                |                 |%10.3f',dYHtime0_deu));
disp(sprintf('dYNtime0_deu        :                |                 |%10.3f',dYNtime0_deu));
disp(sprintf('dYHYNtime0_deu      :                |                 |%10.3f',dYHYNtime0_deu));
disp(sprintf('dPHtime0_deu        :                |                 |%10.3f',dPHtime0_deu));
disp(sprintf('dPNtime0_deu        :                |                 |%10.3f',dPNtime0_deu));
disp(sprintf('dPtime0_deu         :                |                 |%10.3f',dPtime0_deu));
disp(sprintf('dSYtime0_deu        :                |                 |%10.3f',dSYtime0_deu));
disp(sprintf('dIYtime0_deu        :                |                 |%10.3f',dIYtime0_deu));
disp(sprintf('dCAYtime0_deu       :                |                 |%10.5f',dCAYtime0_deu)); 
disp(sprintf('dCAYtime0_deu_check :                |                 |%10.5f',dCAYtime0_deu_check)); 
disp(sprintf('dWtime0_deu         :                |                 |%10.3f',dWtime0_deu));
disp(sprintf('dWPCtime0_deu       :                |                 |%10.3f',dWPCtime0_deu));
disp(sprintf('dWHtime0_deu        :                |                 |%10.3f',dWHtime0_deu));
disp(sprintf('dWNtime0_deu        :                |                 |%10.3f',dWNtime0_deu));
disp(sprintf('dOmegatime0_deu     :                |                 |%10.3f',dOmegatime0_deu));
disp(sprintf('dWHPCtime0_deu      :                |                 |%10.3f',dWHPCtime0_deu));
disp(sprintf('dWNPCtime0_deu      :                |                 |%10.3f',dWNPCtime0_deu));
disp(sprintf('dkHKtime0_deu       :                |                 |%10.3f',dkHKtime0_deu));
disp(sprintf('dkNKtime0_deu       :                |                 |%10.3f',dkNKtime0_deu));
disp(sprintf('dLHStime0_deu       :                |                 |%10.3f',dLHStime0_deu));
disp(sprintf('dLNStime0_deu       :                |                 |%10.3f',dLNStime0_deu));
disp(sprintf('dYHStime0_deu       :                |                 |%10.3f',dYHStime0_deu));
disp(sprintf('dYNStime0_deu       :                |                 |%10.3f',dYNStime0_deu));
disp(sprintf('dLISHtime0_deu      :                |                 |%10.3f',dLISHtime0_deu));
disp(sprintf('dLISNtime0_deu      :                |                 |%10.3f',dLISNtime0_deu));
disp(sprintf('dLISHtime0_growth    :                |                 |%10.3f',dLISHtime0_growth_deu));
disp(sprintf('dLISNtime0_growth    :                |                 |%10.3f',dLISNtime0_growth_deu));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f     PN*YN / Y  : %5.3f',omegaYH_0,omegaYN_0));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('PI*I / Y  :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f    GT/G     : %5.3f',omegaGH_0,omegaGF_0,omegaGT_0));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f',omegaINYN_0,omegaIHYH_0));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH_0,omegaGFYH_0));
disp(sprintf('WH*LH/PH*YH :  %5.3f WN*LN/PN*YN :  %5.3f',sLH_0,sLN_0));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('PT*IT/PI*I  :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH_0,alphaH_0));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH_0,omegaCH_0));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF_0,omegaCF_0));
disp(sprintf('PH*XH/Y     :  %5.3f    XH / YH  :  %5.3f',omegaXHY_0,omegaXHYH_0));
disp(sprintf('W*L/PN*Y    :  %5.3f R*K/PN*Y    :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y         :  %5.3f (r*B)/Y     :  %5.3f',omegaKY_0,omegaB_0));
