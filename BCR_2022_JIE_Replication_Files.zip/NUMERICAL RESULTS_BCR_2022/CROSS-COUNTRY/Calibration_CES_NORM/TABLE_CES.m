clc
clear

% Maximum duration for graphics
Tg = 10;
       
% Minimum duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

AUS_CES;  
AUT_CES;  
BEL_CES;  
CAN_CES;  
DEU_CES;  
DNK_CES;  
ESP_CES;  
FIN_CES;  
FRA_CES;  
GBR_CES;  
IRL_CES;  
ITA_CES;  
JPN_CES;  
NLD_CES;  
NOR_CES;  
SWE_CES;  
USA_CES;  
OECD_CES; 

disp('-------------------------------------------------------------------------------------------------------- ');
disp('    Increase in Z by 1%    ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');
disp(sprintf('dLISHtime0,dLISNtime0,dLISH,dLISN')); 
disp('Impact and Long-Run Responses of Labor income shares');
disp(sprintf('aus   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_aus,dLISNtime0_aus,dLISH_aus,dLISN_aus));
disp(sprintf('aut   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_aut,dLISNtime0_aut,dLISH_aut,dLISN_aut));
disp(sprintf('bel   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_bel,dLISNtime0_bel,dLISH_bel,dLISN_bel));
disp(sprintf('deu   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_can,dLISNtime0_can,dLISH_can,dLISN_can));
disp(sprintf('can   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_deu,dLISNtime0_deu,dLISH_deu,dLISN_deu));
disp(sprintf('dnk   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_dnk,dLISNtime0_dnk,dLISH_dnk,dLISN_dnk));
disp(sprintf('esp   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_esp,dLISNtime0_esp,dLISH_esp,dLISN_esp));
disp(sprintf('fin   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_fin,dLISNtime0_fin,dLISH_fin,dLISN_fin));
disp(sprintf('fra   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_fra,dLISNtime0_fra,dLISH_fra,dLISN_fra));
disp(sprintf('gbr   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_gbr,dLISNtime0_gbr,dLISH_gbr,dLISN_gbr));
disp(sprintf('irl   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_irl,dLISNtime0_irl,dLISH_irl,dLISN_irl));
disp(sprintf('ita   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_ita,dLISNtime0_ita,dLISH_ita,dLISN_ita));
disp(sprintf('jpn   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_jpn,dLISNtime0_jpn,dLISH_jpn,dLISN_jpn));
disp(sprintf('nld   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_nld,dLISNtime0_nld,dLISH_nld,dLISN_nld));
disp(sprintf('nor   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_nor,dLISNtime0_nor,dLISH_nor,dLISN_nor));
disp(sprintf('swe   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_swe,dLISNtime0_swe,dLISH_swe,dLISN_swe));
disp(sprintf('usa   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_usa,dLISNtime0_usa,dLISH_usa,dLISN_usa));
disp(sprintf('oecd  : |%10.3f | %10.3f  | %10.3f | %10.3f',dLISHtime0_oecd,dLISNtime0_oecd,dLISH_oecd,dLISN_oecd));
disp(' ');

disp(' '); disp('Impact and Long-Run Sectoral Techology Shocks');
disp(sprintf('dZHtime0,dZNtime0,dZH,dZN')); 
disp(sprintf('aus   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_aus,dZNtime0_aus,hatZH_aus,hatZN_aus));      
disp(sprintf('aut   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_aut,dZNtime0_aut,hatZH_aut,hatZN_aut));      
disp(sprintf('bel   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_bel,dZNtime0_bel,hatZH_bel,hatZN_bel));      
disp(sprintf('can   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_can,dZNtime0_can,hatZH_can,hatZN_can));      
disp(sprintf('deu   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_deu,dZNtime0_deu,hatZH_deu,hatZN_deu));      
disp(sprintf('dnk   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_dnk,dZNtime0_dnk,hatZH_dnk,hatZN_dnk));      
disp(sprintf('esp   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_esp,dZNtime0_esp,hatZH_esp,hatZN_esp));      
disp(sprintf('fin   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_fin,dZNtime0_fin,hatZH_fin,hatZN_fin));      
disp(sprintf('fra   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_fra,dZNtime0_fra,hatZH_fra,hatZN_fra));      
disp(sprintf('gbr   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_gbr,dZNtime0_gbr,hatZH_gbr,hatZN_gbr));      
disp(sprintf('irl   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_irl,dZNtime0_irl,hatZH_irl,hatZN_irl));      
disp(sprintf('ita   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_ita,dZNtime0_ita,hatZH_ita,hatZN_ita));      
disp(sprintf('jpn   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_jpn,dZNtime0_jpn,hatZH_jpn,hatZN_jpn));      
disp(sprintf('nld   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_nld,dZNtime0_nld,hatZH_nld,hatZN_nld));      
disp(sprintf('nor   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_nor,dZNtime0_nor,hatZH_nor,hatZN_nor));      
disp(sprintf('swe   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_swe,dZNtime0_swe,hatZH_swe,hatZN_swe));      
disp(sprintf('usa   : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_usa,dZNtime0_usa,hatZH_usa,hatZN_usa));      
disp(sprintf('oecd  : | %10.3f | %10.3f  | %10.3f | %10.3f',dZHtime0_oecd,dZNtime0_oecd,hatZH_oecd,hatZN_oecd));         
disp(' ');

disp(sprintf('dLHStime0,dLNStime0,dLHS,dLNS')); 
disp('Impact and Long-Run Responses of sectoral shares in total labor');
disp(sprintf('aus   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_aus,dLNStime0_aus,domegaLH_aus,domegaLN_aus));    
disp(sprintf('aut   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_aut,dLNStime0_aut,domegaLH_aut,domegaLN_aut));    
disp(sprintf('bel   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_bel,dLNStime0_bel,domegaLH_bel,domegaLN_bel));    
disp(sprintf('deu   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_can,dLNStime0_can,domegaLH_can,domegaLN_can));    
disp(sprintf('can   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_deu,dLNStime0_deu,domegaLH_deu,domegaLN_deu));    
disp(sprintf('dnk   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_dnk,dLNStime0_dnk,domegaLH_dnk,domegaLN_dnk));    
disp(sprintf('esp   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_esp,dLNStime0_esp,domegaLH_esp,domegaLN_esp));    
disp(sprintf('fin   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_fin,dLNStime0_fin,domegaLH_fin,domegaLN_fin));    
disp(sprintf('fra   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_fra,dLNStime0_fra,domegaLH_fra,domegaLN_fra));    
disp(sprintf('gbr   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_gbr,dLNStime0_gbr,domegaLH_gbr,domegaLN_gbr));    
disp(sprintf('irl   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_irl,dLNStime0_irl,domegaLH_irl,domegaLN_irl));    
disp(sprintf('ita   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_ita,dLNStime0_ita,domegaLH_ita,domegaLN_ita));    
disp(sprintf('jpn   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_jpn,dLNStime0_jpn,domegaLH_jpn,domegaLN_jpn));    
disp(sprintf('nld   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_nld,dLNStime0_nld,domegaLH_nld,domegaLN_nld));    
disp(sprintf('nor   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_nor,dLNStime0_nor,domegaLH_nor,domegaLN_nor));    
disp(sprintf('swe   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_swe,dLNStime0_swe,domegaLH_swe,domegaLN_swe));    
disp(sprintf('usa   : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_usa,dLNStime0_usa,domegaLH_usa,domegaLN_usa));    
disp(sprintf('oecd  : |%10.3f | %10.3f  | %10.3f | %10.3f',dLHStime0_oecd,dLNStime0_oecd,domegaLH_oecd,domegaLN_oecd));

disp(sprintf('dYHStime0,dYNStime0,dYHS,dYNS'));                                                                            
disp('Impact and Long-Run Responses of sectoral shares in real GDP');                                                      
disp(sprintf('aus   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_aus,dYNStime0_aus,domegaYHS_aus,domegaYNS_aus));      
disp(sprintf('aut   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_aut,dYNStime0_aut,domegaYHS_aut,domegaYNS_aut));      
disp(sprintf('bel   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_bel,dYNStime0_bel,domegaYHS_bel,domegaYNS_bel));      
disp(sprintf('deu   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_can,dYNStime0_can,domegaYHS_can,domegaYNS_can));      
disp(sprintf('can   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_deu,dYNStime0_deu,domegaYHS_deu,domegaYNS_deu));      
disp(sprintf('dnk   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_dnk,dYNStime0_dnk,domegaYHS_dnk,domegaYNS_dnk));      
disp(sprintf('esp   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_esp,dYNStime0_esp,domegaYHS_esp,domegaYNS_esp));      
disp(sprintf('fin   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_fin,dYNStime0_fin,domegaYHS_fin,domegaYNS_fin));      
disp(sprintf('fra   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_fra,dYNStime0_fra,domegaYHS_fra,domegaYNS_fra));      
disp(sprintf('gbr   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_gbr,dYNStime0_gbr,domegaYHS_gbr,domegaYNS_gbr));      
disp(sprintf('irl   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_irl,dYNStime0_irl,domegaYHS_irl,domegaYNS_irl));      
disp(sprintf('ita   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_ita,dYNStime0_ita,domegaYHS_ita,domegaYNS_ita));      
disp(sprintf('jpn   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_jpn,dYNStime0_jpn,domegaYHS_jpn,domegaYNS_jpn));      
disp(sprintf('nld   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_nld,dYNStime0_nld,domegaYHS_nld,domegaYNS_nld));      
disp(sprintf('nor   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_nor,dYNStime0_nor,domegaYHS_nor,domegaYNS_nor));      
disp(sprintf('swe   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_swe,dYNStime0_swe,domegaYHS_swe,domegaYNS_swe));      
disp(sprintf('usa   : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_usa,dYNStime0_usa,domegaYHS_usa,domegaYNS_usa));      
disp(sprintf('oecd  : |%10.3f | %10.3f  | %10.3f | %10.3f',dYHStime0_oecd,dYNStime0_oecd,domegaYHS_oecd,domegaYNS_oecd));  



disp(' '); disp('Impact and Long-run responses of sectoral capital-labor ratios');
disp(sprintf('dkHtime0,dkNtime0,dkH,dkN')); 
disp(sprintf('aus   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_aus,dkNKtime0_aus,dkH_aus,dkN_aus));
disp(sprintf('aut   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_aut,dkNKtime0_aut,dkH_aut,dkN_aut));
disp(sprintf('bel   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_bel,dkNKtime0_bel,dkH_bel,dkN_bel));
disp(sprintf('can   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_can,dkNKtime0_can,dkH_can,dkN_can));
disp(sprintf('deu   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_deu,dkNKtime0_deu,dkH_deu,dkN_deu));
disp(sprintf('dnk   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_dnk,dkNKtime0_dnk,dkH_dnk,dkN_dnk));
disp(sprintf('esp   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_esp,dkNKtime0_esp,dkH_esp,dkN_esp));
disp(sprintf('fin   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_fin,dkNKtime0_fin,dkH_fin,dkN_fin));
disp(sprintf('fra   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_fra,dkNKtime0_fra,dkH_fra,dkN_fra));
disp(sprintf('gbr   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_gbr,dkNKtime0_gbr,dkH_gbr,dkN_gbr));
disp(sprintf('irl   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_irl,dkNKtime0_irl,dkH_irl,dkN_irl));
disp(sprintf('ita   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_ita,dkNKtime0_ita,dkH_ita,dkN_ita));
disp(sprintf('jpn   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_jpn,dkNKtime0_jpn,dkH_jpn,dkN_jpn));
disp(sprintf('nld   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_nld,dkNKtime0_nld,dkH_nld,dkN_nld));
disp(sprintf('nor   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_nor,dkNKtime0_nor,dkH_nor,dkN_nor));
disp(sprintf('swe   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_swe,dkNKtime0_swe,dkH_swe,dkN_swe));
disp(sprintf('usa   : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_usa,dkNKtime0_usa,dkH_usa,dkN_usa));
disp(sprintf('oecd  : | %10.3f | %10.3f  | %10.3f | %10.3f',dkHKtime0_oecd,dkNKtime0_oecd,dkH_oecd,dkN_oecd));
disp(' ');

disp(sprintf('hatSHtime0,hatSNtime0,hatSH,hatSN')); 
disp('Impact and Long-Run Responses of sectoral shares in total labor: GROWTH RATES');
disp(sprintf('aus   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_aus,hatSNtime0_aus,hatSH_aus,hatSN_aus));
disp(sprintf('aut   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_aut,hatSNtime0_aut,hatSH_aut,hatSN_aut));
disp(sprintf('bel   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_bel,hatSNtime0_bel,hatSH_bel,hatSN_bel));
disp(sprintf('deu   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_can,hatSNtime0_can,hatSH_can,hatSN_can));
disp(sprintf('can   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_deu,hatSNtime0_deu,hatSH_deu,hatSN_deu));
disp(sprintf('dnk   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_dnk,hatSNtime0_dnk,hatSH_dnk,hatSN_dnk));
disp(sprintf('esp   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_esp,hatSNtime0_esp,hatSH_esp,hatSN_esp));
disp(sprintf('fin   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_fin,hatSNtime0_fin,hatSH_fin,hatSN_fin));
disp(sprintf('fra   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_fra,hatSNtime0_fra,hatSH_fra,hatSN_fra));
disp(sprintf('gbr   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_gbr,hatSNtime0_gbr,hatSH_gbr,hatSN_gbr));
disp(sprintf('irl   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_irl,hatSNtime0_irl,hatSH_irl,hatSN_irl));
disp(sprintf('ita   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_ita,hatSNtime0_ita,hatSH_ita,hatSN_ita));
disp(sprintf('jpn   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_jpn,hatSNtime0_jpn,hatSH_jpn,hatSN_jpn));
disp(sprintf('nld   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_nld,hatSNtime0_nld,hatSH_nld,hatSN_nld));
disp(sprintf('nor   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_nor,hatSNtime0_nor,hatSH_nor,hatSN_nor));
disp(sprintf('swe   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_swe,hatSNtime0_swe,hatSH_swe,hatSN_swe));
disp(sprintf('usa   : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_usa,hatSNtime0_usa,hatSH_usa,hatSN_usa));
disp(sprintf('oecd  : |%10.3f | %10.3f  | %10.3f | %10.3f',hatSHtime0_oecd,hatSNtime0_oecd,hatSH_oecd,hatSN_oecd));
disp(' ');
disp(' ');

disp(' '); disp('Impact and Long-run responses of total hours worked'); disp(sprintf('dLtime0,hatL'));
disp(sprintf('aus   : | %10.3f | %10.3f ',dLtime0_aus,hatL_aus));
disp(sprintf('aut   : | %10.3f | %10.3f ',dLtime0_aut,hatL_aut));
disp(sprintf('bel   : | %10.3f | %10.3f ',dLtime0_bel,hatL_bel));
disp(sprintf('can   : | %10.3f | %10.3f ',dLtime0_can,hatL_can));
disp(sprintf('deu   : | %10.3f | %10.3f ',dLtime0_deu,hatL_deu));
disp(sprintf('dnk   : | %10.3f | %10.3f ',dLtime0_dnk,hatL_dnk));
disp(sprintf('esp   : | %10.3f | %10.3f ',dLtime0_esp,hatL_esp));
disp(sprintf('fin   : | %10.3f | %10.3f ',dLtime0_fin,hatL_fin));
disp(sprintf('fra   : | %10.3f | %10.3f ',dLtime0_fra,hatL_fra));
disp(sprintf('gbr   : | %10.3f | %10.3f ',dLtime0_gbr,hatL_gbr));
disp(sprintf('irl   : | %10.3f | %10.3f ',dLtime0_irl,hatL_irl));
disp(sprintf('ita   : | %10.3f | %10.3f ',dLtime0_ita,hatL_ita));
disp(sprintf('jpn   : | %10.3f | %10.3f ',dLtime0_jpn,hatL_jpn));
disp(sprintf('nld   : | %10.3f | %10.3f ',dLtime0_nld,hatL_nld));
disp(sprintf('nor   : | %10.3f | %10.3f ',dLtime0_nor,hatL_nor));
disp(sprintf('swe   : | %10.3f | %10.3f ',dLtime0_swe,hatL_swe));
disp(sprintf('usa   : | %10.3f | %10.3f ',dLtime0_usa,hatL_usa));
disp(sprintf('oecd  : | %10.3f | %10.3f ',dLtime0_oecd,hatL_oecd));

disp(' '); disp('Impact and Long-run responses of traded and non-traded hours worked');
disp(sprintf('dLHtime0,dLNtime0,dLH,dLN'));
disp(sprintf('aus   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_aus,dLNtime0_aus,dLHoverL_aus,dLNoverL_aus));
disp(sprintf('aut   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_aut,dLNtime0_aut,dLHoverL_aut,dLNoverL_aut));
disp(sprintf('bel   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_bel,dLNtime0_bel,dLHoverL_bel,dLNoverL_bel));
disp(sprintf('can   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_can,dLNtime0_can,dLHoverL_can,dLNoverL_can));
disp(sprintf('deu   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_deu,dLNtime0_deu,dLHoverL_deu,dLNoverL_deu));
disp(sprintf('dnk   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_dnk,dLNtime0_dnk,dLHoverL_dnk,dLNoverL_dnk));
disp(sprintf('esp   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_esp,dLNtime0_esp,dLHoverL_esp,dLNoverL_esp));
disp(sprintf('fin   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_fin,dLNtime0_fin,dLHoverL_fin,dLNoverL_fin));
disp(sprintf('fra   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_fra,dLNtime0_fra,dLHoverL_fra,dLNoverL_fra));
disp(sprintf('gbr   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_gbr,dLNtime0_gbr,dLHoverL_gbr,dLNoverL_gbr));
disp(sprintf('irl   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_irl,dLNtime0_irl,dLHoverL_irl,dLNoverL_irl));
disp(sprintf('ita   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_ita,dLNtime0_ita,dLHoverL_ita,dLNoverL_ita));
disp(sprintf('jpn   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_jpn,dLNtime0_jpn,dLHoverL_jpn,dLNoverL_jpn));
disp(sprintf('nld   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_nld,dLNtime0_nld,dLHoverL_nld,dLNoverL_nld));
disp(sprintf('nor   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_nor,dLNtime0_nor,dLHoverL_nor,dLNoverL_nor));
disp(sprintf('swe   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_swe,dLNtime0_swe,dLHoverL_swe,dLNoverL_swe));
disp(sprintf('usa   : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_usa,dLNtime0_usa,dLHoverL_usa,dLNoverL_usa));
disp(sprintf('oecd  : | %10.3f | %10.3f  | %10.3f | %10.3f',dLHtime0_oecd,dLNtime0_oecd,dLHoverL_oecd,dLNoverL_oecd));
disp(' ');    
                                                                              
                                                                                                                  
disp(' ');
disp('-------------------------------------------------------------------------------------------------------- ');

clear