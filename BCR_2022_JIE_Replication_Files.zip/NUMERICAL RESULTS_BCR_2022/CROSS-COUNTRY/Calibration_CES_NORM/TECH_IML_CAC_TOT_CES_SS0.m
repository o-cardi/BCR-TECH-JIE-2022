function g = TECH_IML_CAC_TOT_CES_SS0(x)

global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH 
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global B0 K0 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
alphaC  = x(18) ; % Tradable content of consumption expenditure 
alphaH  = x(19) ; % Home goods content of consumption expenditure on traded goods
PI      = x(20) ; % Aggregate investment price index
PIT     = x(21) ; % Investment price index for tradables
IN      = x(22) ; % Non tradable investment
IH      = x(23) ; % Investment in home goods
IF      = x(24) ; % Investment in foreign goods
alphaI  = x(25) ; % Tradable content of investment expenditure
alphaIH = x(26) ; % Home goods content of investment expenditure
LH      = x(27) ; % Labor in sector H
LN      = x(28) ; % Labor in sector N 
GF      = x(29) ; % Government spending in foreign goods
GN      = x(30) ; % Government spending in non tradables 
GH      = x(31) ; % Government spending in home traded goods
yH      = x(32) ; % Output of home traded goods per worker
YH      = x(33) ; % Output of home traded goods
yN      = x(34) ; % Output of non traded goods per worker
YN      = x(35) ; % Output of non traded goods
XH      = x(36) ; % Exports of home traded goods
MF      = x(37) ; % Imports of foreign goods
LH_WH   = x(38) ; % Partial derivative of LH=LH(lambda,WH,WN)
LH_WN   = x(39) ; % Partial derivative of LH=LH(lambda,WH,WN)
LN_WH   = x(40) ; % Partial derivative of LN=LN(lambda,WH,WN)
LN_WN   = x(41) ; % Partial derivative of LN=LN(lambda,WH,WN) 
lambda  = x(42) ; % Intertemporal Solvency Condition   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      

% Aggregate Consumption - C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors - kH and
% kN
g(3)= PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((yH/kH)^(1/sigmaH)) - PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((yN/kN)^(1/sigmaN)); 

% Wage rate in sector H - WH
g(4)= PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH)) - WH;

% Wage rate in sector N - WN
g(5)= PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN)) - WN;

% Aggregate wage index - W
g(6)= W - ((vartheta*(WH)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% sectoral capital allocation - kH and kN - 
g(7)= (LH*kH) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate - PN 
g(8)= PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((yN/kN)^(1/sigmaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(10)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(11)= (r*B) + (PH*XH) - MF;

% Non tradable share of labor income - alphaL 
g(12)= alphaL - ((1-vartheta)*(WN)^(epsilon+1))/( vartheta*(WH)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) ); 

% Consumption price index - PC=PC(PT,PN)
g(13)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(14)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(15)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(16)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(17)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Tradable content of consumption expenditure - alphaC
g(18)= alphaC - varphi*(PT/PC)^(1-phi);

% Home goods content of consumption expenditure - alphaH
g(19)= alphaH - varphiH*(PH/PT)^(1-rho);

% Investment price index - PI=PI(PT,PN)
g(20)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(21)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(22)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(23)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(24)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Tradable of investment expenditure - alphaI
g(25)= alphaI - iota*(PIT/PI)^(1-phiI);

% Home goods content of investment expenditure - alphaIH
g(26)= alphaIH - iotaH*(PH/PIT)^(1-rhoI);

% Employment in the traded sector - LH
g(27)= LH - L*(vartheta*(WH/W)^epsilon); 

% Employment in the non traded sector - LN
g(28)= LN - L*((1-vartheta)*(WN/W)^epsilon); 

% Total government spending - G
g(29)= ((PH*GH) + GF + (PN*GN)) - omegaG*( (PH*YH) + (PN*YN) ); 

% Non tradable share of government spending  - GN
g(30)= (PN*GN) - omegaGN*( (PH*GH) + GF + (PN*GN) ); 

% Home goods content of government spending  - GH
g(31)= (PH*GH) - omegaGH*( (PH*GH) + GF ); 

% Output in the home good sector - YH
% Output per worker in the home traded sector - kH,yH - and Labor
% income share in sector H, sLH
g(32)= yH - ( gammaH*(AH^((sigmaH-1)/sigmaH)) + (1-gammaH)*((BH*kH)^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));  
g(33)= YH  - (LH*yH); 

% Output per worker in the non traded sector - kN,yN - and Labor
% income share in sector N, sLN
g(34)= yN  - ( gammaN*(AN)^((sigmaN-1)/sigmaN) + (1-gammaN)*((BN*kN)^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
g(35)= YN  - (LN*yN); 

% Export of home goods - XH
g(36)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(37)= MF - (CF+IF+GF);

% LHT = partial LH/partial WH
g(38)= LH_WH - (LH/WH)*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 

% LHN = partial LH/partial WN
g(39)= LH_WN - (LH/WN)*alphaL*(sigmaL-epsilon); 

% LNT = partial LN/partial WH
g(40)= LN_WH - (LN/WH)*(1-alphaL)*(sigmaL-epsilon); 

% LNN = partial LN/partial WN
g(41)= LN_WN - (LN/WN)*( epsilon*(1-alphaL) + (sigmaL*alphaL) ); 

% Labor income share in the home traded good and non traded good sector
sLH    = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN    = gammaN*(AN/yN)^((sigmaN-1)/sigmaN); 

% Intermediate solutions for kH, kN, LH, LN as functions of P,K 
d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d13 = 0;
d14 = 0;
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = (1/sigmaN)*((1-sLN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = (kH*LH_WH) + (kN*LN_WH); 
d44 = (kH*LH_WN) + (kN*LN_WN); 

e11 = (1/PN); 
e12 = -(1/PH);
e13 = 0;
e21 = 0; 
e22 = -(1/PH); 
e23 = 0;
e31 = -(1/PN); 
e32 = 0; 
e33 = 0; 
e41 = 0; 
e42 = 0; 
e43 = 1; 
    
M = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X = [e11 e12 e13; e21 e22 e23; e31 e32 e33; e41 e42 e43];
JST = inv(M);
MST = JST*X;
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1K = MST(1,3);  
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1K = MST(2,3);  
WH_PN = MST(3,1); WH_PH = MST(3,2); WH_1K = MST(3,3);  
WN_PN = MST(4,1); WN_PH = MST(4,2); WN_1K = MST(4,3);  

% Intermediate solutions for sectoral labor and sectoral output - Yj=Yj(PN,PH,K,ZH,ZN)
LH_PN = (LH_WH*WH_PN) + (LH_WN*WN_PN); 
LN_PN = (LN_WH*WH_PN) + (LN_WN*WN_PN); 
LH_PH = (LH_WH*WH_PH) + (LH_WN*WN_PH); 
LN_PH = (LN_WH*WH_PH) + (LN_WN*WN_PH);
LH_1K = (LH_WH*WH_1K) + (LH_WN*WN_1K); 
LN_1K = (LN_WH*WH_1K) + (LN_WN*WN_1K);

yH_PN = (yH/kH)*(1-sLH)*kH_PN;   
yN_PN = (yN/kN)*(1-sLN)*kN_PN;
yH_PH = (yH/kH)*(1-sLH)*kH_PH;   
yN_PH = (yN/kN)*(1-sLN)*kN_PH;   
yH_1K = (yH/kH)*(1-sLH)*kH_1K;   
yN_1K = (yN/kN)*(1-sLN)*kN_1K; 

YH_PN = (LH*yH_PN) + (yH*LH_PN);
YN_PN = (LN*yN_PN) + (yN*LN_PN);
YH_PH = (LH*yH_PH) + (yH*LH_PH);
YN_PH = (LN*yN_PH) + (yN*LN_PH);
YH_1K = (LH*yH_1K) + (yH*LH_1K);
YN_1K = (LN*yN_1K) + (yN*LN_1K);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN,PN) -
% Intermediate Solution
PsiH_PH  = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN  = (YH_PN - CH_PN - JH_PN);
PH_PN    = -PsiH_PN/PsiH_PH; 
PH_1K    = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q    = JH_1Q/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,ZH,ZN)
PsiN_PH  = (YN_PH - CN_PH - JN_PH); 
PsiN_PN  = (YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN);
PN_K     = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q     =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN) - Final
% Solution
PH_K     = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q     = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 

% Solving for capital-labor ratios kj=kj(lambda,K,Q,ZH,ZN) - 
% sectoral labor Lj=Lj(lambda,K,Q,ZH,ZN) - sectoral output 
% Yj=Yj(lambda,K,Q,ZH,ZN) - Final Solutions
kH_K = kH_1K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = kN_1K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CH_K = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CN_K = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CF_K = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q = (CF_PH*PH_Q) + (CF_PN*PN_Q); 

JH_K  = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q  = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q); 
JN_K  = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q  = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JF_K  = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q  = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 

XH_K = XH_PH*PH_K; 
XH_Q = XH_PH*PH_Q; 
MF_K = (CF_K + JF_K); 
MF_Q = (CF_Q + JF_Q); 

% Marginal revenue of capital R = PN*partial YN/partial KN
RK  = PI*(r+deltaK); 
R_K = (RK/PN)*PN_K - (RK/sigmaN)*(sLN/kN)*kN_K; 
R_Q = (RK/PN)*PN_Q - (RK/sigmaN)*(sLN/kN)*kN_Q; 

% Solving for investment function I/K = v(Q/PI)+delta_K - final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 

% Elements of the Jacobian Matrix 
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 
 
x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    
                                                                      
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(42) = (B - B0) - H1*(K-K0);


