function g = TECH_PML_CAC_TOT_SS0(x)

global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH 
global ZH ZN thetaH thetaN 
global B0 K0 
global xiH xiN barzH barzN gzH gzN gz gzH0 gzN0 aH aN

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LH      = x(6) ; % Labor in sector H
LN      = x(7) ; % Labor in sector N 
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
PC      = x(12) ; % Aggregate consumption price index
PT      = x(13) ; % Consumption price index for tradables
CN      = x(14) ; % Consumption in non tradables 
CH      = x(15) ; % Consumption in tradables 
CF      = x(16) ; % Consumption goods imports
alphaC  = x(17) ; % Tradable content of consumption expenditure 
alphaH  = x(18) ; % Home goods content of consumption expenditure on traded goods
PI      = x(19) ; % Aggregate investment price index
PIT     = x(20) ; % Investment price index for tradables
IN      = x(21) ; % Non tradable investment
IH      = x(22) ; % Investment in home goods
IF      = x(23) ; % Investment in foreign goods
alphaI  = x(24) ; % Tradable content of investment expenditure
alphaIH = x(25) ; % Home goods content of investment expenditure
GF      = x(26) ; % Government spending in foreign goods
GN      = x(27) ; % Government spending in non tradables 
GH      = x(28) ; % Government spending in home traded goods
YH      = x(29) ; % Output of home traded goods
YN      = x(30) ; % Output of non traded goods
XH      = x(31) ; % Exports of home traded goods
MF      = x(32) ; % Imports of foreign goods
lambda  = x(33) ; % Intertemporal Solvency Condition   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      

% Aggregate Consumption - C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors - kH and
% kN
g(3)= PH*ZH*(1-thetaH)*(kH^(-thetaH)) -  PN*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector H - kH and kN
g(4)= PH*ZH*thetaH*(kH^(1-thetaH)) - PN*ZN*thetaN*(kN^(1-thetaN));

% Aggregate wage index - W
g(5)= W - PH*ZH*thetaH*(kH^(1-thetaH));

% sectoral labor allocation  - LH and LN 
g(6)= (LH+LN) - L;

% sectoral capital allocation - LH and LN - 
g(7)= (LH*kH) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate - PN 
g(8)= PN*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(10)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(11)= (r*B) + (PH*XH) - MF;

% Consumption price index - PC=PC(PT,PN)
g(12)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(13)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(14)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(15)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(16)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Tradable content of consumption expenditure - alphaC
g(17)= alphaC - varphi*(PT/PC)^(1-phi);

% Home goods content of consumption expenditure - alphaH
g(18)= alphaH - varphiH*(PH/PT)^(1-rho);

% Investment price index - PI=PI(PT,PN)
g(19)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(20)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(21)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(22)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(23)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Tradable of investment expenditure - alphaI
g(24)= alphaI - iota*(PIT/PI)^(1-phiI);

% Home goods content of investment expenditure - alphaIH
g(25)= alphaIH - iotaH*(PH/PIT)^(1-rhoI);

% Total government spending - G
g(26)= ((PH*GH) + GF + (PN*GN)) - omegaG*( (PH*YH) + (PN*YN) ); 

% Non tradable share of government spending  - GN
g(27)= (PN*GN) - omegaGN*( (PH*GH) + GF + (PN*GN) ); 

% Home goods content of government spending  - GH
g(28)= (PH*GH) - omegaGH*( (PH*GH) + GF ); 

% Output in the home good sector - YH
g(29)= YH - ZH*LH*(kH^(1-thetaH)); 

% Output in the non traded sector - YN
g(30)= YN - ZN*LN*(kN^(1-thetaN));

% Export of home goods - XH
g(31)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(32)= MF - (CF+IF+GF);

% Intermediate solutions for kH, kN, LH, LN as functions of P,K 
d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d21 = ((1-thetaH)/kH); 
d22 = -((1-thetaN)/kN);

e11 = (1/PN); 
e12 = -(1/PH);
e21 = (1/PN); 
e22 = -(1/PH); 
 
M = [d11 d12; d21 d22];
X = [e11 e12; e21 e22];
JST = inv(M);
MST = JST*X;
kH_PN = MST(1,1); kH_PH = MST(1,2); 
kN_PN = MST(2,1); kN_PH = MST(2,2);  

% Solution for W=W(PH,PN,ZH,ZN), L=L(lambda,PH,PN,ZH,ZN)
W_PH     = (W/PH) + (1-thetaH)*(W/kH)*kH_PH; 
W_PN     = (1-thetaH)*(W/kH)*kH_PN; 
L_W      = sigmaL*(L/W); 
L_PN     = L_W*W_PN;
L_PH     = L_W*W_PH;

% Solutions for Lj=Lj(K,P)
KC_PN  = ( (LH*kH_PN) + (LN*kN_PN) ); 
KC_PH  = ( (LH*kH_PH) + (LN*kN_PH) );

f11 = 1; 
f12 = 1;  
f21 = kH; 
f22 = kN;

g11 = 0; 
g12 = L_PN;
g13 = L_PH;
g21 = 1; 
g22 = -KC_PN; 
g23 = -KC_PH;

M = [f11 f12; f21 f22];
X = [g11 g12 g13; g21 g22 g23];
JST = inv(M);
MST = JST*X;
LH_1K = MST(1,1); LH_PN = MST(1,2); LH_PH = MST(1,3);  
LN_1K = MST(2,1); LN_PN = MST(2,2); LN_PH = MST(2,3);   

% Intermediate solutions for sectoral labor and sectoral output - Yj=Yj(PN,PH,K,ZH,ZN)
YH_PN = YH*( (LH_PN/LH) + (1-thetaH)*(kH_PN/kH) ); 
YN_PN = YN*( (LN_PN/LN) + (1-thetaN)*(kN_PN/kN) ); 
YH_PH = YH*( (LH_PH/LH) + (1-thetaH)*(kH_PH/kH) ); 
YN_PH = YN*( (LN_PH/LN) + (1-thetaN)*(kN_PH/kN) );
YH_1K = YH*(LH_1K/LH); 
YN_1K = YN*(LN_1K/LN); 

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I     = deltaK*K; 
JN_PN = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K = (IN/I)*J_K; 
JN_1Q = (IN/I)*J_Q; 

JH_PN =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K = (IH/I)*J_K; 
JH_1Q = (IH/I)*J_Q; 

JF_PN = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K = (IF/I)*J_K; 
JF_1Q = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN,PN) -
% Intermediate Solution
PsiH_PH  = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN  = (YH_PN - CH_PN - JH_PN);
PH_PN    = -PsiH_PN/PsiH_PH; 
PH_1K    = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q    = JH_1Q/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,ZH,ZN)
PsiN_PH  = (YN_PH - CN_PH - JN_PH); 
PsiN_PN  = (YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN);
PN_K     = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q     =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN) - Final
% Solution
PH_K     = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q     = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 

% Solving for capital-labor ratios kj=kj(lambda,K,Q,ZH,ZN) - 
% sectoral labor Lj=Lj(lambda,K,Q,ZH,ZN) - sectoral output 
% Yj=Yj(lambda,K,Q,ZH,ZN) - Final Solutions
kH_K = (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CH_K = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CN_K = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CF_K = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q = (CF_PH*PH_Q) + (CF_PN*PN_Q); 

JH_K  = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q  = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q); 
JN_K  = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q  = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JF_K  = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q  = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 

XH_K = XH_PH*PH_K; 
XH_Q = XH_PH*PH_Q; 
MF_K = (CF_K + JF_K); 
MF_Q = (CF_Q + JF_Q); 

% Marginal revenue of capital R = PN*partial YN/partial KN
RK  = PI*(r+deltaK); 
R_K = (RK/PN)*PN_K - (RK/kN)*thetaN*kN_K; 
R_Q = (RK/PN)*PN_Q - (RK/kN)*thetaN*kN_Q; 

% Solving for investment function I/K = v(Q/PI)+delta_K - final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 

% Elements of the Jacobian Matrix 
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 
 
x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    
                                                                      
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(33) = (B - B0) - H1*(K-K0);


