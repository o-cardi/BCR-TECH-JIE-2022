function g = TECH_IML_CAC_SS0(x)

global sigmaC phi varphi 
global gammaL sigmaL phiI varphiI
global r deltaK omegaG omegaGN
global ZT ZN thetaT thetaN kappa
global epsilon vartheta 
global B0 K0 GT GN 
global xiT xiN barzT barzN gzT gzN aT aN

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
WT      = x(4)  ; % Wage rate in sector T
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
alphaL  = x(11) ; % Output per worker in sector N 
CN      = x(12) ; % Consumption in non tradables 
CT      = x(13) ; % Consumption in tradables 
PC      = x(14) ; % Consumption price index
alphaC  = x(15) ; % Non tradable share of consumption - alphaC
IN      = x(16) ; % Non tradable investment
IT      = x(17) ; % Tradable investment 
PI      = x(18) ; % Investment price index
alphaI  = x(19) ; % Non tradable share of investment 
PIprime = x(20) ; % Partial derivative of PI
LT      = x(21) ; % Labor in sector T
LN      = x(22) ; % Labor in sector N 
GT      = x(23) ; % Government spending in tradables
GN      = x(24) ; % Government spending in non tradables 
f       = x(25) ; % Output per worker in sector T 
h       = x(26) ; % Output per worker in sector N 
CT_P    = x(27) ; % Partial derivative of CT=CT(P,lambda)
CN_P    = x(28) ; % Partial derivative of CN=CN(P,lambda)
LT_WT   = x(29) ; % Partial derivative of LT=LT(lambda,WT,WN)
LT_WN   = x(30) ; % Partial derivative of LT=LT(lambda,WT,WN)
LN_WT   = x(31) ; % Partial derivative of LN=LN(lambda,WT,WN)
LN_WN   = x(32) ; % Partial derivative of LN=LN(lambda,WT,WN) 
lambda  = x(33) ; % Intertemporal Solvency Condition   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      

% Aggregate Consumption -  C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors  - kT and
% kN
g(3)= ZT*(1-thetaT)*(kT^(-thetaT)) -  (P)*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector T  - WT
g(4)= ZT*thetaT*(kT^(1-thetaT)) - WT;

% Wage rate in sector N   - WN
g(5)= P*ZN*thetaN*(kN^(1-thetaN)) - WN;

% Aggregate wage index  - W
g(6)= W - ((vartheta*(WT)^(epsilon+1)) + ((1-vartheta)*(WN)^(epsilon+1)))^(1/(epsilon+1));

% sectoral capital allocation  -  kT and kN - 
g(7)= (LT*kT) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate  
g(8)= P*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= ZN*(LN*(kN^(1-thetaN))) - CN - GN - IN;

% Traded good market clearing condition - B
g(10)= (r*B) + ZT*(LT*(kT^(1-thetaT))) - CT - GT - IT;

% Non tradable share of labor income - alphaL 
g(11)= alphaL - ((1-vartheta)*(WN)^(epsilon+1))/( vartheta*(WT)^(epsilon+1) + (1-vartheta)*(WN)^(epsilon+1) ); 

% Consumption in non tradables - CN
g(12)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT 
g(13)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(14)= PC - (varphi+(1-varphi)*P^(1-phi))^(1/(1-phi));

% Non tradable share of consumption - alphaC
g(15)= alphaC - (1-varphi)*(P/PC)^(1-phi);

% Non tradable Investment - IN
g(16)= IN - (alphaI*PI*(deltaK*K)/P);

% Tradable Investment - IT 
g(17)= IT - (1-alphaI)*PI*(deltaK*K);

% Investment price index - PI
g(18)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Non tradable share of investment - alphaI
g(19)= alphaI - (1-varphiI)*(P/PI)^(1-phiI);

% Partial derivative of Investment price index - PIprime
g(20)= PIprime - (1-varphiI)*(P/PI)^(-phiI);

% Employment in the traded sector - LT
g(21)= LT - L*(vartheta*(WT/W)^epsilon); 

% Employment in the non traded sector - LN
g(22)= LN - L*((1-vartheta)*(WN/W)^epsilon); 

% Total government spending - GT
g(23)= (GT+(P*GN)) - omegaG*((ZT*LT*f) + (P)*ZN*LN*h); 

% Non tradable share of government spending 
g(24)= (P*GN) - omegaGN*(GT+(P*GN)); 

% Output per worker in the traded sector - f
g(25)= f - (kT^(1-thetaT)); 

% Output per worker in the non traded sector - h
g(26)= h - (kN^(1-thetaN));

% Partial CT/partial P - CT_P
g(27)= CT_P - alphaC*(CT/P)*(phi-sigmaC);

% Partial CN/partial P - CN_P
g(28)= CN_P + (CN/P)*(phi*(1-alphaC)+ (sigmaC*alphaC));

% LTT = partial LT/partial WT
g(29)= LT_WT - (LT/WT)*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 

% LTN = partial LT/partial WN
g(30)= LT_WN - (LT/WN)*alphaL*(sigmaL-epsilon); 

% LNT = partial LN/partial WT
g(31)= LN_WT - (LN/WT)*(1-alphaL)*(sigmaL-epsilon); 

% LNN = partial LN/partial WN
g(32)= LN_WN - (LN/WN)*( epsilon*(1-alphaL) + (sigmaL*alphaL) ); 

% Solutions for kT, kN, LT, LN as functions of P,K 
Psi_WT   = ( (kT*LT_WT) + (kN*LN_WT) );
Psi_WN   = ( (kT*LT_WN) + (kN*LN_WN) );

d11 = -(thetaT/kT); 
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaT)/kT); 
d22 = 0;  
d23 = -(1/WT); 
d24 = 0; 
d31 = 0; 
d32 = ((1-thetaN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LT; 
d42 = LN; 
d43 = Psi_WT; 
d44 = Psi_WN; 

e11 = (1/P); 
e12 = 0;
e21 = 0; 
e22 = 0; 
e31 = -(1/P); 
e32 = 0; 
e41 = 0; 
e42 = 1; 
    
M = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X = [e11 e12; e21 e22; e31 e32; e41 e42];
JST = inv(M);
MST = JST*X;
kT_P = MST(1,1); kT_K = MST(1,2); 
kN_P = MST(2,1); kN_K = MST(2,2); 
WT_P = MST(3,1); WT_K = MST(3,2); 
WN_P = MST(4,1); WN_K = MST(4,2); 

% Solutions for sectoral labor and sectoral output
YT   = ZT*(LT*(kT^(1-thetaT))); 
YN   = ZN*(LN*(kN^(1-thetaN))); 
LT_P = (LT_WT*WT_P) + (LT_WN*WN_P); 
LN_P = (LN_WT*WT_P) + (LN_WN*WN_P); 
LT_K = (LT_WT*WT_K) + (LT_WN*WN_K); 
LN_K = (LN_WT*WT_K) + (LN_WN*WN_K);
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YT_K = YT*( (LT_K/LT) + (1-thetaT)*(kT_K/kT) ); 
YN_K = YN*( (LN_K/LN) + (1-thetaN)*(kN_K/kN) ); 

% Investment function I/K = v(Q/PI(P))+delta_K
v_Q = 1/(kappa*PI); 
v_P = -alphaI/(kappa*P); 

% Marginal revenue of capital R = P*h_k[kN(K,P)]
RK = PI*(r+deltaK); 
R_K = -(RK/kT)*thetaT*kT_K; 
R_P = -(RK/kT)*thetaT*kT_P; 

% Solving for the relative price P=P(lambda,K,Q,ZT,ZN)
PsiP  = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime) - K*v_P; 
P_K   = -(1/PsiP)*( (YN_K/PIprime) - deltaK ); 
P_Q   = (K/PsiP)*v_Q; 

% Elements of the Jacobian Matrix 
Upsilon_K = ( (YN_K/PIprime) - deltaK);                                                                        
Upsilon_P = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime); 
Sigma_K   = -R_K; 
Sigma_P   = -(R_P + (PI*kappa*v_P*deltaK)); 
Sigma_Q   = (r+deltaK) - (PI*kappa*v_Q*deltaK); 
 
x11 = Upsilon_K + (Upsilon_P*P_K);                                                                         
x12 = (Upsilon_P*P_Q);                                                                                                                                                                                                                     
x21 = Sigma_K + (Sigma_P*P_K);                        
x22 = Sigma_Q + (Sigma_P*P_Q);    
                                                                      
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
Xi_K  = (YT_K - ((1-alphaI)/alphaI)*P*YN_K); 
Xi_P  = ( (YT_P-CT_P) - ((1-alphaI)/alphaI)*P*(YN_P-CN_P) - phiI*((1-alphaI)/alphaI)*IN ); 
B_K   = (Xi_K + (Xi_P*P_K)); 
B_Q   = (Xi_P*P_Q); 
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(33) = (B - B0) - H1*(K-K0);


