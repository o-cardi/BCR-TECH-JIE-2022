global sigmaC phi varphi beta
global gammaL sigmaL phiI varphiI
global r deltaK omegaG omegaGN
global ZT ZN thetaT thetaN kappa
global B0 K0 GT GN %H1_0
global xiT xiN barzT barzN gzT gzN gz gzT0 gzN0 gz0 aT aN


% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% PML CAC kT>kN                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ZT_0         = 1.00;  
ZN_0         = 1.00;
omegaG       = 0.196; 
omegaGN      = 0.90; 
thetaT_0     = 0.631; 
thetaN_0     = 0.682; 
sigmaL_0     = 1.6; 
gammaL       = 1; 
sigmaC_0     = 2;  
phi_0        = 0.44;
varphi_0     = 0.513;                   
phiI_0       = 1.00000000001;                    
varphiI_0    = 0.379;  
kappa_1      = 17; 
  
r            = 0.04; 
beta         = r; 
deltaK       = 0.093;

B0           = 10.6;
K0           = 0;

ZT           = ZT_0;       
ZN           = ZN_0;       
thetaT       = thetaT_0;   
thetaN       = thetaN_0;   
sigmaC       = sigmaC_0;  
sigmaL       = sigmaL_0;   
phi          = phi_0 ;     
varphi       = varphi_0;  
phiI         = phiI_0;    
varphiI      = varphiI_0; 
kappa        = kappa_1; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.024   ; % Consumption 
L_ini        = 1.035   ; % Labor supply 
kT_ini       = 5.084   ; % Capital-labor ratio in sector T
kN_ini       = 2.971   ; % Capital-labor ratio in sector N
W_ini        = 1.616   ; % Aggregate wage index
LT_ini       = 0.322   ; % Labor in sector T
LN_ini       = 0.712   ; % Labor in sector N 
P_ini        = 2.262   ; % Relative price of non tradables
K_ini        = 3.785   ; % Stock of capital
B_ini        = -1.58   ; % Stock of Traded Bonds
CN_ini       = 0.299   ; % Consumption in non tradables 
CT_ini       = 0.589   ; % Consumption in tradables 
PC_ini       = 1.186   ; % Consumption price index
alphaC_ini   = 0.430   ; % Non tradables share of consumption expenditure
IN_ini       = 0.235   ; % Non traded investment
IT_ini       = 0.000   ; % Traded investment
alphaI_ini   = 1.000   ; % Non tradable share of investment expenditure
PI_ini       = 1.486   ; % Investment price index
PIprime_ini  = 1.000   ; % partial derivative of the investment price index
GT_ini       = 0.03    ; % Government spending in tradables
GN_ini       = 0.21    ; % Government spending in non tradables 
YT_ini       = 1.935   ; % Output per worker in sector T 
YN_ini       = 1.408   ; % Output per worker in sector N     
CT_P_ini     = 0.000   ; % Partial derivative of CT=CT(P,lambda)
CN_P_ini     = -0.410  ; % Partial derivative of CN=CN(P,lambda)    
lambda_ini   = 0.967   ; % Intertemporal Solvency Condition          
                                                          
x0 =[C_ini L_ini kT_ini kN_ini W_ini LT_ini LN_ini P_ini K_ini B_ini CN_ini CT_ini PC_ini alphaC_ini IN_ini IT_ini alphaI_ini PI_ini PIprime_ini GT_ini GN_ini YT_ini YN_ini CT_P_ini CN_P_ini lambda_ini];
[x,fval,exitflag]=fsolve('TECH_PML_CAC_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
alphaC  = x(14) ; % Non tradable share of consumption - alphaC
IN      = x(15) ; % Non tradable investment
IT      = x(16) ; % Tradable investment 
PI      = x(17) ; % Investment price index
alphaI  = x(18) ; % Non tradable share of investment 
PIprime = x(19) ; % Partial derivative of PI
GT      = x(20) ; % Government spending in tradables
GN      = x(21) ; % Government spending in non tradables 
YT      = x(22) ; % Output in sector T 
YN      = x(23) ; % Output in sector N 
CT_P    = x(24) ; % Partial derivative of CT=CT(P,lambda)
CN_P    = x(25) ; % Partial derivative of CN=CN(P,lambda)
lambda  = x(26) ; % Intertemporal Solvency Condition      

% Sectoral outputs and sectoral profits   
KT  = LT*kT;  
RK  = (1-thetaT)*(YT/KT);
WT  = thetaT*(YT/LT); 
PiT = YT - (RK*KT) - (WT*LT);
  
KN  = LN*kN;  
WN  = P*thetaN*(YN/LN);
PiN = (P*YN) - (RK*KN) - (WN*LN);

% Labor income share in the traded good and non traded good sector
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN); 

% Capital Rental Rates
RKT = (1-thetaT)*(YT/KT);
RKN = P*(1-thetaN)*(YN/KN);

% Solution for C as function C=C(lambda,P) 
C_lambda  = -sigmaC*(C/lambda); 
C_P       = -alphaC*sigmaC*(C/P); 

% Solutions for kj=kj(P,ZT,ZN)
d11 = -(thetaT/kT); 
d12 =  (thetaN/kN);
d21 =  (1-thetaT)/kT; 
d22 = -(1-thetaN)/kN;  

e11 =  (1/P); 
e12 = -(1/ZT);
e13 =  (1/ZN);
e21 =  (1/P); 
e22 = -(1/ZT);
e23 =  (1/ZN);

M = [d11 d12; d21 d22];
X = [e11 e12 e13; e21 e22 e23];
JST = inv(M);
MST = JST*X;
kT_P = MST(1,1); kT_ZT = MST(1,2); kT_ZN = MST(1,3); 
kN_P = MST(2,1); kN_ZT = MST(2,2); kN_ZN = MST(2,3);  

% Solution for W as function W=W(P,ZT,ZN)  
W_P       = (1-thetaT)*(W/kT)*kT_P; 
W_ZT      = (1-thetaT)*(W/kT)*kT_ZT; 
W_ZN      = (1-thetaT)*(W/kT)*kT_ZN;

% Solution for L as function L=L(lambda,P,ZT,ZN)
L_lambda = sigmaL*(L/lambda);
L_W      = sigmaL*(L/W);  
L_P      = L_W*W_P;
L_ZT     = L_W*W_ZT; 
L_ZN     = L_W*W_ZN;

% Solutions for Lj=Lj(K,P)
Psi_P  = ( (LT*kT_P) + (LN*kN_P) ); 
Psi_ZT = ( (LT*kT_ZT) + (LN*kN_ZT) );
Psi_ZN = ( (LT*kT_ZN) + (LN*kN_ZN) );

f11 = 1; 
f12 = 1;  
f21 = kT; 
f22 = kN;

g11 = 0; 
g12 = L_P;
g13 = L_ZT;
g14 = L_ZN;
g15 = L_lambda;
g21 = 1; 
g22 = -Psi_P; 
g23 = -Psi_ZT;
g24 = -Psi_ZN;
g25 = 0;

M = [f11 f12; f21 f22];
X = [g11 g12 g13 g14 g15; g21 g22 g23 g24 g25];
JST = inv(M);
MST = JST*X;
LT_K = MST(1,1); LT_P = MST(1,2); LT_ZT = MST(1,3); LT_ZN = MST(1,4); LT_lambda = MST(1,5);  
LN_K = MST(2,1); LN_P = MST(2,2); LN_ZT = MST(2,3); LN_ZN = MST(2,4); LN_lambda = MST(2,5);  

% Solutions for sectoral labor and sectoral output Lj=Lj(lambda,P,K,ZT,ZN),
% Yj=Yj(lambda,P,K,ZT,ZN)

YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YT_K = YT*(LT_K/LT); 
YN_K = YN*(LN_K/LN); 
YT_ZT = YT*( (1/ZT) + (LT_ZT/LT) + (1-thetaT)*(kT_ZT/kT) ); 
YN_ZT = YN*( (LN_ZT/LN) + (1-thetaN)*(kN_ZT/kN) );              
YT_ZN = YT*( (LT_ZN/LT) + (1-thetaT)*(kT_ZN/kT) );  
YN_ZN = YN*( (1/ZN) + (LN_ZN/LN) + (1-thetaN)*(kN_ZN/kN) );
YT_lambda = YT*(LT_lambda/LT); 
YN_lambda = YN*(LN_lambda/LN); 

% GDP and output shares in real terms
Y   = YT+(P*YN);

% Solution for Y as function Y=Y(K,P,lambda,ZT,ZN) 
Y_P       = YT_P + (P*YN_P) + YN; 
Y_K       = YT_K + (P*YN_K); 
Y_ZT      = YT_ZT + (P*YN_ZT);
Y_ZN      = YT_ZN + (P*YN_ZN);
Y_lambda  = YT_lambda + (P*YN_lambda); 

% Investment function I/K = v(Q/PI(P))+delta_K
v_Q = 1/(kappa*PI); 
v_P = -alphaI/(kappa*P); 

% Solution for R as function R=R(P,ZT,ZN) 
RK    = PI*(r+deltaK); 
R_P   = -RK*thetaT*(kT_P/kT); 
R_ZT  = (RK/ZT) - RK*thetaT*(kT_ZT/kT); 
R_ZN  = -RK*thetaT*(kT_ZN/kT); 

% Solving for the relative price P=P(lambda,K,Q,GN)
PsiP  = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime) - K*v_P; 
P_K   = -(1/PsiP)*( (YN_K/PIprime) - deltaK ); 
P_Q   = (K/PsiP)*v_Q; 
P_ZT  = -(YN_ZT/PIprime)*(1/PsiP); 
P_ZN  = -(YN_ZN/PIprime)*(1/PsiP);

% Eigenvalues and Eigenvectors 
Upsilon_K = ( (YN_K/PIprime) - deltaK);                                                                        
Upsilon_P = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime); 
Sigma_K   = 0; 
Sigma_P   = -(R_P + (PI*kappa*v_P*deltaK)); 
Sigma_Q   = (r+deltaK) - (PI*kappa*v_Q*deltaK); 
 
x11 = Upsilon_K + (Upsilon_P*P_K);                                                                         
x12 = (Upsilon_P*P_Q);                                                                                                                                                                                                                     
x21 = Sigma_K + (Sigma_P*P_K);                        
x22 = Sigma_Q + (Sigma_P*P_Q);   

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
Xi_K  = (YT_K - ((1-alphaI)/alphaI)*P*YN_K); 
Xi_P  = ( (YT_P-CT_P) - ((1-alphaI)/alphaI)*P*(YN_P-CN_P) - phiI*((1-alphaI)/alphaI)*IN ); 
B_K   = (Xi_K + (Xi_P*P_K)); 
B_Q   = (Xi_P*P_Q); 
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G  = GT+ (P*GN);   

% TFP
a  = (1/(alphaI+(1-alphaI)*(thetaT/thetaN))); 
b  = a*(thetaT/thetaN); 
Z  = (ZT^a)/(ZN^b); 

% Investment 
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
I = deltaK*K; 
EI = PI*I; 
omegaI = PI*I/Y; 

% Net exports, current account and saving
NX  = YT-CT-GT-IT; 
CA  = (r*B) + YT - CT - GT - IT; 
A   = B + (PI*K); 
Tax = GT + (P*GN); 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
alphaL  = (WN*LN)/(W*L); 
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT); 
YTYN  = (YT/YN); 
LTLN  = (LT/LN);

% Consumption 
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 

% Sectoral ratios
omegaINYN = IN/YN; 
omegaITYT = IT/YT; 
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;
omegaYT   =  YT / Y;
omegaYN   =  (P)*YN/Y; 
omegaLT   =  LT / L;
omegaLN   =  LN / L; 

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model
cond1  = (1-thetaT)*(YT/KT)-RK;                               
cond2  = P*(1-thetaN)*(YN/KN)-RK;                             
cond3  = thetaT*(YT/LT)-WT;                                   
cond4  = P*thetaN*(YN/LN)-WN;                                 
cond5  = (LT*kT)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YT-CT-GT-IT+(r*B);                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10 = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LT+LN) - L;  
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);               
cond14 = (PC*C) - (CT+(P*CN));                                
cond15 = (W*L) - ((WT*LT)+(WN*LN));                                        
cond16 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond17 = Sav;                                                 
cond18 = (PC*C) - (CT+(P*CN));                                
cond19 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);            
cond20 = (PI*I) - (IT+(P*IN));                                
cond21 = (RK*K) - ((RKT*KT)+(RKN*KN));                        
cond22 = 1 - (omegaK + omegaL);                               
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kT > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f    PIprime: %9.3f',EI,PIprime));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector T');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('Profit             : %9.10f',PiT));

disp(' ');
disp('Partial derivatives CT and CN');
disp(sprintf('CN_P  :   %7.3f    CT_P    : %9.3f',CN_P,CT_P));

disp('Partial derivatives LT and LN');
disp(sprintf('LN_K        :   %7.3f  LT_K       : %9.3f',LN_K,LT_K));
disp(sprintf('LN_P        :   %7.3f  LT_P       : %9.3f',LN_P,LT_P));
disp(sprintf('LN_lamb     :   %7.3f  LT_lamb    : %9.3f',LN_lambda,LT_lambda));
disp(sprintf('LN_ZT       :   %7.3f  LT_ZT      : %9.3f',LN_ZT,LT_ZT));
disp(sprintf('LN_ZN       :   %7.3f  LT_ZN      : %9.3f',LN_ZN,LT_ZN));

disp('Partial derivatives kT and kN');
disp(sprintf('kN_P       :   %7.6f  kT_P       : %9.6f',kN_P,kT_P));    
disp(sprintf('kN_ZT      :   %7.6f  kT_ZT      : %9.6f',kN_ZT,kT_ZT));
disp(sprintf('kN_ZN      :   %7.6f  kT_ZN      : %9.6f',kN_ZN,kT_ZN));

disp('Partial derivatives C');
disp(sprintf('YN_P       :   %7.6f  YT_P       : %9.6f',YN_P,YT_P));
disp(sprintf('YN_K       :   %7.6f  YT_K       : %9.6f',YN_K,YT_K));
disp(sprintf('YN_lambda  :   %7.3f  YT_lambda  : %9.3f',YN_lambda,YT_lambda));
disp(sprintf('YN_ZT      :   %7.6f  YT_ZT      : %9.6f',YN_ZT,YT_ZT));
disp(sprintf('YN_ZN      :   %7.6f  YT_ZN      : %9.6f',YN_ZN,YT_ZN));

disp('Partial derivatives of Y');
disp(sprintf('Y_P        :   %7.3f  Y_K        : %9.3f',Y_P,Y_K));
disp(sprintf('Y_ZT       :   %7.3f  Y_ZN       : %9.3f',Y_ZT,Y_ZN));
disp(sprintf('Y_lambda   : %9.3f',Y_lambda));

disp('Partial derivatives of L');
disp(sprintf('W_ZT       :   %7.3f  W_ZN       : %9.3f',W_ZT,W_ZN));
disp(sprintf('W_P        :   %7.3f  L_P        : %9.3f',W_P,L_P));
disp(sprintf('L_ZT       :   %7.3f  L_ZN       : %9.3f',L_ZT,L_ZN));
disp(sprintf('L_lambda   :   %7.3f  L_W        : %9.3f',L_lambda,L_W));

disp('Partial derivatives of W');
disp(sprintf('W_P        :   %7.3f',W_P));
disp(sprintf('W_ZT       :   %7.3f  W_ZN       : %9.3f',W_ZT,W_ZN));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');
disp('Linearization');
disp(sprintf('R_P       :  %5.4f',R_P));
disp(sprintf('R_ZT      :  %5.4f  R_ZN      : %5.4f',R_ZT,R_ZN));
disp(sprintf('PsiP      :  %5.4f  P_K       : %5.4f   P_Q     : %5.4f',PsiP,P_K,P_Q));
disp(sprintf('P_ZT      :  %5.4f  P_ZN      : %5.4f',P_ZT,P_ZN));
disp(sprintf('v_P       :  %5.4f  v_Q       : %5.4f',v_P,v_Q));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_P : %5.4f',Upsilon_K,Upsilon_P));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_P   : %5.4f   Sigma_Q : %5.4f',Sigma_K,Sigma_P,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KT = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LT = WT       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Resource constraint for labor     : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));
disp(sprintf('Private Savings                   : %9.16f   ',cond17));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));

kT_0 = kT;  kN_0 = kN; P_0 = P; LT_0 = LT; K_0 = K; C_0 = C;  
LN_0  = LN; L_0 = L; W_0 = W; 
YT_0  = YT; YN_0  = YN; Y_0  = Y; KT_0  = KT; KN_0  = KN; G_0 = G;     
PC_0 = PC; alphaC_0 = alphaC; CN_0 = CN; CT_0 = CT;  
ZT_0 = ZT; ZN_0 = ZN; Z_0 = Z; GT_0 = GT; GN_0 = GN; 
LT_0 = LT; LN_0 = LN; KT_0 = KT; KN_0 = KN; WT_0 = WT; WN_0 = WN; 
Omega_0 = Omega; YTYN_0 = YTYN; LTLN_0 = LTLN;

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IT_0 = IT; PI_0 = PI; alphaI_0 = alphaI; PIprime_0 = PIprime; EI_0 = EI; 
WPC_0 = WPC; WTPC_0 = WTPC; WNPC_0 = WNPC; alphaL_0 = alphaL; RK_0 = RK; PT_0 = 1; PN_0 = P; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaITYT_0 = omegaITYT; omegaGTYT_0 = omegaGTYT; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYT_0 = omegaYT; omegaYN_0 = omegaYN; omegaLT_0 = omegaLT; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; omegaKY_0 = omegaKY; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; alphaI_0 = alphaI; 
sLT_0 = sLT; sLN_0 = sLN;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Permanent Technology Shock                      %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GT       = GT_0; 
GN       = GN_0; 
%% Endogenous response of the ratio ZT/ZN to an exogenous technology shock 
%%%%%%%%%%%%%%%%%%% Calibration shock %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
filename = 'Calibration-file'; 
sheet    = 21;
xlRange  = 'B22:I39';
datac = xlsread(filename,sheet,xlRange);
param_OECD = [datac(18,8)/100  datac(18,4)/100 datac(18,7)/100 datac(18,3)/100 datac(18,1) datac(18,2)];
parameters = param_OECD;
gz       = parameters(1);      
gzT      = parameters(2);      
gzN      = ((a*gzT)-gz)/b;     
gz0      = parameters(3);      
gzT0     = parameters(4);      
gzN0     = ((a*gzT0)-gz0)/b;   
barzN    = gzN - gzN0;         
barzT    = gzT - gzT0;         
xiT      = parameters(5);      
xiN      = parameters(6);      
ZT       = ZT_0*(1+gzT);       
ZN       = ZN_0*(1+gzN);       
aT       = -ZT_0*barzT;        
aN       = -ZN_0*barzN;                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 =[C_0 L_0 kT_0 kN_0 W_0 LT_0 LN_0 P_0 K_0 B_0 CN_0 CT_0 PC_0 IN_0 IT_0 PI_0 YT_0 YN_0 lambda_0];
[x,fval,exitflag]=fsolve('TECH_PML_CAC_perm',x0,optimset('display','off','TolFun',1e-011));
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
IN      = x(14) ; % Non tradable investment
IT      = x(15) ; % Tradable investment 
PI      = x(16) ; % Investment price index
YT      = x(17) ; % Labor in sector T
YN      = x(18) ; % Labor in sector N  
lambda  = x(19) ; % Marginal utility of wealth lambda

% Sectoral outputs and sectoral profits   
KT  = LT*kT;  
RK  = (1-thetaT)*(YT/KT);
WT  = thetaT*(YT/LT); 
PiT = YT - (RK*KT) - (WT*LT);
  
KN  = LN*kN;  
WN  = P*thetaN*(YN/LN);
PiN = (P*YN) - (RK*KN) - (WN*LN);

% Labor income share in the traded good and non traded good sector
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN); 

% Capital Rental Rates
RKT = (1-thetaT)*(YT/KT);
RKN = P*(1-thetaN)*(YN/KN);; 

% GDP and shares in real terms
Y  = YT + (P*YN); 
YR = YT + (P_0*YN);
omegaYTR = YT/YR; 
omegaYNR = (P_0*YN)/YR; 

% Government spending 
G = GT+ (P*GN);   

% TFP
a  = (1/(alphaI+(1-alphaI)*(thetaT/thetaN))); 
b  = a*(thetaT/thetaN); 
Z  = (ZT^a)/(ZN^b); 

% Investment 
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
I       = deltaK*K; 
EI      = PI*I; 
omegaI  = PI*I/Y; 
PIprime = (1-varphiI)*(P/PI)^(-phiI);

% Shares
alphaC = P*CN/(PC*C); 
alphaI = P*IN/(PI*I); 
alphaL = WN*LN/(W*L); 

% Net exports, current account and saving
NX   = YT-CT-GT-IT; 
CA   = (r*B) + YT - CT - GT - IT; 
A    = B + (PI*K); 
Tax  = GT + (P*GN); 
Sav  = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT); 
YTYN  = (YT/YN); 
LTLN  = (LT/LN);

% Consumption 
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1));

% Partial derivatives CT=CT(P), CN=CN(P)
CT_P = alphaC*(CT/P)*(phi-sigmaC);
CN_P = - (CN/P)*(phi*(1-alphaC)+ (sigmaC*alphaC));

% Solution for C as function C=C(lambda,P) 
C_lambda  = -sigmaC*(C/lambda); 
C_P       = -alphaC*sigmaC*(C/P); 

% Solutions for kj=kj(P,ZT,ZN)
d11 = -(thetaT/kT); 
d12 =  (thetaN/kN);
d21 =  (1-thetaT)/kT; 
d22 = -(1-thetaN)/kN;  

e11 =  (1/P); 
e12 = -(1/ZT);
e13 =  (1/ZN);
e21 =  (1/P); 
e22 = -(1/ZT);
e23 =  (1/ZN);

M = [d11 d12; d21 d22];
X = [e11 e12 e13; e21 e22 e23];
JST = inv(M);
MST = JST*X;
kT_P = MST(1,1); kT_ZT = MST(1,2); kT_ZN = MST(1,3); 
kN_P = MST(2,1); kN_ZT = MST(2,2); kN_ZN = MST(2,3);   

% Solution for W as function W=W(P,ZT,ZN)  
W_P       = (1-thetaT)*(W/kT)*kT_P; 
W_ZT      = (WT/ZT) + (1-thetaT)*(W/kT)*kT_ZT; 
W_ZN      = (1-thetaT)*(W/kT)*kT_ZN;

% Solution for L as function L=L(lambda,P,ZT,ZN)
L_W      = sigmaL*(L/W);  
L_P      = L_W*W_P;
L_ZT     = L_W*W_ZT; 
L_ZN     = L_W*W_ZN;

% Solutions for Lj=Lj(K,P)
Psi_P  = ( (LT*kT_P) + (LN*kN_P) ); 
Psi_ZT = ( (LT*kT_ZT) + (LN*kN_ZT) );
Psi_ZN = ( (LT*kT_ZN) + (LN*kN_ZN) );

f11 = 1; 
f12 = 1;  
f21 = kT; 
f22 = kN;

g11 = 0; 
g12 = L_P;
g13 = L_ZT;
g14 = L_ZN;
g21 = 1; 
g22 = -Psi_P; 
g23 = -Psi_ZT;
g24 = -Psi_ZN;

M = [f11 f12; f21 f22];
X = [g11 g12 g13 g14; g21 g22 g23 g24];
JST = inv(M);
MST = JST*X;
LT_K = MST(1,1); LT_P = MST(1,2); LT_ZT = MST(1,3); LT_ZN = MST(1,4);  
LN_K = MST(2,1); LN_P = MST(2,2); LN_ZT = MST(2,3); LN_ZN = MST(2,4);   

% Solutions for sectoral labor and sectoral output Lj=Lj(lambda,P,K,ZT,ZN),
% Yj=Yj(lambda,P,K,ZT,ZN)
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YT_K = YT*(LT_K/LT); 
YN_K = YN*(LN_K/LN); 
YT_ZT = YT*( (1/ZT) + (LT_ZT/LT) + (1-thetaT)*(kT_ZT/kT) ); 
YN_ZT = YN*( (LN_ZT/LN) + (1-thetaN)*(kN_ZT/kN) );              
YT_ZN = YT*( (LT_ZN/LT) + (1-thetaT)*(kT_ZN/kT) );  
YN_ZN = YN*( (1/ZN) + (LN_ZN/LN) + (1-thetaN)*(kN_ZN/kN) );

% Solution for Y as function Y=Y(K,P,lambda,ZT,ZN) 
Y_P       = YT_P + (P*YN_P) + YN; 
Y_K       = YT_K + (P*YN_K); 
Y_ZT      = YT_ZT + (P*YN_ZT);
Y_ZN      = YT_ZN + (P*YN_ZN);

% Investment function I/K = v(Q/PI(P))+delta_K
v_Q = 1/(kappa*PI); 
v_P = -alphaI/(kappa*P); 

% Solution for R as function R=R(P,ZT,ZN) 
RK    = PI*(r+deltaK); 
R_P  = -RK*thetaT*(kT_P/kT); 
R_ZT = (RK/ZT) - RK*thetaT*(kT_ZT/kT); 
R_ZN = -RK*thetaT*(kT_ZN/kT); 

% Solving for the relative price P=P(lambda,K,Q,GN)
PsiP  = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime) - K*v_P; 
P_K   = -(1/PsiP)*( (YN_K/PIprime) - deltaK ); 
P_Q   = (K/PsiP)*v_Q; 
P_ZT  = -(YN_ZT/PIprime)*(1/PsiP); 
P_ZN  = -(YN_ZN/PIprime)*(1/PsiP);

% Eigenvalues and Eigenvectors 
Upsilon_K   = ( (YN_K/PIprime) - deltaK);                                                                        
Upsilon_P   = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime); 
Upsilon_ZT  = (YN_ZT/PIprime); 
Upsilon_ZN  = (YN_ZN/PIprime); 
Sigma_K     = 0; 
Sigma_P     = -(R_P + (PI*kappa*v_P*deltaK)); 
Sigma_Q     = (r+deltaK) - (PI*kappa*v_Q*deltaK); 
Sigma_ZT    = - R_ZT; 
Sigma_ZN    = - R_ZN;
 
x11   = Upsilon_K + (Upsilon_P*P_K);                                                                         
x12   = (Upsilon_P*P_Q);     
x13   = Upsilon_ZT + Upsilon_P*P_ZT; 
x14   = Upsilon_ZN + Upsilon_P*P_ZN; 
x21   = Sigma_K + (Sigma_P*P_K);                        
x22   = Sigma_Q + (Sigma_P*P_Q);
x23   = Sigma_ZT + Sigma_P*P_ZT; 
x24   = Sigma_ZN + Sigma_P*P_ZN; 
x31   = 0; 
x32   = 0; 
x33   = -xiT; 
x34   = 0; 
x41   = 0; 
x42   = 0; 
x43   = 0; 
x44   = -xiN; 

J = [x11 x12 x13 x14; x21 x22 x23 x24; x31 x32 x33 x34; x41 x42 x43 x44];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
nu_1 = nu(1,1);             
nu_2 = nu(2,2);             
nu_3 = nu(3,3);             
nu_4 = nu(4,4);             
                            
omega_11 = V(1,1)/V(1,1);   
omega_21 = V(2,1)/V(1,1);   
omega_31 = V(3,1)/V(1,1);   
omega_41 = V(4,1)/V(1,1);   
                            
omega_12 = V(1,2)/V(1,2);   
omega_22 = V(2,2)/V(1,2);   
omega_32 = V(3,2)/V(1,2);   
omega_42 = V(4,2)/V(1,2);   
                            
omega_13 = V(1,3)/V(3,3);   
omega_23 = V(2,3)/V(3,3);   
omega_33 = V(3,3)/V(3,3);   
omega_43 = V(4,3)/V(3,3);   
                            
omega_14 = V(1,4)/V(4,4);   
omega_24 = V(2,4)/V(4,4);   
omega_34 = V(3,4)/V(4,4);   
omega_44 = V(4,4)/V(4,4);   

TrJ = trace(J); 
DetJ = det(J); 

J1 = [x11 x12; x21 x22];
TrJ1 = trace(J1); 
DetJ1 = det(J1);

% Check for Eigenvectors
omega13 = -( x13*(x22+xiT) - (x12*x23) )/( (nu_1+xiT)*(nu_2+xiT) ); 
omega14 = -( x14*(x22+xiN) - (x12*x24) )/( (nu_1+xiN)*(nu_2+xiN) );
omega23 =  ( (x13*x21) - (x11+xiT)*x23 )/( (nu_1+xiT)*(nu_2+xiT) );
omega24 =  ( (x14*x21) - (x11+xiN)*x24 )/( (nu_1+xiN)*(nu_2+xiN) );

% Solve for Arbitrary Constants 
D3 = aT; 
D4 = aN; 
D1 = (K0 - K) - (omega_13*D3) - (omega_14*D4); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q,ZT,ZN);
% Xi_Q=0
Xi_K         = (YT_K - ((1-alphaI)/alphaI)*P*YN_K); 
Xi_P         = ( (YT_P-CT_P) - ((1-alphaI)/alphaI)*P*(YN_P-CN_P) - phiI*((1-alphaI)/alphaI)*IN ); 
Xi_ZT        = (YT_ZT - ((1-alphaI)/alphaI)*P*YN_ZT);
Xi_ZN        = (YT_ZN - ((1-alphaI)/alphaI)*P*YN_ZN);
B_K          = (Xi_K + (Xi_P*P_K)); 
B_Q          = (Xi_P*P_Q); 
B_ZT         = (Xi_ZT + (Xi_P*P_ZT)); 
B_ZN         = (Xi_ZN + (Xi_P*P_ZN)); 
N1           = (B_K + (B_Q*omega_21)); 
N2           = ((B_K*omega_13) + (B_Q*omega_23) + B_ZT); 
N3           = ((B_K*omega_14) + (B_Q*omega_24) + B_ZN); 
wB1          = N1/(r-nu_1); 
wBT          = N2/(r+xiT); 
wBN          = N3/(r+xiN);
%B            = B0 + (wB1*D1) + (wBT*aT) + (wBN*aN); 

% Solution for the stock of financial wealth
A0        = B0 + (PI*K0); 
Lambda_K  = 0; 
Lambda_P  = (((W_P*L)+(W*L_P)) - (CN + (PC*C_P) + GN)); 
Lambda_ZT = (W_ZT*L)+(W*L_ZT);
Lambda_ZN = (W_ZN*L)+(W*L_ZN);
A_K       = (Lambda_K + (Lambda_P*P_K)); 
A_Q       = (Lambda_P*P_Q); 
A_ZT      = (Lambda_ZT + (Lambda_P*P_ZT)); 
A_ZN      = (Lambda_ZN + (Lambda_P*P_ZN)); 
M1        = A_K + (A_Q*omega_21); 
M2        = ((A_K*omega_13) + (A_Q*omega_23) + A_ZT); 
M3        = ((A_K*omega_14) + (A_Q*omega_24) + A_ZN); 
wA1       = M1/(r-nu_1); 
wAT       = M2/(r+xiT); 
wAN       = M3/(r+xiN);
A         = A0 + (wA1*D1) + (wAT*D3) + (wAN*D4); 

% Solving for sectoral wages - Wj=Wj(lambda,K,Q,ZH,ZN)
WT_P  = W_P; 
WT_ZT = W_ZT; 
WT_ZN = W_ZN; 

WN_P  = W_P; 
WN_ZT = W_ZT; 
WN_ZN = W_ZN; 

% Solution for the labor income share sLj=sLj(K,P,ZH,ZN)               
sLT_K  = sLT*( (LT_K/LT) - (YT_K/YT) );                    
sLT_P  = sLT*( (WT_P/WT) + (LT_P/LT) - (YT_P/YT) );                    
sLT_ZT = sLT*( (WT_ZT/WT) + (LT_ZT/LT) - (YT_ZT/YT) );                 
sLT_ZN = sLT*( (WT_ZN/WT) + (LT_ZN/LT) - (YT_ZN/YT) );                 
                                                                       
sLN_K  = sLN*( (LN_K/LN) - (YN_K/YN) );         
sLN_P  = sLN*( (WN_P/WN) + (LN_P/LN) - (1/P) - (YN_P/YN) );         
sLN_ZT = sLN*( (WN_ZT/WN) + (LN_ZT/LN) - (YN_ZT/YN) );     
sLN_ZN = sLN*( (WN_ZN/WN) + (LN_ZN/LN) - (YN_ZN/YN) );  

% Sectoral ratios
omegaINYN = IN/YN; 
omegaITYT = IT/YT; 
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;
omegaYT   =  YT / Y;
omegaYN   =  (P*YN)/Y; 
omegaLT   =  LT / L;
omegaLN   =  LN / L; 

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
cond1  = (1-thetaT)*(YT/KT)-RK;                               
cond2  = P*(1-thetaN)*(YN/KN)-RK;                             
cond3  = thetaT*(YT/LT)-WT;                                   
cond4  = P*thetaN*(YN/LN)-WN;                                 
cond5  = (LT*kT)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI; 
cond7  = YN-CN-GN-IN;
cond8  = YT-CT-GT-IT+(r*B);
cond9  = (B-B0) - (wB1*D1) - (wBT*D3) - (wBN*D4);
cond10  = DetJ1 - (nu_1*nu_2);
cond11 = TrJ1 - (nu_1+nu_2); 
cond12 = (LT+LN) - L;
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);
cond14 = (PC*C) - (CT+(P*CN)); 
cond15 = (W*L) - ((WT*LT)+(WN*LN)); 
cond16 = Y - (PC*C) - G - (PI*I) + (r*B); 
cond17 = Sav; 
cond18 = (PC*C) - (CT+(P*CN)); 
cond19 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);
cond20 = (PI*I) - (IT+(P*IN)); 
cond21 = (RK*K) - ((RKT*KT)+(RKN*KN));
cond22 = 1 - (omegaK + omegaL); 
cond23 = omega_13 - omega13; 
cond24 = omega_14 - omega14; 
cond25 = omega_23 - omega23; 
cond26 = omega_24 - omega24; 
cond27 = nu_3 + xiT; 
cond28 = nu_4 + xiN; 

% Define New steady-state values
kT_pmlcac = kT; kN_pmlcac = kN; P_pmlcac = P; LT_pmlcac = LT; K_pmlcac = K; C_pmlcac = C;  
LN_pmlcac = LN; L_pmlcac  = L; W_pmlcac = W; 
YT_pmlcac = YT; YN_pmlcac = YN; Y_pmlcac = Y; KT_pmlcac  = KT; KN_pmlcac  = KN; G_pmlcac = G;     
PC_pmlcac = PC; alphaC_pmlcac = alphaC; CN_pmlcac = CN; CT_pmlcac = CT;  
GT_pmlcac = GT; GN_pmlcac = GN; ZT_pmlcac = ZT; ZN_pmlcac = ZN; Z_pmlcac = Z; 
LT_pmlcac = LT; LN_pmlcac = LN; KT_pmlcac = KT; KN_pmlcac = KN; WT_pmlcac = WT; WN_pmlcac = WN; 
Omega_pmlcac = Omega; WPC_pmlcac = WPC; WTPC_pmlcac = WTPC; WNPC_pmlcac = WNPC;

YTYN_pmlcac = YTYN; LTLN_pmlcac = LTLN; IT_pmlcac = IT; IN_pmlcac = IN; PI_pmlcac = PI; 
PIprime_pmlcac = PIprime; EI_pmlcac = EI; 
CA_pmlcac = CA; Sav_pmlcac = Sav; NX_pmlcac = NX; I_pmlcac = I; A_pmlcac = A; 
B_pmlcac = B; lambda_pmlcac  = lambda; RK_pmlcac = RK; YR_pmlcac = YR; 

omegaL_pmlcac = omegaL; omegaK_pmlcac = omegaK; omegaI_pmlcac = omegaI; omegaINYN_pmlcac = omegaINYN;
omegaITYT_pmlcac = omegaITYT; omegaGTYT_pmlcac = omegaGTYT; omegaGNYN_pmlcac = omegaGNYN; omegaGN_pmlcac = omegaGN;
omegaYT_pmlcac = omegaYT; omegaYN_pmlcac = omegaYN; omegaLT_pmlcac = omegaLT; omegaLN_pmlcac = omegaLN; 
omegaC_pmlcac =omegaC; omegaNX_pmlcac =omegaNX; omegaG_pmlcac =omegaG; omegaB_pmlcac =omegaB; omegaKY_pmlcac = omegaKY; 
alphaL_pmlcac = alphaL; alphaK_pmlcac = alphaK; alphaC_pmlcac = alphaC; alphaI_pmlcac = alphaI; 
omegaYTR_pmlcac = omegaYTR; omegaYNR_pmlcac = omegaYNR; sLT_pmlcac = sLT; sLN_pmlcac = sLN; 
% Steady-State Changes
dC       = C_pmlcac - C_0; % Steady-state change of real consumption 
dK       = K_pmlcac - K_0; % Steady-state change of real capital 
dL       = L_pmlcac - L_0; % Steady-state change of employment 
dP       = P_pmlcac - P_0; % Steady-state change of real exchange rate 
dB       = B_pmlcac - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_pmlcac - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = (YT_pmlcac+(P_pmlcac*YN_pmlcac)) - (YT_0+(P_0*YN_0)); % Steady-state change of real GDP 
dY_check = Y_pmlcac - Y_0; % Steady-state change of real GDP - Check
dA       = A_pmlcac - A_0; % Steady-state change of financial wealth 
dW       = W_pmlcac - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_pmlcac - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_pmlcac - Omega_0; % Steady-state change of the sector wage ratio

dCT   = CT_pmlcac - CT_0; % Steady-state change of cT
dCN   = CN_pmlcac - CN_0; % Steady-state change of cT
dLT   = LT_pmlcac - LT_0; % Steady-state change of real capital 
dLN   = LN_pmlcac - LN_0; % Steady-state change of employment 
dKT   = KT_pmlcac - KT_0; % Steady-state change of real capital 
dKN   = KN_pmlcac - KN_0; % Steady-state change of employment 
dYT   = YT_pmlcac - YT_0; % Steady-state change of YT
dYN   = YN_pmlcac - YN_0; % Steady-state change of YN
dWT   = WT_pmlcac - WT_0; % Steady-state change of WT
dWN   = WN_pmlcac - WN_0; % Steady-state change of WN
dWTPC = WTPC_pmlcac - WTPC_0; % Steady-state change of WT/PC
dWNPC = WNPC_pmlcac - WNPC_0; % Steady-state change of WN/PC
dkT   = kT_pmlcac - kT_0; % Steady-state change of kT 
dkN   = kN_pmlcac - kN_0; % Steady-state change of kN
dLTLN = LTLN_pmlcac - LTLN_0; % Steady-state change of LT/LN
dYTYN = YTYN_pmlcac - YTYN_0; % Steady-state change of LT/LN

dZT   = ZT_pmlcac - ZT_0; 
dZN   = ZN_pmlcac - ZN_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% Solution for investment PI*K, 
EK_1  = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK_T  = (PI*omega_13) + (K*omega_23);
EK_N  = (PI*omega_14) + (K*omega_24);
 
% Solution for the Relative Price of Non tradables P=P(lambda,K,Q,ZT,ZN)
wP_1  = P_K + (P_Q*omega_21); 
wP_T  = (P_K*omega_13) + (P_Q*omega_23) + P_ZT;
wP_N  = (P_K*omega_14) + (P_Q*omega_24) + P_ZN;

% Solution for the Relative Price of tradables PT = fixed
wPT_1 = 0; 
wPT_T = 0;
wPT_N = 0;

% Solution for Q(t)/PI(P(t))
wQPI_1 = (omega_21/PI) - (alphaI/P)*wP_1; 
wQPI_T = (omega_23/PI) - (alphaI/P)*wP_T;
wQPI_N = (omega_24/PI) - (alphaI/P)*wP_N;

% Solution for Consumption C=C(lambda,P)
wC_1 = (C_P*wP_1); 
wC_T = (C_P*wP_T); 
wC_N = (C_P*wP_N); 

% Solution for the Aggregate Wage Index W=W(K,P,ZT,ZN)
wW_1  = (W_P*wP_1); 
wW_T  = (W_P*wP_T) + W_ZT; 
wW_N  = (W_P*wP_N) + W_ZN;  

% Solution for the Aggregate Capital Rental Rate RK=R(K,P,ZT,ZN)
wR_1  = (R_P*wP_1); 
wR_T  = (R_P*wP_T) + R_ZT; 
wR_N  = (R_P*wP_N) + R_ZN; 

% Solution for the Real Wage W(K,P,ZT,ZN)/PC(P)
wWPC_1 = WPC*( (wW_1/W)-(alphaC/P)*wP_1 ); 
wWPC_T = WPC*( (wW_T/W)-(alphaC/P)*wP_T );
wWPC_N = WPC*( (wW_N/W)-(alphaC/P)*wP_N );

% Solution for the Labor L=L(lambda,W)=L(lambda,K,P,ZT,ZN)
wL_1  = (L_P*wP_1); 
wL_T  = (L_P*wP_T) + L_ZT; 
wL_N  = (L_P*wP_N) + L_ZN; 

% Solutions for the Sectoral Labor kj=kj(lambda,K,P,ZT,ZN)
wkT_1  = (kT_P*wP_1); 
wkT_T  = (kT_P*wP_T) + kT_ZT;
wkT_N  = (kT_P*wP_N) + kT_ZN; 

wkN_1  = (kN_P*wP_1); 
wkN_T  = (kN_P*wP_T) + kN_ZT;
wkN_N  = (kN_P*wP_N) + kN_ZN; 

% Solutions for the Sectoral Labor Lj=Lj(lambda,K,P,ZT,ZN)
wLT_1  = LT_K + (LT_P*wP_1); 
wLT_T  = (LT_K*omega_13) + (LT_P*wP_T) + LT_ZT;
wLT_N  = (LT_K*omega_14) + (LT_P*wP_N) + LT_ZN;

wLN_1  = LN_K + (LN_P*wP_1); 
wLN_T  = (LN_K*omega_13) + (LN_P*wP_T) + LN_ZT;
wLN_N  = (LN_K*omega_14) + (LN_P*wP_N) + LN_ZN;

% Solution for GDP Y=Y(lambda,K,P,ZT,ZN)
wY_1   = Y_K + (Y_P*wP_1);  
wY_T   = (Y_K*omega_13) + (Y_P*wP_T) + Y_ZT;
wY_N   = (Y_K*omega_14) + (Y_P*wP_N) + Y_ZN;

wYR_1  = YT_K + (P_0*YN_K) + (YT_P + (P_0*YN_P))*wP_1;  
wYR_T  = (YT_K + (P_0*YN_K))*omega_13 + (YT_P + (P_0*YN_P))*wP_T + (YT_ZT + (P_0*YN_ZT));
wYR_N  = (YT_K + (P_0*YN_K))*omega_14 + (YT_P + (P_0*YN_P))*wP_N + (YT_ZN + (P_0*YN_ZN));

% Solutions for the Sectoral Output Yj=Yj(lambda,K,P,ZT,ZN)
wYT_1  = YT_K + (YT_P*wP_1); 
wYT_T  = (YT_K*omega_13) + (YT_P*wP_T) + YT_ZT;
wYT_N  = (YT_K*omega_14) + (YT_P*wP_N) + YT_ZN;

wYN_1  = YN_K + (YN_P*wP_1); 
wYN_T  = (YN_K*omega_13) + (YN_P*wP_T) + YN_ZT;
wYN_N  = (YN_K*omega_14) + (YN_P*wP_N) + YN_ZN;

% Solutions for the Sectoral Wages Wj=Wj(K,P,ZT,ZN)
wWT_1  = (W_P*wP_1);                    
wWT_T  = (W_P*wP_T) + W_ZT;  
wWT_N  = (W_P*wP_N) + W_ZN; 
                                              
wWN_1  = (W_P*wP_1);                    
wWN_T  = (W_P*wP_T) + W_ZT; 
wWN_N  = (W_P*wP_N) + W_ZN; 

% Solutions for the Real Sectoral Wages Wj(K,P)/PC(P) 
wWTPC_1 = WTPC*( (wWT_1/WT)-(alphaC/P)*wP_1 );
wWTPC_T = WTPC*( (wWT_T/WT)-(alphaC/P)*wP_T );
wWTPC_N = WTPC*( (wWT_N/WT)-(alphaC/P)*wP_N );
                                           
wWNPC_1 = WNPC*( (wWN_1/WN)-(alphaC/P)*wP_1 );
wWNPC_T = WNPC*( (wWN_T/WN)-(alphaC/P)*wP_T );
wWNPC_N = WNPC*( (wWN_N/WN)-(alphaC/P)*wP_N );

% Solution for Omega = WN(K,P)/WT(K,P)
wOmega_1 = Omega*((wWN_1/WN) - (wWT_1/WT)); 
wOmega_T = Omega*((wWN_T/WN) - (wWT_T/WT)); 
wOmega_N = Omega*((wWN_N/WN) - (wWT_N/WT)); 

% Solution for YT(lambda,K,P,ZT,ZN)/YN(lambda,K,P,ZT,ZN)
wYTYN_1 = YTYN*((wYT_1/YT) - (wYN_1/YN));  
wYTYN_T = YTYN*((wYT_T/YT) - (wYN_T/YN));  
wYTYN_N = YTYN*((wYT_N/YT) - (wYN_N/YN));  

% Solution for LT(lambda,K,P,ZT,ZN)/LN(lambda,K,P,ZT,ZN)
wLTLN_1 = LTLN*((wLT_1/LT) - (wLN_1/LN));  
wLTLN_T = LTLN*((wLT_T/LT) - (wLN_T/LN));  
wLTLN_N = LTLN*((wLT_N/LT) - (wLN_N/LN));  

% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(lambda,K,P,ZT,ZN)
wYTS_1  = omegaYTR*((wYT_1/YT)-(wYR_1/YR)); 
wYTS_T  = omegaYTR*((wYT_T/YT)-(wYR_T/YR)); 
wYTS_N  = omegaYTR*((wYT_N/YT)-(wYR_N/YR)); 
                                         
wYNS_1  = omegaYNR*((wYN_1/YN)-(wYR_1/YR)); 
wYNS_T  = omegaYNR*((wYN_T/YN)-(wYR_T/YR)); 
wYNS_N  = omegaYNR*((wYN_N/YN)-(wYR_N/YR)); 

% Solutions for the employment shares Lj/L=(Lj/L)(lambda,K,P,ZT,ZN)
wLTS_1  = omegaLT*((wLT_1/LT)-(wL_1/L)); 
wLTS_T  = omegaLT*((wLT_T/LT)-(wL_T/L)); 
wLTS_N  = omegaLT*((wLT_N/LT)-(wL_N/L)); 
                                      
wLNS_1  = omegaLN*((wLN_1/LN)-(wL_1/L)); 
wLNS_T  = omegaLN*((wLN_T/LN)-(wL_T/L)); 
wLNS_N  = omegaLN*((wLN_N/LN)-(wL_N/L)); 

% Solutions for the employment shares sLj=LISj(lambda,K,P,ZT,ZN) -    
% sLj = Wj*Lj/(Pj*Yj) -                                               
wLIST_1 = sLT_K + (sLT_P*wP_1);                                   
wLIST_T = (sLT_K*omega_13) + (sLT_P*wP_T) + sLT_ZT;               
wLIST_N = (sLT_K*omega_14) + (sLT_P*wP_N) + sLT_ZN;               
                                                                      
wLISN_1 = sLN_K + (sLN_P*wP_1);                                   
wLISN_T = (sLN_K*omega_13) + (sLN_P*wP_T) + sLN_ZT;               
wLISN_N = (sLN_K*omega_14) + (sLN_P*wP_N) + sLN_ZN;  

% Solutions for the relative wages Wj/W: WjW=WjW(lambda,K,Q,ZT,ZN) -
wWTW_1 = (WT/W)*( (wWT_1/WT) - (wW_1/W) ); 
wWTW_T = (WT/W)*( (wWT_T/WT) - (wW_T/W) ); 
wWTW_N = (WT/W)*( (wWT_N/WT) - (wW_N/W) ); 
                                           
wWNW_1 = (WN/W)*( (wWN_1/WN) - (wW_1/W) ); 
wWNW_T = (WN/W)*( (wWN_T/WN) - (wW_T/W) ); 
wWNW_N = (WN/W)*( (wWN_N/WN) - (wW_N/W) );

% Transitional Paths 
Tm = 0; Tu = 1; Tg = 10;
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdZT0    = (ZT_0 - ZT_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathdZ0     = (Z_0 - Z_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdLTL0   = (LN_0 - LN_0) + 0*time0;
pathdLNL0   = (LT_0 - LT_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWT0    = (WT_0 - WT_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYTYN0  = (YTYN_0 - YTYN_0) + 0*time0;
pathdLTLN0  = (LTLN_0 - LTLN_0) + 0*time0;
pathdITY0   = (IN_0 - IN_0) + 0*time0;
pathdINY0   = (IT_0 - IT_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0; 
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLIST0  = (sLT_0 - sLT_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..10]
X1           = D1*exp(nu_1*time1); 
XT           = aT*exp(-xiT*time1);
XN           = aN*exp(-xiN*time1);
%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pathdZT1     = (( (ZT_pmlcac-ZT_0) +  XT )/ZT_0)*100;
pathdZN1     = (( (ZN_pmlcac-ZN_0) +  XN )/ZN_0)*100;
pathdZ1       = a*( (((ZT_pmlcac-ZT_0) + XT)/ZT_0) - b*(((ZN_pmlcac-ZN_0) + XN)/ZN_0) )*100; 
pathdQ1      = (((PI_pmlcac-PI_0) + (omega_21*X1) + (omega_23*XT) + (omega_23*XT))/PI_0)*100;
pathdP1      = (((P_pmlcac-P_0) + (wP_1*X1) + (wP_T*XT) + (wP_N*XN) )/P_0)*100;
pathCY1      = ( PC_0*((C_pmlcac-C_0) + (wC_1*X1) + (wC_T*XT) + (wC_N*XN) )/Y_0 )*100;
pathdQPI1    = ( (wQPI_1*X1) + (wQPI_T*XT) + (wQPI_N*XN) )*100;
pathdL1      = (((L_pmlcac-L_0)  + (wL_1*X1) + (wL_T*XT) + (wL_N*XN) )/L_0)*100;
pathdLTL1    = ( (1-alphaL_0)*((LT_pmlcac-LT_0) + (wLT_1*X1) + (wLT_T*XT) + (wLT_N*XN) )/LT_0)*100;
pathdLNL1    = ( alphaL_0*((LN_pmlcac-LN_0) + (wLN_1*X1) + (wLN_T*XT) + (wLN_N*XN) )/LN_0)*100;
pathdkTK1    = ( LT_0*((kT_pmlcac-kT_0) + (wkT_1*X1) + (wkT_T*XT) + (wkT_N*XN) )/K_0)*100;
pathdkNK1    = ( LN_0*((kN_pmlcac-kN_0) + (wkN_1*X1) + (wkN_T*XT) + (wkN_N*XN) )/K_0)*100;
pathdW1      = (((W_pmlcac-W_0) + (wW_1*X1) + (wW_T*XT) + (wW_N*XN) )/W_0)*100;
pathdR1      = (((RK_pmlcac-RK_0) + (wR_1*X1) + (wR_T*XT) + (wR_N*XN) )/RK_0)*100;                    
pathdWPC1    = (((WPC_pmlcac-WPC_0) + (wWPC_1*X1) + (wWPC_T*XT) + (wWPC_N*XN) )/WPC_0)*100;           
pathdY1      = (((Y_pmlcac-Y_0) + (wY_1*X1) + (wY_T*XT) + (wY_N*XN) )/Y_0)*100;                       
pathdYR1     = (((YR_pmlcac-Y_0) + (wYR_1*X1) + (wYR_T*XT) + (wYR_N*XN) )/Y_0)*100;                   
pathdYTY1    = (((YT_pmlcac-YT_0) + (wYT_1*X1) + (wYT_T*XT) + (wYT_N*XN) )/Y_0)*100;                  
pathdYNY1    = (P_0*((YN_pmlcac-YN_0) + (wYN_1*X1) + (wYN_T*XT) + (wYN_N*XN) )/Y_0)*100;            
pathdWT1     = (((WT_pmlcac-WT_0) + (wWT_1*X1) + (wWT_T*XT) + (wWT_N*XN) )/WT_0)*100;                 
pathdWN1     = (((WN_pmlcac-WN_0) + (wWN_1*X1) + (wWN_T*XT) + (wWN_N*XN) )/WN_0)*100;                 
pathdWTPC1   = (((WTPC_pmlcac-WTPC_0) + (wWTPC_1*X1) + (wWTPC_T*XT) + (wWTPC_N*XN) )/WTPC_0)*100;     
pathdWNPC1   = (((WNPC_pmlcac-WNPC_0) + (wWNPC_1*X1) + (wWNPC_T*XT) + (wWNPC_N*XN) )/WNPC_0)*100;   
pathdWTW1    = (( ((WT_pmlcac/W_pmlcac)-(WT_0/W_0)) + (wWTW_1*X1) + (wWTW_T*XT) + (wWTW_N*XN) )/(WT_0/W_0) )*100; 
pathdWNW1    = (( ((WN_pmlcac/W_pmlcac)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_T*XT) + (wWNW_N*XN) )/(WN_0/W_0) )*100; 

pathCAY1     = (( -(nu_1*wB1*X1) + (xiT*wBT*XT) + (xiN*wBN*XN) )/Y_0 )*100;
pathSY1      = (( -(nu_1*wA1*X1) + (xiT*wAT*XT) + (xiN*wAN*XN) )/Y_0 )*100;
pathIY1      = (( (nu_1*EK_1*X1) - (xiT*EK_T*XT) - (xiN*EK_N*XN) )/Y_0)*100; 

pathdOmega1  = (((Omega_pmlcac-Omega_0) + (wOmega_1*X1) + (wOmega_T*XT) + (wOmega_N*XN) )/Omega_0)*100; 
pathdYTYN1   = (1/P_0)*( (YTYN_pmlcac-YTYN_0) + (wYTYN_1*X1) + (wYTYN_T*XT) + (wYTYN_N*XN) )*100;
pathdLTLN1   = ( (LTLN_pmlcac-LTLN_0) + (wLTLN_1*X1) + (wLTLN_T*XT) + (wLTLN_N*XN) )*100;

%pathdLTS1    = ( (omegaLT_pmlcac-omegaLT_0) + (wLTS_1*X1) + (wLTS_T*XT) + (wLTS_N*XN) )*100;    
%pathdLNS1    = ( (omegaLN_pmlcac-omegaLN_0) + (wLNS_1*X1) + (wLNS_T*XT) + (wLNS_N*XN) )*100; 
pathdLTS1    = (1-alphaL_0)*(( (omegaLT_pmlcac-omegaLT_0) + (wLTS_1*X1) + (wLTS_T*XT) + (wLTS_N*XN) )/omegaLT_0)*100;    
pathdLNS1    = alphaL_0*(( (omegaLN_pmlcac-omegaLN_0) + (wLNS_1*X1) + (wLNS_T*XT) + (wLNS_N*XN) )/omegaLN_0)*100;  
pathdYTS1    = ( (omegaYTR_pmlcac-omegaYT_0) + (wYTS_1*X1) + (wYTS_T*XT) + (wYTS_N*XN) )*100;   
pathdYNS1    = ( (omegaYNR_pmlcac-omegaYN_0) + (wYNS_1*X1) + (wYNS_T*XT) + (wYNS_N*XN) )*100;   

pathdLIST1   = ( (sLT_pmlcac-sLT_0) + (wLIST_1*X1) + (wLIST_T*XT) + (wLIST_N*XN) )*100;
pathdLISN1   = ( (sLN_pmlcac-sLN_0) + (wLISN_1*X1) + (wLISN_T*XT) + (wLISN_N*XN) )*100;

pathdPT1     = (((P_0-P_0) + (wPT_1*X1) + (wPT_T*XT) + (wPT_N*XN) )/P_0)*100; % TOT

% Temporal paths over entire period
timeperm = [time0 time1];
pathdZT_pmlcac    = [pathdZT0  pathdZT1];
pathdZN_pmlcac    = [pathdZN0  pathdZN1];
pathdZ_pmlcac     = [pathdZ0   pathdZ1];
pathdQ_pmlcac     = [pathdQ0  pathdQ1];
pathdQPI_pmlcac   = [pathdQ0  pathdQPI1];
pathdP_pmlcac     = [pathdP0  pathdP1]; 
pathdPT_pmlcac    = [pathdP0  pathdPT1]; 
pathCY_pmlcac     = [pathCY0  pathCY1];                                             
pathdL_pmlcac     = [pathdL0  pathdL1];                
pathdLTL_pmlcac   = [pathdLTL0 pathdLTL1];             
pathdLNL_pmlcac   = [pathdLNL0 pathdLNL1]; 
pathdkTK_pmlcac   = [pathdLTL0 pathdkTK1];             
pathdkNK_pmlcac   = [pathdLNL0 pathdkNK1]; 
pathdW_pmlcac     = [pathdW0 pathdW1]; 
pathdR_pmlcac     = [pathdR0 pathdR1]; 
pathdWPC_pmlcac   = [pathdWPC0 pathdWPC1]; 
pathdY_pmlcac     = [pathdY0 pathdY1]; 
pathdYR_pmlcac    = [pathdY0 pathdYR1];
pathdYTY_pmlcac   = [pathdY0 pathdYTY1];               
pathdYNY_pmlcac   = [pathdY0 pathdYNY1];               
pathdWT_pmlcac    = [pathdWT0  pathdWT1];              
pathdWN_pmlcac    = [pathdWN0  pathdWN1]; 
pathdWTPC_pmlcac  = [pathdWT0 pathdWTPC1];
pathdWNPC_pmlcac  = [pathdWN0 pathdWNPC1];
pathdWTW_pmlcac   = [pathdWT0 pathdWTW1];   
pathdWNW_pmlcac   = [pathdWN0 pathdWNW1]; 

pathIY_pmlcac     = [pathIY0  pathIY1];                        
pathCAY_pmlcac    = [pathCAY0 pathCAY1];               
pathSY_pmlcac     = [pathSY0  pathSY1];

pathdOmega_pmlcac = [pathdOmega0 pathdOmega1];         
pathdYTYN_pmlcac  = [pathdYTYN0 pathdYTYN1];           
pathdLTLN_pmlcac  = [pathdLTLN0 pathdLTLN1];

pathdLTS_pmlcac   = [pathdLTL0 pathdLTS1];             
pathdLNS_pmlcac   = [pathdLNL0 pathdLNS1];
pathdYTS_pmlcac   = [pathdY0 pathdYTS1];             
pathdYNS_pmlcac   = [pathdY0 pathdYNS1];

pathdLIST_pmlcac  = [pathdLIST0 pathdLIST1];             
pathdLISN_pmlcac  = [pathdLISN0 pathdLISN1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZT/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Impact Effects of an Unanticipated Rise in dZT(0) = aT and dZN(0) = aN
X10           = D1; 
XT0           = aT;
XN0           = aN;

pathZTtime0       = ZT_pmlcac + XT0;  % initial level of TFP in the traded sector                                                                    
pathZNtime0       = ZN_pmlcac + XN0;  % initial level of TFP in the non traded sector                                                                
pathQtime0        = PI_pmlcac + (omega_21*X10) + (omega_23*XT0) + (omega_24*XN0);  % initial level of the shadow value of investment                                                       
pathCYtime0       = C_pmlcac + (wC_1*X10) + (wC_T*XT0) + (wC_N*XN0);  % initial level of real consumption                                            
pathLtime0        = L_pmlcac + (wL_1*X10) + (wL_T*XT0) + (wL_N*XN0);  % initial level of employment                                                  
pathLTtime0       = LT_pmlcac + (wLT_1*X10) + (wLT_T*XT0) + (wLT_N*XN0);  % initial level of employment in sector T                                  
pathLNtime0       = LN_pmlcac + (wLN_1*X10) + (wLN_T*XT0) + (wLN_N*XN0);  % initial level of employment in sector N                                  
pathPtime0        = P_pmlcac + (wP_1*X10) + (wP_T*XT0) + (wP_N*XN0);  % initial level of real exchange rate                                          
pathWtime0        = W_pmlcac + (wW_1*X10) + (wW_T*XT0) + (wW_N*XN0);  % initial level of the wage rate                                               
pathWPCtime0      = WPC_pmlcac + (wWPC_1*X10) + (wWPC_T*XT0) + (wWPC_N*XN0);  % initial level of W/PC                                                
pathYtime0        = Y_pmlcac + (wY_1*X10) + (wY_T*XT0) + (wY_N*XN0);  % initial level of Y                                                           
pathYRtime0       = YR_pmlcac + (wYR_1*X10) + (wYR_T*XT0) + (wYR_N*XN0);  % initial level of Y once non tradable inflation is controlled for         
pathYTtime0       = YT_pmlcac + (wYT_1*X10) + (wYT_T*XT0) + (wYT_N*XN0);  % initial level of YT                                                      
pathYNtime0       = YN_pmlcac + (wYN_1*X10) + (wYN_T*XT0) + (wYN_N*XN0);  % initial level of YN                                                      
pathWTtime0       = WT_pmlcac + (wWT_1*X10) + (wWT_T*XT0) + (wWT_N*XN0);  % initial level of WT                                                      
pathWNtime0       = WN_pmlcac + (wWN_1*X10) + (wWN_T*XT0) + (wWN_N*XN0);  % initial level of WN                                                      
pathWTPCtime0     = WTPC_pmlcac + (wWTPC_1*X10) + (wWTPC_T*XT0) + (wWTPC_N*XN0);  % initial level of WTPC                                            
pathWNPCtime0     = WNPC_pmlcac + (wWNPC_1*X10) + (wWNPC_T*XT0) + (wWNPC_N*XN0);  % initial level of WNPC   
pathdkTKtime0     = kT_pmlcac + (wkT_1*X10) + (wkT_T*XT0) + (wkT_N*XN0);
pathdkNKtime0     = kN_pmlcac + (wkN_1*X10) + (wkN_T*XT0) + (wkN_N*XN0);
pathWTWtime0      = (WT_pmlcac/W_pmlcac) + (wWTW_1*X10) + (wWTW_T*XT0) + (wWTW_N*XN0);  % initial level of WT/W 
pathWNWtime0      = (WN_pmlcac/W_pmlcac) + (wWNW_1*X10) + (wWNW_T*XT0) + (wWNW_N*XN0);  % initial level of WN/W 
                                                                                                                                                    
pathOmegatime0    = Omega_pmlcac + (wOmega_1*X10) + (wOmega_T*XT0) + (wOmega_N*XN0);  % initial level of the sector wage ratio                       
pathYTYNtime0     = YTYN_pmlcac + (wYTYN_1*X10) + (wYTYN_T*XT0) + (wYTYN_N*XN0);  % initial level of ratio YT/YN                                     
pathLTLNtime0     = LTLN_pmlcac + (wLTLN_1*X10) + (wLTLN_T*XT0) + (wLTLN_N*XN0);  % initial level of ratio LT/LN                                     
                                                                                                                                                    
pathLTStime0      =  omegaLT_pmlcac + (wLTS_1*X10) + (wLTS_T*XT0) + (wLTS_N*XN0);                                                                    
pathLNStime0      =  omegaLN_pmlcac + (wLNS_1*X10) + (wLNS_T*XT0) + (wLNS_N*XN0);                                                                    
pathYTStime0      =  omegaYTR_pmlcac + (wYTS_1*X10) + (wYTS_T*XT0) + (wYTS_N*XN0);                                                                   
pathYNStime0      =  omegaYNR_pmlcac + (wYNS_1*X10) + (wYNS_T*XT0) + (wYNS_N*XN0);   

pathLISTtime0      =  sLT_pmlcac + (wLIST_1*X10) + (wLIST_T*XT0) + (wLIST_N*XN0);      
pathLISNtime0      =  sLN_pmlcac + (wLISN_1*X10) + (wLISN_T*XT0) + (wLISN_N*XN0);  
                                                                                                                                                    
pathYtime0_check  = YT_pmlcac + (P_pmlcac*YN_pmlcac) + ((wYT_1*X10) + (wYT_T*XT0) + (wYT_N*XN0)) + (P_pmlcac)*((wYN_1*X10) + (wYN_T*XT0) + (wYN_N*XN0)) + (YN_pmlcac)*((wP_1*X10) + (wP_T*XT0) + (wP_N*XN0));  % initial level of Y

dZTtime0_pmlcac      = ((pathZTtime0 - ZT_0)/ZT_0)*100;  % initial response of TFP in the traded sector
dZNtime0_pmlcac      = ((pathZNtime0 - ZN_0)/ZN_0)*100;  % initial response of TFP in the non traded sector
dZtime0_pmlcac       = (a*((pathZTtime0 - ZT_0)/ZT_0) - b*((pathZNtime0 - ZN_0)/ZN_0))*100;  % initial response of the productivity differential
dCYtime0_pmlcac      = (PC_0*(pathCYtime0 - C_0)/Y_0)*100;  % initial response of real consumption 
dLtime0_pmlcac       = ((pathLtime0 - L_0)/L_0)*100; % initial response of employment
dLTtime0_pmlcac      = ((1-alphaL_0)*(pathLTtime0 - LT_0)/LT_0)*100; % initial response of employment in sector T 
dLNtime0_pmlcac      = (alphaL_0*(pathLNtime0 - LN_0)/LN_0)*100; % initial response of employment in sector N 
dLTLNtime0_pmlcac    = (pathLTLNtime0 - LTLN_0)*100; % initial response of ratio LT/LN 
dPtime0_pmlcac       = ((pathPtime0 - P_0)/P_0)*100; % initial response of real exchange rate
dWtime0_pmlcac       = ((pathWtime0 - W_0)/W_0)*100; % initial response of W 
dWPCtime0_pmlcac     = ((pathWPCtime0 - WPC_0)/WPC_0)*100; % initial response of W/PC 
dYtime0_pmlcac       = ((pathYtime0 - Y_0)/Y_0)*100; % initial response of Y
dYRtime0_pmlcac      = ((pathYRtime0 - Y_0)/Y_0)*100; % initial response of real GDP 
dYTtime0_pmlcac      = ((pathYTtime0 - YT_0)/Y_0)*100; % initial response of YT
dYNtime0_pmlcac      = (P_0*(pathYNtime0 - YN_0)/Y_0)*100; % initial response of YN
dYTYNtime0_pmlcac    = (1/P_0)*((pathYTYNtime0 - YTYN_0))*100; % initial response of ratio YT/YN 
dWTtime0_pmlcac      = ((pathWTtime0 - WT_0)/WT_0)*100; % initial response of wage in sector T 
dWNtime0_pmlcac      = ((pathWNtime0 - WN_0)/WN_0)*100; % initial response of wage in sector N 
dWTPCtime0_pmlcac    = ((pathWTPCtime0 - WTPC_0)/WTPC_0)*100; % initial response of real wage in sector T 
dWNPCtime0_pmlcac    = ((pathWNPCtime0 - WNPC_0)/WNPC_0)*100; % initial response of real wage in sector N 
dOmegatime0_pmlcac   = ((pathOmegatime0 - Omega_0)/Omega_0)*100; % initial response of the sector wage ratio
dYtime0_check_pmlcac = ((pathYtime0_check - Y_0)/Y_0)*100; % initial response of Y - Check with sectoral output responses
dkTKtime0_pmlcac     = (LT_0*(pathdkTKtime0-kT_0)/K_0)*100; % initial change in kT
dkNKtime0_pmlcac     = (LN_0*(pathdkNKtime0-kN_0)/K_0)*100; % initial change in kN
dPTtime0_pmlcac      = ((P_0 - P_0)/P_0)*100; % initial response of TOT
dPNtime0_pmlcac      = ((pathPtime0 - P_0)/P_0)*100; % initial response of the relative price of non tradables
dLISTtime0_pmlcac    = (pathLISTtime0-sLT_0)*100;
dLISNtime0_pmlcac    = (pathLISNtime0-sLN_0)*100;
dWTWtime0_pmlcac     = ((pathWTWtime0 - (WT_0/W_0))/(WT_0/W_0))*100; % initial response of WT/W 
dWNWtime0_pmlcac     = ((pathWNWtime0 - (WN_0/W_0))/(WN_0/W_0))*100; % initial response of WN/W 

dCAYtime0_pmlcac     = (( -(nu_1*wB1*X10) + (xiT*wBT*XT0) + (xiN*wBN*XN0) )/Y_0 )*100; % initial response of current account dot{B}(0)
dSYtime0_pmlcac      = (( -(nu_1*wA1*X10) + (xiT*wAT*XT0) + (xiN*wAN*XN0) )/Y_0 )*100; % initial response of saving dot{A}(0)
dIYtime0_pmlcac      = (( (nu_1*EK_1*X10) - (xiT*EK_T*XT0) - (xiN*EK_N*XN0) )/Y_0)*100; % initial response of investment dot{Q*K}(0)

dCAYtime0_pmlcac_check = dSYtime0_pmlcac - dIYtime0_pmlcac; 

dLTStime0_pmlcac     = ((pathLTStime0-omegaLT_0)/omegaLT_0)*(1-alphaL_0)*100; % Initial response of LT/L
dLNStime0_pmlcac     = ((pathLNStime0-omegaLN_0)/omegaLN_0)*alphaL_0*100; % Initial response of LN/L
dYTStime0_pmlcac     = (pathYTStime0-omegaYT_0)*100; % Initial response of YT/Y
dYNStime0_pmlcac     = (pathYNStime0-omegaYN_0)*100; % Initial response of YN/Y

% Changes at t=10                                                                                                              
hatt        = 10; % span of time t = [0..10]                                                                                   
X1_10          = D1*exp(nu_1*hatt);                                                                                            
XT_10          = aT*exp(-xiT*hatt);                                                                                            
XN_10          = aN*exp(-xiN*hatt);                                                                                            
                                                                                                                               
pathLTtime10     = LT_pmlcac + (wLT_1*X1_10) + (wLT_T*XT_10) + (wLT_N*XN_10);  %  level of employment in sector T              
pathLNtime10     = LN_pmlcac + (wLN_1*X1_10) + (wLN_T*XT_10) + (wLN_N*XN_10);  %  level of employment in sector N              
pathYTtime10     = YT_pmlcac + (wYT_1*X1_10) + (wYT_T*XT_10) + (wYT_N*XN_10);  %  level of YT                                  
pathYNtime10     = YN_pmlcac + (wYN_1*X1_10) + (wYN_T*XT_10) + (wYN_N*XN_10);  %  level of YN                                  
pathPtime10      = P_pmlcac + (wP_1*X1_10) + (wP_T*XT_10) + (wP_N*XN_10);  %  level of  PN                                     
pathLTStime10    = omegaLT_pmlcac + (wLTS_1*X1_10) + (wLTS_T*XT_10) + (wLTS_N*XN_10);  % Tome traded labor sTare               
pathYTStime10    = omegaYTR_pmlcac + (wYTS_1*X1_10) + (wYTS_T*XT_10) + (wYTS_N*XN_10); % Tome traded output sTare              
pathdkTKtime10   = kT_pmlcac + (wkT_1*X1_10) + (wkT_T*XT_10) + (wkT_N*XN_10);                                                  
pathdkNKtime10   = kN_pmlcac + (wkN_1*X1_10) + (wkN_T*XT_10) + (wkN_N*XN_10);                                                  
pathLISTtime10   = sLT_pmlcac + (wLIST_1*X1_10) + (wLIST_T*XT_10) + (wLIST_N*XN_10);  % Tome traded labor income sTare         
pathLISNtime10   = sLN_pmlcac + (wLISN_1*X1_10) + (wLISN_T*XT_10) + (wLISN_N*XN_10);  % Non traded labor income sTare          
pathWTWtime10    = (WT_pmlcac/W_pmlcac) + (wWTW_1*X1_10) + (wWTW_T*XT_10) + (wWTW_N*XN_10);  % level of WT/W                   
pathWNWtime10    = (WN_pmlcac/W_pmlcac) + (wWNW_1*X1_10) + (wWNW_T*XT_10) + (wWNW_N*XN_10);  % level of WN/W                                            

dLTtime10_pmlcac      = ((1-alphaL_0)*(pathLTtime10 - LT_0)/LT_0)*100; %  response of employment in sector T        
dLNtime10_pmlcac      = (alphaL_0*(pathLNtime10 - LN_0)/LN_0)*100; %  response of employment in sector N            
dYTtime10_pmlcac      = (PT_0*(pathYTtime10 - YT_0)/Y_0)*100; %  response of YT                                     
dYNtime10_pmlcac      = (PN_0*(pathYNtime10 - YN_0)/Y_0)*100; % response of YN at time t=10 in % of GDP             
dPTtime10_pmlcac      = ((PT_0 - PT_0)/PT_0)*100; %  response of PT                                                 
dPtime10_pmlcac       = ((pathPtime10 - P_0)/P_0)*100; %  response of PN/PT                                         
dLTStime10_pmlcac     = ((pathLTStime10-omegaLT_0)/omegaLT_0)*(1-alphaL_0)*100; %  response of LT/L                 
dYTStime10_pmlcac     = (pathYTStime10-omegaYT_0)*100; %  response of YT/Y                                          
dkTKtime10_pmlcac     = (LT_0*(pathdkTKtime10-kT_0)/K_0)*100;                                                       
dkNKtime10_pmlcac     = (LN_0*(pathdkNKtime10-kN_0)/K_0)*100;                                                       
dLISTtime10_pmlcac    = (pathLISTtime10-sLT_0)*100;                                                                 
dLISNtime10_pmlcac    = (pathLISNtime10-sLN_0)*100;                                                                 
dWTWtime10_pmlcac     = ((pathWTWtime0 - (WT_0/W_0))/(WT_0/W_0))*100; % response of WT/W                            
dWNWtime10_pmlcac     = ((pathWNWtime0 - (WN_0/W_0))/(WN_0/W_0))*100; % response of WN/W                            

% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_pmlcac       = (dlambda/lambda_0)*100; 
dCoverY_pmlcac         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
hatZN_pmlcac           = (dZN/ZN_0)*100; % Rate of change of the TFP in the non traded sector
hatZT_pmlcac           = (dZT/ZT_0)*100; % Rate of change of the TFP in the traded sector
hatZ_pmlcac            = (a*(dZT/ZT_0) - b*(dZN/ZN_0)); % Rate of change of the productivity differential
hatL_pmlcac            = (dL/L_0)*100; % Rate of change of employment
hatK_pmlcac            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLToverL_pmlcac        = (dLT/L_0)*100; % Rate of change of LT
dLNoverL_pmlcac        = (dLN/L_0)*100; % Rate of change of LN
dLTLN_pmlcac           =  dLTLN*100; %  Change of LT/LN
hatP_pmlcac            = (dP/P_0)*100; % Rate of change of the real exchange rate
hatPN_pmlcac           = (dP/P_0)*100; % Rate of change of the relative price of non tradables
hatPT_pmlcac           = ((dP-dP)/P_0)*100; % Rate of change of the TOT
dBoverY_pmlcac         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_pmlcac         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_pmlcac            = (dW/W_0)*100; % Rate of change of wage
hatWPC_pmlcac          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_pmlcac            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_pmlcac           = ((YR_pmlcac-Y_0)/Y_0)*100; % Rate of change of Real GDP
hatY_check_pmlcac      = (dY_check/Y_0)*100; % Rate of change of output
dYToverY_pmlcac        = (dYT/Y_0)*100; % Rate of change of YT
dYNoverY_pmlcac        = ((P_0*dYN)/Y_0)*100; % Rate of change of YN
dYTYN_pmlcac           = (dYTYN)*100; % Rate of change of YT/YN
hatWT_pmlcac           = (dWT/WT_0)*100; % Rate of change of WT
hatWN_pmlcac           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_pmlcac        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWTPC_pmlcac         = (dWTPC/WTPC_0)*100; % Rate of change of WT/PC
hatWNPC_pmlcac         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkT_pmlcac             = LT_0*(dkT/K_0)*100; % Rate of change of kT
dkN_pmlcac             = LN_0*(dkN/K_0)*100; % Rate of change of kN
domegaLT_pmlcac        = (omegaLT_pmlcac-omegaLT_0)*100; % change in  the labor share of T
domegaLN_pmlcac        = (omegaLN_pmlcac-omegaLN_0)*100; % change in the labor share of NT
domegaYTS_pmlcac       = (omegaYTR_pmlcac-omegaYT_0)*100; % change in the output share of T
domegaYNS_pmlcac       = (omegaYNR_pmlcac-omegaYN_0)*100; % change in the output share of NT
dLIST_pmlcac           = (sLT_pmlcac-sLT_0)*100; % Change in the labor income share T
dLISN_pmlcac           = (sLN_pmlcac-sLN_0)*100; % Change in the labor income share N
dWTW_pmlcac            = (((WT_pmlcac/W_pmlcac)-(WT_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage T   
dWNW_pmlcac            = (((WN_pmlcac/W_pmlcac)-(WN_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage N   


disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kT > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f    PIprime: %9.3f',EI,PIprime));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector T');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('Profit             : %9.10f',PiT));


disp('Relative Price P=P(lambda,K,Q,GN)');
disp(sprintf('PsiP     :   %7.3f ',PsiP));
disp(sprintf('P_K      :   %7.3f    P_Q    : %9.3f',P_K,P_Q));
disp(sprintf('P_ZT     :   %7.3f    P_ZN   : %9.3f',P_ZT,P_ZN));

disp('Linearization');
disp(sprintf('R_P       : %5.4f',R_P));
disp(sprintf('R_ZT      :  %5.4f  R_ZN      : %5.4f',R_ZT,R_ZN));
disp(sprintf('PsiP      :  %5.4f  P_K       : %5.4f   P_Q     : %5.4f',PsiP,P_K,P_Q));
disp(sprintf('P_ZT      :  %5.4f  P_ZN      : %5.4f',P_ZT,P_ZN));
disp(sprintf('v_P       :  %5.4f  v_Q       : %5.4f',v_P,v_Q));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_P : %5.4f',Upsilon_K,Upsilon_P));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_P   : %5.4f   Sigma_Q : %5.4f',Sigma_K,Sigma_P,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('nu3        :   %5.6f  nu4        : %5.6f',nu_3,nu_4));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));
disp(sprintf('TrJ1        :   %5.6f  DetJ1     : %5.6f',TrJ1,DetJ1));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega_21,omega_22));
disp(sprintf('omega13    :   %5.6f  omega14    : %5.6f',omega_13,omega_14));
disp(sprintf('omega23    :   %5.6f  omega24    : %5.6f',omega_23,omega_24));
disp(sprintf('omega31    :   %5.6f  omega32    : %5.6f',omega_31,omega_32));
disp(sprintf('omega41    :   %5.6f  omega42    : %5.6f',omega_41,omega_42));
disp(sprintf('omega33    :   %5.6f  omega34    : %5.6f',omega_33,omega_34));
disp(sprintf('omega43    :   %5.6f  omega44    : %5.6f',omega_43,omega_44));

disp('solutions at time t = 0 X10 X20');
disp(sprintf('X10       :   %5.3f  X20     : %5.3f XN0   : %5.3f',X10,XT0,XN0));
disp(sprintf('D1        :   %5.3f  D3      : %5.3f D4    : %5.3f',D1,D3,D4));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));
disp(' ');
disp(sprintf('Marginal product of KT = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LT = WT       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Resource constraint for labor     : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));
disp(sprintf('Private Savings                   : %9.16f   ',cond17));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));
disp(sprintf('omega_13 - omega13                : %9.16f   ',cond23));
disp(sprintf('omega_14 - omega14                : %9.16f   ',cond24));
disp(sprintf('omega_23 - omega23                : %9.16f   ',cond25));
disp(sprintf('omega_24 - omega24                : %9.16f   ',cond26));
disp(sprintf('nu_3 + xiT                        : %9.16f   ',cond27));
disp(sprintf('nu_4 + xiN                        : %9.16f   ',cond28));

disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_pmlcac        :         |           |%10.3f',hatlambda_pmlcac));
disp(sprintf('dZoverZ_pmlcac          :         |           |%10.3f',hatZ_pmlcac));
disp(sprintf('dZToverZT_pmlcac        :         |           |%10.3f',hatZT_pmlcac));
disp(sprintf('dZNoverZN_pmlcac        :         |           |%10.3f',hatZN_pmlcac));
disp(sprintf('dCoverY_pmlcac          :         |           |%10.3f',dCoverY_pmlcac));
disp(sprintf('dLoverL_pmlcac          :         |           |%10.3f',hatL_pmlcac));
disp(sprintf('dYoverY_pmlcac          :         |           |%10.3f',hatY_pmlcac));
disp(sprintf('dYoverY_check_pmlcac    :         |           |%10.3f',hatY_check_pmlcac));
disp(sprintf('dYRoverY_pmlcac         :         |           |%10.3f',hatYR_pmlcac));
disp(sprintf('dKoverK_pmlcac          :         |           |%10.3f',hatK_pmlcac));
disp(sprintf('dLToverL_pmlcac         :         |           |%10.3f',dLToverL_pmlcac));
disp(sprintf('dLNover_pmlcac          :         |           |%10.3f',dLNoverL_pmlcac));
disp(sprintf('dLTLN_pmlcac            :         |           |%10.3f',dLTLN_pmlcac));
disp(sprintf('dYToverY_pmlcac         :         |           |%10.3f',dYToverY_pmlcac));
disp(sprintf('dYNoverY_pmlcac         :         |           |%10.3f',dYNoverY_pmlcac));
disp(sprintf('dYTYN_pmlcac            :         |           |%10.3f',dYTYN_pmlcac));
disp(sprintf('hatP_pmlcac             :         |           |%10.3f',hatP_pmlcac));
disp(sprintf('hatPT_pmlcac            :         |           |%10.3f',hatPT_pmlcac));
disp(sprintf('hatPN_pmlcac            :         |           |%10.3f',hatPN_pmlcac));
disp(sprintf('dBoverY_pmlcac          :         |           |%10.3f',dBoverY_pmlcac));
disp(sprintf('dAoverY_pmlcac          :         |           |%10.3f',dAoverY_pmlcac));
disp(sprintf('dWoverW_pmlcac          :         |           |%10.3f',hatW_pmlcac));
disp(sprintf('dWPCoverWPC_pmlcac      :         |           |%10.3f',hatWPC_pmlcac));
disp(sprintf('dWToverWT_pmlcac        :         |           |%10.3f',hatWT_pmlcac));
disp(sprintf('dWNoverWN_pmlcac        :         |           |%10.3f',hatWN_pmlcac));
disp(sprintf('hatOmega_pmlcac         :         |           |%10.3f',hatOmega_pmlcac));
disp(sprintf('dWTPCoverWTPC_pmlcac    :         |           |%10.3f',hatWTPC_pmlcac));
disp(sprintf('dWNPCoverWNPC_pmlcac    :         |           |%10.3f',hatWNPC_pmlcac));
disp(sprintf('dkToverK_pmlcac         :         |           |%10.3f',dkT_pmlcac));
disp(sprintf('dkNoverK_pmlcac         :         |           |%10.3f',dkN_pmlcac));
disp(sprintf('domegaLT_pmlcac         :         |           |%10.3f',domegaLT_pmlcac));
disp(sprintf('domegaLN_pmlcac         :         |           |%10.3f',domegaLN_pmlcac));
disp(sprintf('domegaYTS_pmlcac        :         |           |%10.3f',domegaYTS_pmlcac));
disp(sprintf('domegaYNS_pmlcac        :         |           |%10.3f',domegaYNS_pmlcac));
disp(sprintf('dLIST_pmlcac            :         |           |%10.3f',dLIST_pmlcac));   
disp(sprintf('dLISN_pmlcac            :         |           |%10.3f',dLISN_pmlcac));   
disp(sprintf('dWTW_pmlcac             :         |           |%10.3f',dWTW_pmlcac));    
disp(sprintf('dWNW_pmlcac             :         |           |%10.3f',dWNW_pmlcac)); 

%disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dZtime0_pmlcac         :                |                 |%10.3f',dZtime0_pmlcac));
disp(sprintf('dZTtime0_pmlcac        :                |                 |%10.3f',dZTtime0_pmlcac));
disp(sprintf('dZNtime0_pmlcac        :                |                 |%10.3f',dZNtime0_pmlcac));
disp(sprintf('dCYtime0_pmlcac        :                |                 |%10.3f',dCYtime0_pmlcac));
disp(sprintf('dLtime0_pmlcac         :                |                 |%10.3f',dLtime0_pmlcac));
disp(sprintf('dLTtime0_pmlcac        :                |                 |%10.3f',dLTtime0_pmlcac));
disp(sprintf('dLNtime0_pmlcac        :                |                 |%10.3f',dLNtime0_pmlcac));
disp(sprintf('dLTLNtime0_pmlcac      :                |                 |%10.3f',dLTLNtime0_pmlcac));
disp(sprintf('dYtime0_pmlcac         :                |                 |%10.3f',dYtime0_pmlcac));
disp(sprintf('dYtime0_check          :                |                 |%10.3f',dYtime0_check_pmlcac));
disp(sprintf('dYRtime0_pmlcac        :                |                 |%10.3f',dYRtime0_pmlcac));
disp(sprintf('dYTtime0_pmlcac        :                |                 |%10.3f',dYTtime0_pmlcac));
disp(sprintf('dYNtime0_pmlcac        :                |                 |%10.3f',dYNtime0_pmlcac));
disp(sprintf('dYTYNtime0_pmlcac      :                |                 |%10.3f',dYTYNtime0_pmlcac));
disp(sprintf('dPtime0_pmlcac         :                |                 |%10.3f',dPtime0_pmlcac));
disp(sprintf('dSYtime0_pmlcac        :                |                 |%10.3f',dSYtime0_pmlcac));
disp(sprintf('dIYtime0_pmlcac        :                |                 |%10.3f',dIYtime0_pmlcac));
disp(sprintf('dCAYtime0_pmlcac       :                |                 |%10.5f',dCAYtime0_pmlcac)); 
disp(sprintf('dCAYtime0_pmlcac_check :                |                 |%10.5f',dCAYtime0_pmlcac_check)); 
disp(sprintf('dWtime0_pmlcac         :                |                 |%10.3f',dWtime0_pmlcac));
disp(sprintf('dWPCtime0_pmlcac       :                |                 |%10.3f',dWPCtime0_pmlcac));
disp(sprintf('dWTtime0_pmlcac        :                |                 |%10.3f',dWTtime0_pmlcac));
disp(sprintf('dWNtime0_pmlcac        :                |                 |%10.3f',dWNtime0_pmlcac));
disp(sprintf('dOmegatime0_pmlcac     :                |                 |%10.3f',dOmegatime0_pmlcac));
disp(sprintf('dWTPCtime0_pmlcac      :                |                 |%10.3f',dWTPCtime0_pmlcac));
disp(sprintf('dWNPCtime0_pmlcac      :                |                 |%10.3f',dWNPCtime0_pmlcac));
disp(sprintf('dPTtime0_pmlcac        :                |                 |%10.3f',dPTtime0_pmlcac));
disp(sprintf('dPNtime0_pmlcac        :                |                 |%10.3f',dPNtime0_pmlcac));
disp(sprintf('dkTKtime0_pmlcac       :                |                 |%10.3f',dkTKtime0_pmlcac));
disp(sprintf('dkNKtime0_pmlcac       :                |                 |%10.3f',dkNKtime0_pmlcac));
disp(sprintf('dLTStime0_pmlcac       :                |                 |%10.3f',dLTStime0_pmlcac));
disp(sprintf('dLNStime0_pmlcac       :                |                 |%10.3f',dLNStime0_pmlcac));
disp(sprintf('dYTStime0_pmlcac       :                |                 |%10.3f',dYTStime0_pmlcac));
disp(sprintf('dYNStime0_pmlcac       :                |                 |%10.3f',dYNStime0_pmlcac)); 
disp(sprintf('dWTWtime0_pmlcac       :                |                 |%10.3f',dWTWtime0_pmlcac));       
disp(sprintf('dWNWtime0_pmlcac       :                |                 |%10.3f',dWNWtime0_pmlcac));       
disp(sprintf('dLISTtime0_pmlcac      :                |                 |%10.3f',dLISTtime0_pmlcac));      
disp(sprintf('dLISNtime0_pmlcac      :                |                 |%10.3f',dLISNtime0_pmlcac));  

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT_0,omegaYN_0));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN_0,omegaITYT_0,omegaB_0));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y       :  %5.3f',omegaKY_0));

