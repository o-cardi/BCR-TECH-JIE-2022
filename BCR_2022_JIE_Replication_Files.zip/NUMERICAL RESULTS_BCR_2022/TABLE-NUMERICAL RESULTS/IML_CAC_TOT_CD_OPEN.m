global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global epsilon vartheta 
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF
global ZH ZN thetaH thetaN 
global B0 K0 
global xiH xiN barzH barzN gzH gzN gz gzH0 gzN0 aH aN

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% BENCH IML CAC TOT - epsilon =0.98, sigmaL=0.5, kH>kN    %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ZH_0         = 1.00;  
ZN_0         = 1.00;
omegaG       = 0.196; 
omegaGN      = 0.90; 
omegaGH      = 1;
thetaH_0     = 0.631; 
thetaN_0     = 0.682; 
sigmaL_0     = 1.6; 
gammaL       = 1; 
sigmaC_0     = 2;  
phi_0        = 1.2; %0.44;
varphi_0     = 0.513; 
rho_0        = 1.5;  
varphiH_0    = 0.841; 
epsilon_0    = 1.6; 
vartheta_0   = 0.395;
phiI_0       = 1.0000001;                    
iota_0       = 0.379;  
rhoI_0       = 1.5;  
iotaH_0      = 0.619; 
kappa        = 17; 
ex           = 1; 
nuX          = 1.695;
  
r            = 0.04; 
beta         = r; 
deltaK       = 0.093;

B0           = 0.1;
K0           = 0;


ZH           = ZH_0;       
ZN           = ZN_0;       
thetaH       = thetaH_0;   
thetaN       = thetaN_0;   
sigmaC       = sigmaC_0;  
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;
epsilon      = epsilon_0;  
vartheta     = vartheta_0;                            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.024   ; % Consumption 
L_ini        = 1.035   ; % Labor supply 
kH_ini       = 5.084   ; % Capital-labor ratio in sector H
WH_ini       = 1.725   ; % Wage rate in sector H
WN_ini       = 1.568   ; % Wage rate in sector N
W_ini        = 1.616   ; % Aggregate wage index
kN_ini       = 2.971   ; % Capital-labor ratio in sector N
PN_ini       = 2.262   ; % Relative price of non tradables
K_ini        = 3.785   ; % Stock of capital
PH_ini       = 1.5     ; % Terms of trade
B_ini        = 0.0001  ; % Stock of traded Bonds
alphaL_ini   = 0.664   ; % Non tradable share of compensation of employees
PC_ini       = 1.186   ; % Aggregate consumption price index
PT_ini       = 1.186   ; % Consumption price index for tradables
CN_ini       = 0.299   ; % Consumption in non tradables 
CH_ini       = 0.589   ; % Consumption in tradables 
CF_ini       = 0.4     ; % Consumption in foreign goods 
alphaC_ini   = 0.430   ; % Tradable content of consumption expenditure
alphaH_ini   = 0.5     ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 1.486   ; % Aggregate investment price index
PIT_ini      = 1.000   ; % Investment price index for traded goods
IN_ini       = 0.235   ; % Non traded investment
IH_ini       = 0.2     ; % Home goods investment
IF_ini       = 0.2     ; % Foreign goods investment
alphaI_ini   = 0.430   ; % Tradable content of investment expenditure
alphaIH_ini  = 0.5     ; % Home goods content of investment expenditure on traded goods
LH_ini       = 0.322   ; % Labor in sector H
LN_ini       = 0.712   ; % Labor in sector N 
GF_ini       = 0.03    ; % Government spending in foreign goods
GH_ini       = 0.03    ; % Government spending in home goods
GN_ini       = 0.21    ; % Government spending in non tradables 
YH_ini       = 2       ; % Output of home traded goods
YN_ini       = 1       ; % Output of non traded goods
XH_ini       = 0.5     ; % Exports of home traded goods
MF_ini       = 0.5     ; % Imports of foreign goods
LH_WH_ini    = 0.195   ; % Partial derivative of LH=LH(lambda,WH,WN) 
LH_WN_ini    = -0.060  ; % Partial derivative of LH=LH(lambda,WH,WN) 
LN_WH_ini    = -0.060  ; % Partial derivative of LN=LN(lambda,WH,WN) 
LN_WN_ini    = 0.393   ; % Partial derivative of LN=LN(lambda,WH,WN) 
lambda_ini   = 0.967    ; % Intertemporal Solvency Condition          
                                                          
x0 =[C_ini L_ini kH_ini WH_ini WN_ini W_ini kN_ini PN_ini K_ini PH_ini B_ini alphaL_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini LH_ini LN_ini GF_ini GN_ini GH_ini YH_ini YN_ini XH_ini MF_ini LH_WH_ini LH_WN_ini LN_WH_ini LN_WN_ini lambda_ini];
[x,fval,exitflag]=fsolve('TECH_IML_CAC_TOT_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
WH      = x(4)  ; % Wage rate in sector H
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
alphaL  = x(12) ; % Output per worker in sector N 
PC      = x(13) ; % Aggregate consumption price index
PT      = x(14) ; % Consumption price index for tradables
CN      = x(15) ; % Consumption in non tradables 
CH      = x(16) ; % Consumption in tradables 
CF      = x(17) ; % Consumption goods imports
alphaC  = x(18) ; % Tradable content of consumption expenditure 
alphaH  = x(19) ; % Home goods content of consumption expenditure 
PI      = x(20) ; % Aggregate investment price index
PIT     = x(21) ; % Investment price index for tradables
IN      = x(22) ; % Non tradable investment
IH      = x(23) ; % Investment in home goods
IF      = x(24) ; % Investment in foreign goods
alphaI  = x(25) ; % Tradable content of investment expenditure
alphaIH = x(26) ; % Home goods content of investment expenditure
LH      = x(27) ; % Labor in sector H
LN      = x(28) ; % Labor in sector N 
GF      = x(29) ; % Government spending in foreign goods
GN      = x(30) ; % Government spending in non tradables 
GH      = x(31) ; % Government spending in home traded goods
YH      = x(32) ; % Output of home traded goods
YN      = x(33) ; % Output of non traded goods
XH      = x(34) ; % Exports of home traded goods
MF      = x(35) ; % Imports of foreign goods
LH_WH   = x(36) ; % Partial derivative of LH=LH(lambda,WH,WN)
LH_WN   = x(37) ; % Partial derivative of LH=LH(lambda,WH,WN)
LN_WH   = x(38) ; % Partial derivative of LN=LN(lambda,WH,WN)
LN_WN   = x(39) ; % Partial derivative of LN=LN(lambda,WH,WN) 
lambda  = x(40) ; % Intertemporal Solvency Condition     

% Sectoral outputs and sectoral profits   
KH  = LH*kH;  
RK  = PH*(1-thetaH)*(YH/KH); 
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Partial derivatives of LH and LN
LH_1lamb   = sigmaL*LH/lambda; 
LN_1lamb   = sigmaL*LN/lambda;

% Labor income share in the home traded good and non traded good sector
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN); 

% Solutions for kj = kj(PN,PH,KZH,ZN,lambda), Lj=Lj(PN,PH,KZH,ZN,lambda)
Psi_WH   = ( (kH*LH_WH) + (kN*LN_WH) );
Psi_WN   = ( (kH*LH_WN) + (kN*LN_WN) );
Psi_lamb = ( (kH*LH_1lamb) + (kN*LN_1lamb) ); 

d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaH)/kH); 
d22 = 0;  
d23 = -(1/WH); 
d24 = 0; 
d31 = 0; 
d32 = ((1-thetaN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LH; 
d42 = LN; 
d43 = Psi_WH; 
d44 = Psi_WN; 

e11 = (1/PN); 
e12 = -(1/PH);
e13 = 0;
e14 = -(1/ZH);
e15 = (1/ZN); 
e16 = 0; 
e21 = 0; 
e22 = -(1/PH); 
e23 = 0;
e24 = -(1/ZH); 
e25 = 0; 
e26 = 0;
e31 = -(1/PN); 
e32 = 0; 
e33 = 0;
e34 = 0; 
e35 = -(1/ZN); 
e36 = 0; 
e41 = 0; 
e42 = 0; 
e43 = 1; 
e44 = 0; 
e45 = 0; 
e46 = -Psi_lamb;
    
M = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X = [e11 e12 e13 e14 e15 e16; e21 e22 e23 e24 e25 e26; e31 e32 e33 e34 e35 e36; e41 e42 e43 e44 e45 e46];
JST = inv(M);
MST = JST*X;
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1K = MST(1,3);  kH_1ZH = MST(1,4); kH_1ZN = MST(1,5); kH_1lambda = MST(1,6); 
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1K = MST(2,3);  kN_1ZH = MST(2,4); kN_1ZN = MST(2,5); kN_1lambda = MST(2,6); 
WH_PN = MST(3,1); WH_PH = MST(3,2); WH_1K = MST(3,3);  WH_1ZH = MST(3,4); WH_1ZN = MST(3,5); WH_1lambda = MST(3,6); 
WN_PN = MST(4,1); WN_PH = MST(4,2); WN_1K = MST(4,3);  WN_1ZH = MST(4,4); WN_1ZN = MST(4,5); WN_1lambda = MST(4,6);   

% Intermediate solutions for sectoral labor and sectoral output - Yj=Yj(PN,PH,K,ZH,ZN)
LH_PN = (LH_WH*WH_PN) + (LH_WN*WN_PN); 
LN_PN = (LN_WH*WH_PN) + (LN_WN*WN_PN); 
LH_PH = (LH_WH*WH_PH) + (LH_WN*WN_PH); 
LN_PH = (LN_WH*WH_PH) + (LN_WN*WN_PH);
LH_1K = (LH_WH*WH_1K) + (LH_WN*WN_1K); 
LN_1K = (LN_WH*WH_1K) + (LN_WN*WN_1K);

YH_PN = YH*( (LH_PN/LH) + (1-thetaH)*(kH_PN/kH) ); 
YN_PN = YN*( (LN_PN/LN) + (1-thetaN)*(kN_PN/kN) ); 
YH_PH = YH*( (LH_PH/LH) + (1-thetaH)*(kH_PH/kH) ); 
YN_PH = YN*( (LN_PH/LN) + (1-thetaN)*(kN_PH/kN) );
YH_1K = YH*( (LH_1K/LH)  + (1-thetaH)*(kH_1K/kH) ); 
YN_1K = YN*( (LN_1K/LN)  + (1-thetaN)*(kN_1K/kN) ); 

LH_1lambda = LH_1lamb + (LH_WH*WH_1lambda) + (LH_WN*WN_1lambda);
LN_1lambda = LN_1lamb + (LN_WH*WH_1lambda) + (LN_WN*WN_1lambda);
LH_1ZH     = (LH_WH*WH_1ZH) + (LH_WN*WN_1ZH); 
LN_1ZH     = (LN_WH*WH_1ZH) + (LN_WN*WN_1ZH);
LH_1ZN     = (LH_WH*WH_1ZN) + (LH_WN*WN_1ZN);               
LN_1ZN     = (LN_WH*WH_1ZN) + (LN_WN*WN_1ZN); 

YH_1lambda = YH*( (LH_1lambda/LH) + (1-thetaH)*(kH_1lambda/kH) ); 
YN_1lambda = YN*( (LN_1lambda/LN) + (1-thetaN)*(kN_1lambda/kN) ); 
YH_1ZH     = YH*( (1/ZH) + (LH_1ZH/LH) + (1-thetaH)*(kH_1ZH/kH) ); 
YN_1ZH     = YN*( (LN_1ZH/LN) + (1-thetaN)*(kN_1ZH/kN) );             
YH_1ZN     = YH*( (LH_1ZN/LH) + (1-thetaH)*(kH_1ZN/kH) );  
YN_1ZN     = YN*( (1/ZN) + (LN_1ZN/LN) + (1-thetaN)*(kN_1ZN/kN) ); 

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

CH_1lambda = -(CH/lambda)*sigmaC; 
CN_1lambda = -(CN/lambda)*sigmaC;
CF_1lambda = -(CF/lambda)*sigmaC;

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN,PN) -
% Intermediate Solution
PsiH_PH    = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN    = (YH_PN - CH_PN - JH_PN);
PH_PN      = -PsiH_PN/PsiH_PH; 
PH_1K      = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q      = JH_1Q/PsiH_PH; 
PH_1ZH     = -YH_1ZH/PsiH_PH; 
PH_1ZN     = -YH_1ZN/PsiH_PH; 
PH_1lambda = -(YH_1lambda - CH_1lambda)/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,ZH,ZN)
PsiN_PH   = (YN_PH - CN_PH - JN_PH); 
PsiN_PN   = ((YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN));
PN_K      = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q      =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 
PN_ZH     = -( YN_1ZH + (PsiN_PH*PH_1ZH) )/PsiN_PN; 
PN_ZN     = -( YN_1ZN + (PsiN_PH*PH_1ZN) )/PsiN_PN;
PN_lambda = -( YN_1lambda + (PsiN_PH*PH_1lambda) )/PsiN_PN;

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN) - Final
% Solution
PH_K      = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q      = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 
PH_ZH     = -( YH_1ZH + (PsiH_PN*PN_ZH) )/PsiH_PH; 
PH_ZN     = -( YH_1ZN + (PsiH_PN*PN_ZN) )/PsiH_PH; 
PH_lambda = -( (YH_1lambda-CH_1lambda) + (PsiH_PN*PN_lambda) )/PsiH_PH; 

% Solving for capital-labor ratios kj=kj(lambda,K,Q,ZH,ZN) - 
% sectoral labor Lj=Lj(lambda,K,Q,ZH,ZN) - sectoral output 
% Yj=Yj(lambda,K,Q,ZH,ZN) - Final Solutions
kH_K = kH_1K + (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = kN_1K + (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

kH_ZH = kH_1ZH + (kH_PH*PH_ZH) + (kH_PN*PN_ZH);
kH_ZN = kH_1ZN + (kH_PH*PH_ZN) + (kH_PN*PN_ZN);
kN_ZH = kN_1ZH + (kN_PH*PH_ZH) + (kN_PN*PN_ZH);
kN_ZN = kN_1ZN + (kN_PH*PH_ZN) + (kN_PN*PN_ZN); 

kH_lambda = kH_1lambda + (kH_PH*PH_lambda) + (kH_PN*PN_lambda);  
kN_lambda = kN_1lambda + (kN_PH*PH_lambda) + (kN_PN*PN_lambda);  

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

LH_ZH = LH_1ZH + (LH_PH*PH_ZH) + (LH_PN*PN_ZH); 
LH_ZN = LH_1ZN + (LH_PH*PH_ZN) + (LH_PN*PN_ZN); 
LN_ZH = LN_1ZH + (LN_PH*PH_ZH) + (LN_PN*PN_ZH); 
LN_ZN = LN_1ZN + (LN_PH*PH_ZN) + (LN_PN*PN_ZN); 

LH_lambda = LH_1lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda);   
LN_lambda = LN_1lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda);   

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

YH_ZH = YH_1ZH + (YH_PH*PH_ZH) + (YH_PN*PN_ZH);
YH_ZN = YH_1ZN + (YH_PH*PH_ZN) + (YH_PN*PN_ZN);
YN_ZH = YN_1ZH + (YN_PH*PH_ZH) + (YN_PN*PN_ZH);
YN_ZN = YN_1ZN + (YN_PH*PH_ZN) + (YN_PN*PN_ZN);

YH_lambda = YH_1lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);  
YN_lambda = YN_1lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda);  

% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CH_ZH     = (CH_PH*PH_ZH) + (CH_PN*PN_ZH);
CH_ZN     = (CH_PH*PH_ZN) + (CH_PN*PN_ZN);
CH_lambda = CH_1lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda); 

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CN_ZH     = (CN_PH*PH_ZH) + (CN_PN*PN_ZH);
CN_ZN     = (CN_PH*PH_ZN) + (CN_PN*PN_ZN);                       
CN_lambda = CN_1lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);  

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q); 
CF_ZH     = (CF_PH*PH_ZH) + (CF_PN*PN_ZH);
CF_ZN     = (CF_PH*PH_ZN) + (CF_PN*PN_ZN);                       
CF_lambda = CF_1lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);  

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_ZH      = (JH_PH*PH_ZH) + (JH_PN*PN_ZH); 
JH_ZN      = (JH_PH*PH_ZN) + (JH_PN*PN_ZN);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda); 

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JN_ZH      = (JN_PH*PH_ZH) + (JN_PN*PN_ZH);          
JN_ZN      = (JN_PH*PH_ZN) + (JN_PN*PN_ZN);          
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);  

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 
JF_ZH      = (JF_PH*PH_ZH) + (JF_PN*PN_ZH);         
JF_ZN      = (JF_PH*PH_ZN) + (JF_PN*PN_ZN);         
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda); 

XH_K      = XH_PH*PH_K; 
XH_Q      = XH_PH*PH_Q; 
XH_ZH     = XH_PH*PH_ZH;
XH_ZN     = XH_PH*PH_ZN;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K); 
MF_Q      = (CF_Q + JF_Q); 
MF_ZH     = (CF_ZH + JF_ZH); 
MF_ZN     = (CF_ZN + JF_ZN); 
MF_lambda = (CF_lambda + JF_lambda); 

% Solving for sectoral wages - Wj=Wj(lambda,K,Q,ZH,ZN)
WH_K      = WH_1K + (WH_PH*PH_K) + (WH_PN*PN_K); 
WH_Q      = (WH_PH*PH_Q) + (WH_PN*PN_Q); 
WH_ZH     = WH_1ZH + (WH_PH*PH_ZH) + (WH_PN*PN_ZH);
WH_ZN     = WH_1ZN + (WH_PH*PH_ZN) + (WH_PN*PN_ZN);
WH_lambda = WH_1lambda + (WH_PH*PH_lambda) + (WH_PN*PN_lambda);

WN_K      = WN_1K + (WN_PH*PH_K) + (WN_PN*PN_K);                 
WN_Q      = (WN_PH*PH_Q) + (WN_PN*PN_Q);                         
WN_ZH     = WN_1ZH + (WN_PH*PH_ZH) + (WN_PN*PN_ZH);              
WN_ZN     = WN_1ZN + (WN_PH*PH_ZN) + (WN_PN*PN_ZN);              
WN_lambda = WN_1lambda + (WN_PH*PH_lambda) + (WN_PN*PN_lambda); 

% Solution for W as function W=W(lambda,K,Q,ZH,ZN) 
W_WH      = (W/WH)*(1-alphaL); 
W_WN      = (W/WN)*alphaL; 
W_K       = (W_WH*WH_K) + (W_WN*WN_K); 
W_Q       = (W_WH*WH_Q) + (W_WN*WN_Q);
W_ZH      = (W_WH*WH_ZH) + (W_WN*WN_ZH); 
W_ZN      = (W_WH*WH_ZN) + (W_WN*WN_ZN);
W_lambda  = (W_WH*WH_lambda) + (W_WN*WN_lambda);
 
% Solution for L as function L=L(lambda,K,Q,ZH,ZN)
L_1lambda = sigmaL*(L/lambda);
L_W  = sigmaL*(L/W); 
L_WH = sigmaL*L*(1-alphaL)/WH; 
L_WN = sigmaL*L*alphaL/WN; 
L_K  = (L_WH*WH_K) + (L_WN*WN_K); 
L_Q  = (L_WH*WH_Q) + (L_WN*WN_Q);
L_ZH = (L_WH*WH_ZH) + (L_WN*WN_ZH); 
L_ZN = (L_WH*WH_ZN) + (L_WN*WN_ZN);
L_lambda  = L_1lambda + (L_WH*WH_lambda) + (L_WN*WN_lambda);

% Solution for C as function C=C(lambda,K,Q,ZH,ZN) 
C_1lambda  = -sigmaC*(C/lambda); 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_ZH       = (C_PH*PH_ZH) + (C_PN*PN_ZH);
C_ZN       = (C_PH*PH_ZN) + (C_PN*PN_ZN);
C_lambda   = C_1lambda + (C_PH*PH_lambda) + (C_PN*PN_lambda);

% Solution for PC=PC(PH,PN) - PC = PC(lambda,K,Q,ZH,ZF)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_ZH      = (PC/PH)*alphaC*alphaH*PH_ZH + (PC/PN)*(1-alphaC)*PN_ZH;
PC_ZN      = (PC/PH)*alphaC*alphaH*PH_ZN + (PC/PN)*(1-alphaC)*PN_ZN;
PC_lambda  = (PC/PH)*alphaC*alphaH*PH_lambda + (PC/PN)*(1-alphaC)*PN_lambda;

% Solution for PI=PI(PH,PN) - PI = PI(lambda,K,Q,ZH,ZF)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_ZH      = (PI/PH)*alphaI*alphaIH*PH_ZH + (PI/PN)*(1-alphaI)*PN_ZH;
PI_ZN      = (PI/PH)*alphaI*alphaIH*PH_ZN + (PI/PN)*(1-alphaI)*PN_ZN;
PI_lambda  = (PI/PH)*alphaI*alphaIH*PH_lambda + (PI/PN)*(1-alphaI)*PN_lambda;

% Solution for G=G(PH,PN) - G= G(lambda,K,Q,ZH,ZF)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_ZH       = (PH_ZH*GH) + (PN_ZH*GN);
G_ZN       = (PH_ZN*GH) + (PN_ZN*GN);
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Capital rental rates
RKH = PH*(1-thetaH)*(YH/KH); 
RKN = PN*(1-thetaN)*(YN/KN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(lambda,K,Q,ZH,ZF); 
P = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_ZH = (P/PN)*PN_ZH - (P/PH)*PH_ZH;
P_ZN = (P/PN)*PN_ZN - (P/PH)*PH_ZN;

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,ZH,ZN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_ZH      = (PH_ZH*YH) + (PH*YH_ZH) + (PN_ZH*YN) + (PN*YN_ZH);
Y_ZN      = (PH_ZN*YH) + (PH*YH_ZN) + (PN_ZN*YN) + (PN*YN_ZN);
Y_lambda  = (PH_lambda*YH) + (PH*YH_lambda) + (PN_lambda*YN) + (PN*YN_lambda);

% Marginal revenue of capital R = PN*partial YN/partial KN
RK   = PI*(r+deltaK); 
R_K  = (RK/PN)*PN_K - (RK/kN)*thetaN*kN_K; 
R_Q  = (RK/PN)*PN_Q - (RK/kN)*thetaN*kN_Q; 
R_ZH = (RK/PN)*PN_ZH - (RK/kN)*thetaN*kN_ZH; 
R_ZN = (RK/ZN) + (RK/PN)*PN_ZN - (RK/kN)*thetaN*kN_ZN; 
R_lambda = (RK/PN)*PN_lambda - (RK/kN)*thetaN*kN_lambda; 

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(lambda,K,Q,ZH,ZN) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_ZH = (v_PN*PN_ZH) + (v_PH*PH_ZH); 
v_ZN = (v_PN*PN_ZN) + (v_PH*PH_ZN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/G; 
omegaGF = GF/G; 

% TFP
a  = (1/((1-alphaI) + alphaI*(thetaH/thetaN))); 
b  = a*(thetaH/thetaN); 
Z  = (ZH^a)/(ZN^b); 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% L_H, L_N and FOC for LH and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LH^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_H     = ((vartheta)^(-1/epsilon))*(LH/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = G/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model
cond1  = PH*(1-thetaH)*(YH/KH)-RK;                               
cond2  = PN*(1-thetaN)*(YN/KN)-RK;                             
cond3  = PH*thetaH*(YH/LH)-WH;                                   
cond4  = PN*thetaN*(YN/LN)-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LH/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_H - (lambda*WH);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond21 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond22 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond23 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);    
cond25 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond26 = (PT*CT) - ((PH*CH)+CF); 
cond27 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond28 = (PIT*IT) - ((PH*IH)+IF); 
cond29 = r*B + (PH*XH) - MF; 
cond30 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaH  : %5.2f   thetaN   : %5.2f',thetaH,thetaN));
disp(sprintf('sLH     : %5.2f   sLN      : %5.2f',sLH,sLN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f ',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f ',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f ',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GH      : %5.2f   GN       : %5.2f  GF      : %5.2f G      : %5.2f',GH,GN,GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (benchmark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp('Price of Non Tradables in terms of Imports');
disp(sprintf('PsiN_PH     :   %7.3f  PsiN_PN     : %9.3f',PsiN_PH,PsiN_PN));
disp(sprintf('PN_Q        :   %7.3f  PN_K        : %9.3f',PN_Q,PN_K));
disp(sprintf('PN_ZH       :   %7.3f  PN_ZN       : %9.3f',PN_ZH,PN_ZN));

disp('Terms of Trade');
disp(sprintf('PH_1Q       :   %7.3f  PH_1K       : %9.3f PH_PN       : %9.3f',PH_1Q,PH_1K,PH_PN));
disp(sprintf('PH_1ZH      :   %7.3f  PH_1ZN      : %9.3f',PH_1ZH,PH_1ZN));
disp(sprintf('PsiH_PN     :   %7.3f  PsiH_PH     : %9.3f',PsiH_PN,PsiH_PH));
disp(sprintf('PH_Q        :   %7.3f  PH_K        : %9.3f',PH_Q,PH_K));
disp(sprintf('PH_ZH       :   %7.3f  PH_ZN       : %9.3f',PH_ZH,PH_ZN));

disp('Imports');
disp(sprintf('MF_Q        :   %7.3f  MF_K        : %9.3f',MF_Q,MF_K));
disp(sprintf('MF_ZH       :   %7.3f  MF_ZN       : %9.3f',MF_ZH,MF_ZN));
disp(sprintf('XH_Q        :   %7.3f  XH_K        : %9.3f',XH_Q,XH_K));
disp(sprintf('XH_ZH       :   %7.3f  XH_ZN       : %9.3f',XH_ZH,XH_ZN));

disp(' ');
disp('Partial derivatives CH and CN');
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));
disp(sprintf('CN_ZH       :   %7.3f  CH_ZH     : %9.3f',CN_ZH,CH_ZH));
disp(sprintf('CN_ZN       :   %7.3f  CH_ZN     : %9.3f',CN_ZN,CH_ZN));

disp('Partial derivatives LH and LN');
disp(sprintf('LN_WH       :   %7.3f  LH_WH      : %9.3f',LN_WH,LH_WH));
disp(sprintf('LN_WN       :   %7.3f  LH_WN      : %9.3f',LN_WN,LH_WN));
disp(sprintf('LN_lamb     :   %7.3f  LH_lamb    : %9.3f',LN_lambda,LH_lambda));
disp(sprintf('LN_ZH       :   %7.3f  LH_ZH      : %9.3f',LN_ZH,LH_ZH));
disp(sprintf('LN_ZN       :   %7.3f  LH_ZN      : %9.3f',LN_ZN,LH_ZN));


disp('Partial derivatives kH and kN');
disp(sprintf('kN_Q       :   %7.6f  kH_Q       : %9.6f',kN_Q,kH_Q));   
disp(sprintf('kN_K       :   %7.6f  kH_K       : %9.6f',kN_K,kH_K));  
disp(sprintf('kN_lambda  :   %7.3f  kH_lambda  : %9.3f',kN_lambda,kH_lambda));  
disp(sprintf('kN_ZH      :   %7.6f  kH_ZH      : %9.6f',kN_ZH,kH_ZH));
disp(sprintf('kN_ZN      :   %7.6f  kH_ZN      : %9.6f',kN_ZN,kH_ZN));

disp('Partial derivatives WH and WN');
disp(sprintf('WN_Q       :   %7.6f  WH_Q       : %9.6f',WN_Q,WH_Q));     
disp(sprintf('WN_K       :   %7.6f  WH_K       : %9.6f',WN_K,WH_K));    
disp(sprintf('WN_lambda  :   %7.3f  WH_lambda  : %9.3f',WN_lambda,WH_lambda)); 
disp(sprintf('WN_ZH      :   %7.6f  WH_ZH      : %9.6f',WN_ZH,WH_ZH));
disp(sprintf('WN_ZN      :   %7.6f  WH_ZN      : %9.6f',WN_ZN,WH_ZN));


disp('Partial derivatives LH and LN');
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));
disp(sprintf('LN_ZH      :   %7.6f  LH_ZH      : %9.6f',LN_ZH,LH_ZH));
disp(sprintf('LN_ZN      :   %7.6f  LH_ZN      : %9.6f',LN_ZN,LH_ZN));

disp('Partial derivatives C');
disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));
disp(sprintf('YN_ZH      :   %7.6f  YH_ZH      : %9.6f',YN_ZH,YH_ZH));
disp(sprintf('YN_ZN      :   %7.6f  YH_ZN      : %9.6f',YN_ZN,YH_ZN));

disp('Partial derivatives of Y');
disp(sprintf('Y_Q        :   %7.3f  Y_K        : %9.3f',Y_Q,Y_K));
disp(sprintf('Y_ZH       :   %7.3f  Y_ZN       : %9.3f',Y_ZH,Y_ZN));
disp(sprintf('Y_lambda   : %9.3f',Y_lambda));

disp('Partial derivatives of L');
disp(sprintf('L_H        :   %7.3f  L_N        : %9.3f',L_H,L_N));

disp('Partial derivatives of L');
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));
disp(sprintf('L_ZH       :   %7.3f  L_ZN       : %9.3f',L_ZH,L_ZN));
disp(sprintf('L_lambda   :   %7.3f  W_lambda   : %9.3f',L_lambda,W_lambda));

disp('Partial derivatives of W');
disp(sprintf('W_WH       :   %7.3f  W_WN       : %9.3f',W_WH,W_WN));
disp(sprintf('W_Q        :   %7.3f  W_K        : %9.3f',W_Q,W_K));
disp(sprintf('W_ZH       :   %7.3f  W_ZN       : %9.3f',W_ZH,W_ZN));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');
disp('Linearization');
disp(sprintf('R_lambda  :  %5.4f  R_K       : %5.4f   R_Q     : %5.4f',R_lambda,R_K,R_Q));
disp(sprintf('R_ZH      :  %5.4f  R_ZN      : %5.4f',R_ZH,R_ZN));
disp(sprintf('P_K       : %5.4f   P_Q       : %5.4f',P_K,P_Q));
disp(sprintf('P_ZH      :  %5.4f  P_ZN      : %5.4f',P_ZH,P_ZN));
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));
disp(sprintf('v_ZH      :  %5.4f  v_ZN      : %5.4f',v_ZH,v_ZN))
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LH/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLH) = lambda*WH     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond25));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond26));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond27));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond28));
disp(sprintf('Current account                   : %9.16f   ',cond29));
disp(sprintf('Current account                   : %9.16f   ',cond30));

kH_0CD = kH;  kN_0CD = kN; PN_0CD = PN; LH_0CD = LH; K_0CD = K; C_0CD = C;                       
LN_0CD  = LN; L_0CD = L; W_0CD = W; P_0CD = P;                                                   
YH_0CD  = YH; YN_0CD  = YN; Y_0CD  = Y; KH_0CD  = KH; KN_0CD  = KN; G_0CD = G;                   
PC_0CD = PC; alphaC_0CD = alphaC; CN_0CD = CN; CH_0CD = CH;                                      
ZH_0CD = ZH; ZN_0CD = ZN; Z_0CD = Z; GH_0CD = GH; GN_0CD = GN;                                   
LH_0CD = LH; LN_0CD = LN; KH_0CD = KH; KN_0CD = KN; WH_0CD = WH; WN_0CD = WN;                    
Omega_0CD = Omega; YHYN_0CD = YHYN; LHLN_0CD = LHLN;                                             
IF_0CD = IF; CF_0CD = CF; XH_0CD = XH; MF_0CD = MF; GF_0CD = GF; PH_0CD = PH;                    
PT_0CD = PT; PIT_0CD = PIT; CT_0CD = CT; IT_0CD = IT; GT_0CD = GT;                               
                                                                                                 
CA_0CD = CA; Sav_0CD = Sav; NX_0CD = NX; I_0CD = I; lambda_0CD  = lambda; A_0CD = A;             
B_0CD = B; IN_0CD = IN; IH_0CD = IH; PI_0CD = PI; alphaI_0CD = alphaI; EI_0CD = EI;              
WPC_0CD = WPC; WHPC_0CD = WHPC; WNPC_0CD = WNPC; alphaL_0CD = alphaL; RK_0CD = RK;               
                                                                                                 
omegaL_0CD = omegaL; omegaK_0CD = omegaK; omegaI_0CD = omegaI; omegaINYN_0CD = omegaINYN;        
omegaIHYH_0CD = omegaIHYH; omega_IFYH_0CD = omegaIFYH; omegaGHYH_0CD = omegaGHYH;                
omegaGFYH_0CD = omegaGFYH; omegaGNYN_0CD = omegaGNYN; omegaGN_0CD = omegaGN;                     
omegaYH_0CD = omegaYH; omegaYN_0CD = omegaYN; omegaLH_0CD = omegaLH; omegaLN_0CD = omegaLN;      
omegaC_0CD =omegaC; omegaNX_0CD =omegaNX; omegaG_0CD =omegaG; omegaB_0CD =omegaB;                
omegaIFYH_0CD = omegaIFYH; omegaGFYH_0CD = omegaGFYH; omegaIH_0CD = omegaIH;                     
omegaCH_0CD = omegaCH; omegaIF_0CD = omegaIF; omegaCF_0CD = omegaCF;                             
omegaGT_0CD = omegaGT; omegaGH_0CD = omegaGH; omegaGF_0CD = omegaGF;                             
omegaKY_0CD = omegaKY; omegaIH_0CD = omegaIH; omegaIF_0CD = omegaIF;                             
omegaXHY_0CD = omegaXHY; omegaXHYH_0CD = omegaXHYH;                                              
alphaL_0CD = alphaL; alphaK_0CD = alphaK; alphaC_0CD = alphaC;                                   
alphaI_0CD = alphaI; alphaH_0CD = alphaH; alphaIH_0CD = alphaIH;                                 
thetaT_0CD = thetaH; sLH_0CD = sLH; sLN_0CD = sLN; H1_0CD = H1;                                  
                                                                                                                                               
                                                                                                 

