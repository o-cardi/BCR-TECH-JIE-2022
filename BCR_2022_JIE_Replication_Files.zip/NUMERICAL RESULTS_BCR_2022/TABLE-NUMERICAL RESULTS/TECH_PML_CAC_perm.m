function g = TECH_PML_CAC_perm(x)

global sigmaC phi varphi 
global gammaL sigmaL phiI varphiI
global r deltaK 
global ZT ZN thetaT thetaN kappa
global B0 K0 GT GN 
global xiT xiN aT aN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
IN      = x(14) ; % Non tradable investment
IT      = x(15) ; % Tradable investment 
PI      = x(16) ; % Investment price index
YT      = x(17) ; % Labor in sector T
YN      = x(18) ; % Labor in sector N  
lambda  = x(19) ; % Marginal utility of wealth lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aggregate Consumption -  C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors  - kT and
% kN
g(3)= ZT*(1-thetaT)*(kT^(-thetaT)) -  P*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector T  - kT and kN
g(4)= ZT*thetaT*(kT^(1-thetaT)) - P*ZN*thetaN*(kN^(1-thetaN));

% Aggregate wage index  - W
g(5)= W - ZT*thetaT*(kT^(1-thetaT));

% sectoral labor allocation  - LT and LN 
g(6)= (LT+LN) - L;

% sectoral capital allocation  -  LT and LN - 
g(7)= (LT*kT) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate  
g(8)= P*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(10)= (r*B) + YT - CT - GT - IT;

% Consumption in non tradables - CN
g(11)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT 
g(12)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(13)= PC - ((varphi+(1-varphi)*P^(1-phi))^(1/(1-phi)));

% Non tradable Investment - IN
g(14)= IN - (deltaK*K)*(1-varphiI)*(P/PI)^(-phiI);

% Tradable Investment - IT 
g(15)= IT - (deltaK*K)*varphiI*(1/PI)^(-phiI);

% Investment price index - PI
g(16)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Output per worker in the traded sector - YT
g(17)= YT - ZT*LT*(kT^(1-thetaT)); 

% Output per worker in the non traded sector - YN
g(18)= YN - ZN*LN*(kN^(1-thetaN));

% Non tradable shares of consumption, investment, labor compensation
alphaC = (1-varphi)*(P/PC)^(1-phi);
alphaI = (1-varphiI)*(P/PI)^(1-phiI);

% Partial derivative of Investment price index - PIprime
PIprime = (1-varphiI)*(P/PI)^(-phiI);

% Partial derivatives CT=CT(P), CN=CN(P)
CT_P = alphaC*(CT/P)*(phi-sigmaC);
CN_P = - (CN/P)*(phi*(1-alphaC)+ (sigmaC*alphaC));

% Solutions for kj=kj(P,ZT,ZN)
d11 = -(thetaT/kT); 
d12 =  (thetaN/kN);
d21 =  (1-thetaT)/kT; 
d22 = -(1-thetaN)/kN;  

e11 =  (1/P); 
e12 = -(1/ZT);
e13 =  (1/ZN);
e21 =  (1/P); 
e22 = -(1/ZT);
e23 =  (1/ZN);

M = [d11 d12; d21 d22];
X = [e11 e12 e13; e21 e22 e23];
JST = inv(M);
MST = JST*X;
kT_P = MST(1,1); kT_ZT = MST(1,2); kT_ZN = MST(1,3); 
kN_P = MST(2,1); kN_ZT = MST(2,2); kN_ZN = MST(2,3);  

% Solution for W as function W=W(P,ZT,ZN)  
W_P       = (1-thetaT)*(W/kT)*kT_P; 
W_ZT      = (W/ZT) + (1-thetaT)*(W/kT)*kT_ZT; 
W_ZN      = (1-thetaT)*(W/kT)*kT_ZN;

% Solution for L as function L=L(lambda,P,ZT,ZN)
L_W      = sigmaL*(L/W);  
L_P      = L_W*W_P;
L_ZT     = L_W*W_ZT; 
L_ZN     = L_W*W_ZN;

% Solutions for Lj=Lj(K,P)
Psi_P  = ( (LT*kT_P) + (LN*kN_P) ); 
Psi_ZT = ( (LT*kT_ZT) + (LN*kN_ZT) );
Psi_ZN = ( (LT*kT_ZN) + (LN*kN_ZN) );

f11 = 1; 
f12 = 1;  
f21 = kT; 
f22 = kN;

g11 = 0; 
g12 = L_P;
g13 = L_ZT;
g14 = L_ZN;
g21 = 1; 
g22 = -Psi_P; 
g23 = -Psi_ZT;
g24 = -Psi_ZN;

M = [f11 f12; f21 f22];
X = [g11 g12 g13 g14; g21 g22 g23 g24];
JST = inv(M);
MST = JST*X;
LT_K = MST(1,1); LT_P = MST(1,2); LT_ZT = MST(1,3); LT_ZN = MST(1,4);   
LN_K = MST(2,1); LN_P = MST(2,2); LN_ZT = MST(2,3); LN_ZN = MST(2,4); 
 
% Solutions for sectoral labor and sectoral output
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YT_K = YT*(LT_K/LT); 
YN_K = YN*(LN_K/LN); 

YT_ZT = YT*( (1/ZT) + (LT_ZT/LT) + (1-thetaT)*(kT_ZT/kT) ); 
YN_ZT = YN*( (LN_ZT/LN) + (1-thetaN)*(kN_ZT/kN) ); 
YT_ZN = YT*( (LT_ZN/LT) + (1-thetaT)*(kT_ZN/kT) );  
YN_ZN = YN*( (1/ZN) + (LN_ZN/LN) + (1-thetaN)*(kN_ZN/kN) );

% Investment function I/K = v(Q/PI(P))+delta_K
v_Q = 1/(kappa*PI); 
v_P = -alphaI/(kappa*P); 

% Solution for R as function R=R(K,P,lambda,ZT,ZN) 
RK   = PI*(r+deltaK); 
R_P  = -RK*thetaT*(kT_P/kT); 
R_ZT = (RK/ZT) - RK*thetaT*(kT_ZT/kT); 
R_ZN = -RK*thetaT*(kT_ZN/kT); 

% Solving for the relative price P=P(lambda,K,Q,GN)
PsiP  = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime) - K*v_P; 
P_K   = -(1/PsiP)*( (YN_K/PIprime) - deltaK ); 
P_Q   = (K/PsiP)*v_Q; 
P_ZT  = -(YN_ZT/PIprime)*(1/PsiP); 
P_ZN  = -(YN_ZN/PIprime)*(1/PsiP);

% Eigenvalues and Eigenvectors 
Upsilon_K   = ( (YN_K/PIprime) - deltaK);                                                                        
Upsilon_P   = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime); 
Upsilon_ZT  = (YN_ZT/PIprime); 
Upsilon_ZN  = (YN_ZN/PIprime); 
Sigma_K     = 0; 
Sigma_P     = -(R_P + (PI*kappa*v_P*deltaK)); 
Sigma_Q     = (r+deltaK) - (PI*kappa*v_Q*deltaK); 
Sigma_ZT    = - R_ZT; 
Sigma_ZN    = - R_ZN;
 
x11   = Upsilon_K + (Upsilon_P*P_K);                                                                         
x12   = (Upsilon_P*P_Q);     
x13   = Upsilon_ZT + (Upsilon_P*P_ZT); 
x14   = Upsilon_ZN + (Upsilon_P*P_ZN); 
x21   = Sigma_K + (Sigma_P*P_K);                        
x22   = Sigma_Q + (Sigma_P*P_Q);
x23   = Sigma_ZT + (Sigma_P*P_ZT); 
x24   = Sigma_ZN + (Sigma_P*P_ZN); 
x31   = 0; 
x32   = 0; 
x33   = -xiT; 
x34   = 0; 
x41   = 0; 
x42   = 0; 
x43   = 0; 
x44   = -xiN;                                                                      

J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

% Solutions
omega_13 = -( x13*(x22+xiT) - (x12*x23) )/( (nu_1+xiT)*(nu_2+xiT) ); 
omega_14 = -( x14*(x22+xiN) - (x12*x24) )/( (nu_1+xiN)*(nu_2+xiN) );
omega_23 = ( (x13*x21) - (x11+xiT)*x23 )/( (nu_1+xiT)*(nu_2+xiT) );
omega_24 = ( (x14*x21) - (x11+xiN)*x24 )/( (nu_1+xiN)*(nu_2+xiN) );
D3 = aT; 
D4 = aN; 
D1 = (K0 - K) - (omega_13*D3) - (omega_14*D4); 

% Intertemporal solvency condition - lambda 
Xi_K         = (YT_K - ((1-alphaI)/alphaI)*P*YN_K); 
Xi_P         = ( (YT_P-CT_P) - ((1-alphaI)/alphaI)*P*(YN_P-CN_P) - phiI*((1-alphaI)/alphaI)*IN ); 
Xi_ZT        = (YT_ZT - ((1-alphaI)/alphaI)*P*YN_ZT);
Xi_ZN        = (YT_ZN - ((1-alphaI)/alphaI)*P*YN_ZN);
B_K          = (Xi_K + (Xi_P*P_K)); 
B_Q          = (Xi_P*P_Q); 
B_ZT         = (Xi_ZT + (Xi_P*P_ZT)); 
B_ZN         = (Xi_ZN + (Xi_P*P_ZN)); 
N1           = (B_K + (B_Q*omega_21)); 
N2           = ((B_K*omega_13) + (B_Q*omega_23) + B_ZT); 
N3           = ((B_K*omega_14) + (B_Q*omega_24) + B_ZN); 
wB1          = N1/(r-nu_1); 
wBT          = N2/(r+xiT); 
wBN          = N3/(r+xiN);
g(19) = (B - B0) - (wB1*D1) - (wBT*aT) - (wBN*aN);


