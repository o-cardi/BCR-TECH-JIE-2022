clc
clear


% Maxim duration for graphics
Tg = 100;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

IML_CAC_TOT_CES_BIAS_NORM;
IML_CAC_TOT_CES_NORM;
IML_CAC_TOT_CES_NORM_OPEN;
IML_CAC;
PML_CAC; 

%%%%%%%%%%% Table of Results %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
disp('TECH SHOCK - Impact Effects');
disp(sprintf('dZtime0              |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dZtime0_bias,dZtime0_ces,dZtime0_imlcac,dZtime0_pmlcac,dZtime0_open));
disp(sprintf('dZTtime0             |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dZHtime0_bias,dZHtime0_ces,dZTtime0_imlcac,dZTtime0_pmlcac,dZHtime0_open));
disp(sprintf('dZNtime0             |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dZNtime0_bias,dZNtime0_ces,dZNtime0_imlcac,dZNtime0_pmlcac,dZNtime0_open));
disp(' '); disp('IMPACT EFFECTS - Sectoral Output and Labor');
disp(sprintf('dLT0                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLHtime0_bias,dLHtime0_ces,dLTtime0_imlcac,dLTtime0_pmlcac,dLHtime0_open));
disp(sprintf('dLN0                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLNtime0_bias,dLNtime0_ces,dLNtime0_imlcac,dLNtime0_pmlcac,dLNtime0_open));
disp(sprintf('dYT0                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dYHtime0_bias,dYHtime0_ces,dYTtime0_imlcac,dYTtime0_pmlcac,dYHtime0_open));
disp(sprintf('dYN0                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dYNtime0_bias,dYNtime0_ces,dYNtime0_imlcac,dYNtime0_pmlcac,dYNtime0_open));
disp(' '); disp('IMPACT EFFECTS - Labor and value added share');
disp(sprintf('dLTS0overL           |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLHStime0_bias,dLHStime0_ces,dLTStime0_imlcac,dLTStime0_pmlcac,dLHStime0_open));
disp(sprintf('dWTW0                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dWHWtime0_bias,dWHWtime0_ces,dWTWtime0_imlcac,dWTWtime0_pmlcac,dWHWtime0_open));
disp(sprintf('dWNW0                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dWNWtime0_bias,dWNWtime0_ces,dWNWtime0_imlcac,dWNWtime0_pmlcac,dWNWtime0_open));
disp(sprintf('dYTS0overYR          |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dYHStime0_bias,dYHStime0_ces,dYTStime0_imlcac,dYTStime0_pmlcac,dYHStime0_open));
disp(' '); disp('IMPACT EFFECTS - Relative prices');
disp(sprintf('dP0                  |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dPtime0_bias,dPtime0_ces,dPtime0_imlcac,dPtime0_pmlcac,dPtime0_open));
disp(sprintf('dPH0                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dPHtime0_bias,dPHtime0_ces,dPTtime0_imlcac,dPTtime0_pmlcac,dPHtime0_open));
disp(' '); disp('IMPACT EFFECTS - Capital-labor ratios and LIS');
disp(sprintf('dkH0                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dkHKtime0_bias,dkHKtime0_ces,dkTKtime0_imlcac,dkTKtime0_pmlcac,dkHKtime0_open));
disp(sprintf('dkN0                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dkNKtime0_bias,dkNKtime0_ces,dkNKtime0_imlcac,dkNKtime0_pmlcac,dkNKtime0_open));
disp(sprintf('dLIST0               |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLISHtime0_bias,dLISHtime0_ces,dLISTtime0_imlcac,dLISTtime0_pmlcac,dLISHtime0_open));
disp(sprintf('dLISN0               |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLISNtime0_bias,dLISNtime0_ces,dLISNtime0_imlcac,dLISNtime0_pmlcac,dLISNtime0_open));
disp(' '); disp(' '); disp(' ');

disp('TECH SHOCK - Effects t=10');
%disp(sprintf('dZtime10             |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dZtime10_bias,dZtime10_ces,dZtime10_open,dZtime10_pmlcac,dZtime10_imlcac));
%disp(sprintf('dZTtime10            |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dZHtime10_bias,dZHtime10_ces,dZHtime10_open,dZHtime10_pmlcac,dZTtime10_imlcac));
%disp(sprintf('dZNtime10            |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dZtime10_bias,dZtime10_ces,dZtime10_open,dZtime10_pmlcac,dZtime10_imlcac));
disp(' '); disp('EFFECTS t=10 - Sectoral Output and Labor');
disp(sprintf('dLT10                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLHtime10_bias,dLHtime10_ces,dLTtime10_imlcac,dLTtime10_pmlcac,dLHtime10_open));
disp(sprintf('dLN10                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLNtime10_bias,dLNtime10_ces,dLNtime10_imlcac,dLNtime10_pmlcac,dLNtime10_open));
disp(sprintf('dYT10                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dYHtime10_bias,dYHtime10_ces,dYTtime10_imlcac,dYTtime10_pmlcac,dYHtime10_open));
disp(sprintf('dYN10                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dYNtime10_bias,dYNtime10_ces,dYNtime10_imlcac,dYNtime10_pmlcac,dYNtime10_open));
disp(' '); disp('EFFECTS t=10  - Labor and value added share');
disp(sprintf('dLTS10               |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLHStime10_bias,dLHStime10_ces,dLTStime10_imlcac,dLTStime10_pmlcac,dLHStime10_open));
disp(sprintf('dWTW10               |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dWHWtime10_bias,dWHWtime10_ces,dWTWtime10_imlcac,dWTWtime10_pmlcac,dWHWtime10_open));
disp(sprintf('dWNW10               |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dWNWtime10_bias,dWNWtime10_ces,dWNWtime10_imlcac,dWNWtime10_pmlcac,dWNWtime10_open));
disp(sprintf('dYTS10               |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dYHStime10_bias,dYHStime10_ces,dYTStime10_imlcac,dYTStime10_pmlcac,dYHStime10_open));
disp(' '); disp('EFFECTS t=10  - Relative prices');
disp(sprintf('dP10                 |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dPtime10_bias,dPtime10_ces,dPtime10_imlcac,dPtime10_pmlcac,dPtime10_open));
disp(sprintf('dPH10                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dPHtime10_bias,dPHtime10_ces,dPTtime10_imlcac,dPTtime10_pmlcac,dPHtime10_open));
disp(' '); disp('EFFECTS t=10  - Capital-labor ratios and LIS');
disp(sprintf('dkT10                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dkHKtime10_bias,dkHKtime10_ces,dkTKtime10_imlcac,dkTKtime10_pmlcac,dkHKtime10_open));
disp(sprintf('dkN10                |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dkNKtime10_bias,dkNKtime10_ces,dkNKtime10_imlcac,dkNKtime10_pmlcac,dkNKtime10_open));
disp(sprintf('dLIST10              |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLISHtime10_bias,dLISHtime10_ces,dLISTtime10_imlcac,dLISTtime10_pmlcac,dLISHtime10_open));
disp(sprintf('dLISN10              |%10.2f   |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |%10.2f  |',dLISNtime10_bias,dLISNtime10_ces,dLISNtime10_imlcac,dLISNtime10_pmlcac,dLISNtime10_open));
disp(' '); disp(' '); disp(' ');
