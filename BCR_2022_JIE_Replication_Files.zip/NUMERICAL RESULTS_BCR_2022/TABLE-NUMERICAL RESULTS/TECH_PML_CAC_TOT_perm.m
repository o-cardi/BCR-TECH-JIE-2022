function g = TECH_PML_CAC_TOT_perm(x)

global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX 
global gammaL sigmaL 
global r deltaK kappa
global GH GN GF
global ZH ZN thetaH thetaN 
global B0 K0 
global xiH xiN aH aN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LH      = x(6) ; % Labor in sector H
LN      = x(7) ; % Labor in sector N 
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
PC      = x(12) ; % Aggregate consumption price index
PT      = x(13) ; % Consumption price index for tradables
CN      = x(14) ; % Consumption in non tradables 
CH      = x(15) ; % Consumption in tradables 
CF      = x(16) ; % Consumption goods imports
PI      = x(17) ; % Aggregate investment price index
PIT     = x(18) ; % Investment price index for tradables
IN      = x(19) ; % Non tradable investment
IH      = x(20) ; % Investment in home goods
IF      = x(21) ; % Investment in foreign goods
YH      = x(22) ; % Output of home traded goods
YN      = x(23) ; % Output of non traded goods
XH      = x(24) ; % Exports of home traded goods
MF      = x(25) ; % Imports of foreign goods
lambda  = x(26) ; % Marginal utility of wealth lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Aggregate Consumption - C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors - kH and
% kN
g(3)= PH*ZH*(1-thetaH)*(kH^(-thetaH)) -  PN*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector H - kH and kN
g(4)= PH*ZH*thetaH*(kH^(1-thetaH)) - PN*ZN*thetaN*(kN^(1-thetaN));

% Aggregate wage index - W
g(5)= W - PH*ZH*thetaH*(kH^(1-thetaH));

% sectoral labor allocation  - LH and LN 
g(6)= (LH+LN) - L;

% sectoral capital allocation - LH and LN - 
g(7)= (LH*kH) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate - PN 
g(8)= PN*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(10)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(11)= (r*B) + (PH*XH) - MF;

% Consumption price index - PC=PC(PT,PN)
g(12)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(13)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(14)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(15)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(16)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Investment price index - PI=PI(PT,PN)
g(17)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(18)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(19)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(20)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(21)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Output in the home good sector - YH
g(22)= YH - ZH*LH*(kH^(1-thetaH)); 

% Output in the non traded sector - YN
g(23)= YN - ZN*LN*(kN^(1-thetaN));

% Export of home goods - XH
g(24)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(25)= MF - (CF+IF+GF);

% Non tradable shares of consumption, investment, labor compensation
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

% Intermediate solutions for kH, kN, LH, LN as functions of P,K 
d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d21 = ((1-thetaH)/kH); 
d22 = -((1-thetaN)/kN);
                                                          
e11 = (1/PN);                                                                                 
e12 = -(1/PH);                                                                                                                                                                  
e13 = -(1/ZH);                                                                                
e14 = (1/ZN);                                                                                 
e21 = (1/PN);                                                                                        
e22 = -(1/PH);                                                                                                                                                                    
e23 = -(1/ZH);                                                                                                                                                                    
e24 = (1/ZN);                                                                                
                                                                                                                                                                                 
M = [d11 d12; d21 d22];                     
X = [e11 e12 e13 e14; e21 e22 e23 e24];     
JST = inv(M);                                                                                 
MST = JST*X;                                                                                  
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1ZH = MST(1,3); kH_1ZN = MST(1,4); 
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1ZH = MST(2,3); kN_1ZN = MST(2,4);  

% Solution for W=W(PH,PN,ZH,ZN), L=L(lambda,PH,PN,ZH,ZN)
W_PH     = (W/PH) + (1-thetaH)*(W/kH)*kH_PH; 
W_PN     = (1-thetaH)*(W/kH)*kH_PN; 
W_1ZH    = (W/ZH) + (1-thetaH)*(W/kH)*kH_1ZH; 
W_1ZN    = (1-thetaH)*(W/kH)*kH_1ZN; 
L_W      = sigmaL*(L/W); 
L_PN     = L_W*W_PN;
L_PH     = L_W*W_PH;
L_1ZH    = L_W*W_1ZH;
L_1ZN    = L_W*W_1ZN;

% Solutions for Lj=Lj(K,P)
KC_PN  = ( (LH*kH_PN) + (LN*kN_PN) ); 
KC_PH  = ( (LH*kH_PH) + (LN*kN_PH) );
KC_ZH  = ( (LH*kH_1ZH) + (LN*kN_1ZH) ); 
KC_ZN  = ( (LH*kH_1ZN) + (LN*kN_1ZN) );

f11 = 1; 
f12 = 1;  
f21 = kH; 
f22 = kN;

g11 = 0; 
g12 = L_PN;
g13 = L_PH;
g14 = L_1ZH;
g15 = L_1ZN;
g21 = 1; 
g22 = -KC_PN; 
g23 = -KC_PH;
g24 = -KC_ZH; 
g25 = -KC_ZN; 

M = [f11 f12; f21 f22];
X = [g11 g12 g13 g14 g15; g21 g22 g23 g24 g25];
JST = inv(M);
MST = JST*X;
LH_1K = MST(1,1); LH_PN = MST(1,2); LH_PH = MST(1,3); LH_1ZH = MST(1,4); LH_1ZN = MST(1,5);
LN_1K = MST(2,1); LN_PN = MST(2,2); LN_PH = MST(2,3); LN_1ZH = MST(2,4); LN_1ZN = MST(2,5);

% Intermediate solutions for sectoral output - Yj=Yj(PN,PH,K,ZH,ZN)
YH_PN = YH*( (LH_PN/LH) + (1-thetaH)*(kH_PN/kH) ); 
YN_PN = YN*( (LN_PN/LN) + (1-thetaN)*(kN_PN/kN) ); 
YH_PH = YH*( (LH_PH/LH) + (1-thetaH)*(kH_PH/kH) ); 
YN_PH = YN*( (LN_PH/LN) + (1-thetaN)*(kN_PH/kN) );
YH_1K = YH*(LH_1K/LH); 
YN_1K = YN*(LN_1K/LN); 
YH_1ZH     = YH*( (1/ZH) + (LH_1ZH/LH) + (1-thetaH)*(kH_1ZH/kH) ); 
YN_1ZH     = YN*( (LN_1ZH/LN) + (1-thetaN)*(kN_1ZH/kN) );             
YH_1ZN     = YH*( (LH_1ZN/LH) + (1-thetaH)*(kH_1ZN/kH) );  
YN_1ZN     = YN*( (1/ZN) + (LN_1ZN/LN) + (1-thetaN)*(kN_1ZN/kN) );

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q) 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN,PN) -
% Intermediate Solution
PsiH_PH    = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN    = (YH_PN - CH_PN - JH_PN);
PH_PN      = -PsiH_PN/PsiH_PH; 
PH_1K      = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q      = JH_1Q/PsiH_PH; 
PH_1ZH     = -YH_1ZH/PsiH_PH; 
PH_1ZN     = -YH_1ZN/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,ZH,ZN)
PsiN_PH   = (YN_PH - CN_PH - JN_PH); 
PsiN_PN   = (YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN);
PN_K      = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q      =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 
PN_ZH     = -( YN_1ZH + (PsiN_PH*PH_1ZH) )/PsiN_PN; 
PN_ZN     = -( YN_1ZN + (PsiN_PH*PH_1ZN) )/PsiN_PN;

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN) - Final
% Solution
PH_K      = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q      = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 
PH_ZH     = -( YH_1ZH + (PsiH_PN*PN_ZH) )/PsiH_PH; 
PH_ZN     = -( YH_1ZN + (PsiH_PN*PN_ZN) )/PsiH_PH; 

% Solving for capital-labor ratios kj=kj(lambda,K,Q,ZH,ZN) - 
% sectoral labor Lj=Lj(lambda,K,Q,ZH,ZN) - sectoral output 
% Yj=Yj(lambda,K,Q,ZH,ZN) - Final Solutions
kH_K = (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

kH_ZH = kH_1ZH + (kH_PH*PH_ZH) + (kH_PN*PN_ZH);
kH_ZN = kH_1ZN + (kH_PH*PH_ZN) + (kH_PN*PN_ZN);
kN_ZH = kN_1ZH + (kN_PH*PH_ZH) + (kN_PN*PN_ZH);
kN_ZN = kN_1ZN + (kN_PH*PH_ZN) + (kN_PN*PN_ZN); 

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

LH_ZH = LH_1ZH + (LH_PH*PH_ZH) + (LH_PN*PN_ZH); 
LH_ZN = LH_1ZN + (LH_PH*PH_ZN) + (LH_PN*PN_ZN); 
LN_ZH = LN_1ZH + (LN_PH*PH_ZH) + (LN_PN*PN_ZH); 
LN_ZN = LN_1ZN + (LN_PH*PH_ZN) + (LN_PN*PN_ZN); 

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

YH_ZH = YH_1ZH + (YH_PH*PH_ZH) + (YH_PN*PN_ZH);
YH_ZN = YH_1ZN + (YH_PH*PH_ZN) + (YH_PN*PN_ZN);
YN_ZH = YN_1ZH + (YN_PH*PH_ZH) + (YN_PN*PN_ZH);
YN_ZN = YN_1ZN + (YN_PH*PH_ZN) + (YN_PN*PN_ZN);

% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CH_ZH     = (CH_PH*PH_ZH) + (CH_PN*PN_ZH);
CH_ZN     = (CH_PH*PH_ZN) + (CH_PN*PN_ZN);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CN_ZH     = (CN_PH*PH_ZH) + (CN_PN*PN_ZH);
CN_ZN     = (CN_PH*PH_ZN) + (CN_PN*PN_ZN);                       

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q); 
CF_ZH     = (CF_PH*PH_ZH) + (CF_PN*PN_ZH);
CF_ZN     = (CF_PH*PH_ZN) + (CF_PN*PN_ZN);                       
 
JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_ZH      = (JH_PH*PH_ZH) + (JH_PN*PN_ZH); 
JH_ZN      = (JH_PH*PH_ZN) + (JH_PN*PN_ZN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JN_ZH      = (JN_PH*PH_ZH) + (JN_PN*PN_ZH);          
JN_ZN      = (JN_PH*PH_ZN) + (JN_PN*PN_ZN);          

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 
JF_ZH      = (JF_PH*PH_ZH) + (JF_PN*PN_ZH);         
JF_ZN      = (JF_PH*PH_ZN) + (JF_PN*PN_ZN);         

XH_K      = XH_PH*PH_K; 
XH_Q      = XH_PH*PH_Q; 
XH_ZH     = XH_PH*PH_ZH;
XH_ZN     = XH_PH*PH_ZN;

MF_K      = (CF_K + JF_K); 
MF_Q      = (CF_Q + JF_Q); 
MF_ZH     = (CF_ZH + JF_ZH); 
MF_ZN     = (CF_ZN + JF_ZN); 

% Marginal revenue of capital R = PN*partial YN/partial KN
RK   = PI*(r+deltaK); 
R_K  = (RK/PN)*PN_K - (RK/kN)*thetaN*kN_K; 
R_Q  = (RK/PN)*PN_Q - (RK/kN)*thetaN*kN_Q; 
R_ZH = (RK/PN)*PN_ZH - (RK/kN)*thetaN*kN_ZH; 
R_ZN = (RK/ZN) + (RK/PN)*PN_ZN - (RK/kN)*thetaN*kN_ZN; 

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(lambda,K,Q,ZH,ZN) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_ZH = (v_PN*PN_ZH) + (v_PH*PH_ZH); 
v_ZN = (v_PN*PN_ZN) + (v_PH*PH_ZN);

% Eigenvalues and Eigenvectors 
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + (alphaI*phiI*I)*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + (alphaI*phiI*I)*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Upsilon_ZH = (I/IN)*(YN_ZH-CN_ZH) + (alphaI*phiI*I)*( (PN_ZH/PN) - (alphaIH/PH)*PH_ZH );
Upsilon_ZN = (I/IN)*(YN_ZN-CN_ZN) + (alphaI*phiI*I)*( (PN_ZN/PN) - (alphaIH/PH)*PH_ZN );
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 
Sigma_ZH    = -( R_ZH + (PI*kappa*v_ZH*deltaK) ); 
Sigma_ZN    = -( R_ZN + (PI*kappa*v_ZN*deltaK) ); 

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x13   = Upsilon_ZH; 
x14   = Upsilon_ZN; 
x21   = Sigma_K;                        
x22   = Sigma_Q;
x23   = Sigma_ZH; 
x24   = Sigma_ZN; 
x31   = 0; 
x32   = 0; 
x33   = -xiH; 
x34   = 0; 
x41   = 0; 
x42   = 0; 
x43   = 0; 
x44   = -xiN;                                                                      

J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

% Solutions
omega_13 = -( x13*(x22+xiH) - (x12*x23) )/( (nu_1+xiH)*(nu_2+xiH) ); 
omega_14 = -( x14*(x22+xiN) - (x12*x24) )/( (nu_1+xiN)*(nu_2+xiN) );
omega_23 = ( (x13*x21) - (x11+xiH)*x23 )/( (nu_1+xiH)*(nu_2+xiH) );
omega_24 = ( (x14*x21) - (x11+xiN)*x24 )/( (nu_1+xiN)*(nu_2+xiN) );
D3 = aH; 
D4 = aN; 
D1 = (K0 - K) - (omega_13*D3) - (omega_14*D4); 

% Intertemporal solvency condition - lambda 
B_K          = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_ZH         = (PH_ZH*XH) + (PH*XH_ZH) - MF_ZH; 
B_ZN         = (PH_ZN*XH) + (PH*XH_ZN) - MF_ZN;
N1           = (B_K + (B_Q*omega_21)); 
N2           = ((B_K*omega_13) + (B_Q*omega_23) + B_ZH); 
N3           = ((B_K*omega_14) + (B_Q*omega_24) + B_ZN); 
wB1          = N1/(r-nu_1); 
wBH          = N2/(r+xiH); 
wBN          = N3/(r+xiN);
g(26) = (B - B0) - (wB1*D1) - (wBH*aH) - (wBN*aN);


