global sigmaC phi varphi rho varphiH beta
global phiI iota rhoI iotaH 
global ex nuX
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF
global ZH ZN thetaH thetaN 
global B0 K0 
global xiH xiN barzH barzN gzH gzN gz gzH0 gzN0 aH aN

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% PML CAC TOT  kH>kN                                      %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ZH_0         = 1.00;  
ZN_0         = 1.00;
omegaG       = 0.196; 
omegaGN      = 0.90; 
omegaGH      = 1;
thetaH_0     = 0.631; 
thetaN_0     = 0.682; 
sigmaL_0     = 1.6; 
gammaL       = 1; 
sigmaC_0     = 2;  
phi_0        = 0.44;
varphi_0     = 0.513; 
rho_0        = 1.5;  
varphiH_0    = 0.841; 
phiI_0       = 1.0000001;                    
iota_0       = 0.379;  
rhoI_0       = 1.5;  
iotaH_0      = 0.619; 
kappa        = 17; 
ex           = 1; 
nuX          = 1.695;
  
r            = 0.04; 
beta         = r; 
deltaK       = 0.093;

B0           = 0.005;
K0           = 0;

ZH           = ZH_0;       
ZN           = ZN_0;       
thetaH       = thetaH_0;   
thetaN       = thetaN_0;   
sigmaC       = sigmaC_0;  
sigmaL       = sigmaL_0;   
phi          = phi_0;     
varphi       = varphi_0;  
rho          = rho_0;     
varphiH      = varphiH_0;
phiI         = phiI_0;    
iota         = iota_0; 
rhoI         = rhoI_0;    
iotaH        = iotaH_0;  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.024   ; % Consumption 
L_ini        = 1.035   ; % Labor supply 
kH_ini       = 5.084   ; % Capital-labor ratio in sector H
kN_ini       = 2.971   ; % Capital-labor ratio in sector N
W_ini        = 1.616   ; % Aggregate wage index
LH_ini       = 0.322   ; % Labor in sector H
LN_ini       = 0.712   ; % Labor in sector N 
PN_ini       = 2.262   ; % Relative price of non tradables
K_ini        = 3.785   ; % Stock of capital
PH_ini       = 1.5     ; % Terms of trade
B_ini        = 0.0001  ; % Stock of traded Bonds
PC_ini       = 1.186   ; % Aggregate consumption price index
PT_ini       = 1.186   ; % Consumption price index for tradables
CN_ini       = 0.299   ; % Consumption in non tradables 
CH_ini       = 0.589   ; % Consumption in tradables 
CF_ini       = 0.4     ; % Consumption in foreign goods 
alphaC_ini   = 0.430   ; % Tradable content of consumption expenditure
alphaH_ini   = 0.5     ; % Home goods content of consumption expenditure on traded goods
PI_ini       = 1.486   ; % Aggregate investment price index
PIT_ini      = 1.000   ; % Investment price index for traded goods
IN_ini       = 0.235   ; % Non traded investment
IH_ini       = 0.2     ; % Home goods investment
IF_ini       = 0.2     ; % Foreign goods investment
alphaI_ini   = 0.430   ; % Tradable content of investment expenditure
alphaIH_ini  = 0.5     ; % Home goods content of investment expenditure on traded goods
GF_ini       = 0.03    ; % Government spending in foreign goods
GH_ini       = 0.03    ; % Government spending in home goods
GN_ini       = 0.21    ; % Government spending in non tradables 
YH_ini       = 2       ; % Output of home traded goods
YN_ini       = 1       ; % Output of non traded goods
XH_ini       = 0.5     ; % Exports of home traded goods
MF_ini       = 0.5     ; % Imports of foreign goods
lambda_ini   = 0.967    ; % Intertemporal Solvency Condition          
                                                          
x0 =[C_ini L_ini kH_ini kN_ini W_ini LH_ini LN_ini PN_ini K_ini PH_ini B_ini PC_ini PT_ini CN_ini CH_ini CF_ini alphaC_ini alphaH_ini PI_ini PIT_ini IN_ini IH_ini IF_ini alphaI_ini alphaIH_ini GF_ini GN_ini GH_ini YH_ini YN_ini XH_ini MF_ini lambda_ini];
[x,fval,exitflag]=fsolve('TECH_PML_CAC_TOT_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LH      = x(6) ; % Labor in sector H
LN      = x(7) ; % Labor in sector N 
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
PC      = x(12) ; % Aggregate consumption price index
PT      = x(13) ; % Consumption price index for tradables
CN      = x(14) ; % Consumption in non tradables 
CH      = x(15) ; % Consumption in tradables 
CF      = x(16) ; % Consumption goods imports
alphaC  = x(17) ; % Tradable content of consumption expenditure 
alphaH  = x(18) ; % Home goods content of consumption expenditure on traded goods
PI      = x(19) ; % Aggregate investment price index
PIT     = x(20) ; % Investment price index for tradables
IN      = x(21) ; % Non tradable investment
IH      = x(22) ; % Investment in home goods
IF      = x(23) ; % Investment in foreign goods
alphaI  = x(24) ; % Tradable content of investment expenditure
alphaIH = x(25) ; % Home goods content of investment expenditure
GF      = x(26) ; % Government spending in foreign goods
GN      = x(27) ; % Government spending in non tradables 
GH      = x(28) ; % Government spending in home traded goods
YH      = x(29) ; % Output of home traded goods
YN      = x(30) ; % Output of non traded goods
XH      = x(31) ; % Exports of home traded goods
MF      = x(32) ; % Imports of foreign goods
lambda  = x(33) ; % Intertemporal Solvency Condition      

% Sectoral profits   
KH  = LH*kH;
WH = PH*ZH*thetaH*(kH^(1-thetaH));
RK  = PH*(1-thetaH)*(YH/KH); 
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
WN = PN*ZN*thetaN*(kN^(1-thetaN));
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Labor income share in the home traded good and non traded good sector
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN); 

% Intermediate solutions for kH, kN, LH, LN as functions of P,K 
d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d21 = ((1-thetaH)/kH); 
d22 = -((1-thetaN)/kN);
                                                          
e11 = (1/PN);                                                                                 
e12 = -(1/PH);                                                                                                                                                                  
e13 = -(1/ZH);                                                                                
e14 = (1/ZN);                                                                                 
e21 = (1/PN);                                                                                        
e22 = -(1/PH);                                                                                                                                                                    
e23 = -(1/ZH);                                                                                                                                                                    
e24 = (1/ZN);                                                                                
                                                                                                                                                                                 
M = [d11 d12; d21 d22];                     
X = [e11 e12 e13 e14; e21 e22 e23 e24];     
JST = inv(M);                                                                                 
MST = JST*X;                                                                                  
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1ZH = MST(1,3); kH_1ZN = MST(1,4); 
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1ZH = MST(2,3); kN_1ZN = MST(2,4);  

% Solution for W=W(PH,PN,ZH,ZN), L=L(lambda,PH,PN,ZH,ZN)
W_PH     = (W/PH) + (1-thetaH)*(W/kH)*kH_PH; 
W_PN     = (1-thetaH)*(W/kH)*kH_PN; 
W_1ZH    = (W/ZH) + (1-thetaH)*(W/kH)*kH_1ZH; 
W_1ZN    = (1-thetaH)*(W/kH)*kH_1ZN; 
L_W      = sigmaL*(L/W); 
L_PH     = L_W*W_PH; 
L_PN     = L_W*W_PN; 
L_1ZH    = L_W*W_1ZH;
L_1ZN    = L_W*W_1ZN;
L_1lambda = sigmaL*(L/lambda); 

% Solutions for Lj=Lj(K,P)
KC_PN  = ( (LH*kH_PN) + (LN*kN_PN) ); 
KC_PH  = ( (LH*kH_PH) + (LN*kN_PH) );
KC_ZH  = ( (LH*kH_1ZH) + (LN*kN_1ZH) ); 
KC_ZN  = ( (LH*kH_1ZN) + (LN*kN_1ZN) );

f11 = 1; 
f12 = 1;  
f21 = kH; 
f22 = kN;

g11 = 0; 
g12 = L_PN;
g13 = L_PH;
g14 = L_1ZH;
g15 = L_1ZN;
g16 = L_1lambda; 
g21 = 1; 
g22 = -KC_PN; 
g23 = -KC_PH;
g24 = -KC_ZH; 
g25 = -KC_ZN; 
g26 = 0; 

M = [f11 f12; f21 f22];
X = [g11 g12 g13 g14 g15 g16; g21 g22 g23 g24 g25 g26];
JST = inv(M);
MST = JST*X;
LH_1K = MST(1,1); LH_PN = MST(1,2); LH_PH = MST(1,3); LH_1ZH = MST(1,4); LH_1ZN = MST(1,5); LH_1lambda = MST(1,6);  
LN_1K = MST(2,1); LN_PN = MST(2,2); LN_PH = MST(2,3); LN_1ZH = MST(2,4); LN_1ZN = MST(2,5); LN_1lambda = MST(2,6);  

% Intermediate solutions for sectoral output - Yj=Yj(PN,PH,K,ZH,ZN)
YH_PN = YH*( (LH_PN/LH) + (1-thetaH)*(kH_PN/kH) ); 
YN_PN = YN*( (LN_PN/LN) + (1-thetaN)*(kN_PN/kN) ); 
YH_PH = YH*( (LH_PH/LH) + (1-thetaH)*(kH_PH/kH) ); 
YN_PH = YN*( (LN_PH/LN) + (1-thetaN)*(kN_PH/kN) );
YH_1K = YH*(LH_1K/LH); 
YN_1K = YN*(LN_1K/LN); 
YH_1ZH     = YH*( (1/ZH) + (LH_1ZH/LH) + (1-thetaH)*(kH_1ZH/kH) ); 
YN_1ZH     = YN*( (LN_1ZH/LN) + (1-thetaN)*(kN_1ZH/kN) );             
YH_1ZN     = YH*( (LH_1ZN/LH) + (1-thetaH)*(kH_1ZN/kH) );  
YN_1ZN     = YN*( (1/ZN) + (LN_1ZN/LN) + (1-thetaN)*(kN_1ZN/kN) );

YH_1lambda = YH*(LH_1lambda/LH); 
YN_1lambda = YN*(LN_1lambda/LN); 

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

CH_1lambda = -(CH/lambda)*sigmaC; 
CN_1lambda = -(CN/lambda)*sigmaC;
CF_1lambda = -(CF/lambda)*sigmaC;

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
I      = deltaK*K; 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN,PN) -
% Intermediate Solution
PsiH_PH    = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN    = (YH_PN - CH_PN - JH_PN);
PH_PN      = -PsiH_PN/PsiH_PH; 
PH_1K      = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q      = JH_1Q/PsiH_PH; 
PH_1ZH     = -YH_1ZH/PsiH_PH; 
PH_1ZN     = -YH_1ZN/PsiH_PH; 
PH_1lambda = -(YH_1lambda - CH_1lambda)/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,ZH,ZN)
PsiN_PH   = (YN_PH - CN_PH - JN_PH); 
PsiN_PN   = ((YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN));
PN_K      = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q      =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 
PN_ZH     = -( YN_1ZH + (PsiN_PH*PH_1ZH) )/PsiN_PN; 
PN_ZN     = -( YN_1ZN + (PsiN_PH*PH_1ZN) )/PsiN_PN;
PN_lambda = -( YN_1lambda + (PsiN_PH*PH_1lambda) )/PsiN_PN;

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN) - Final
% Solution
PH_K      = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q      = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 
PH_ZH     = -( YH_1ZH + (PsiH_PN*PN_ZH) )/PsiH_PH; 
PH_ZN     = -( YH_1ZN + (PsiH_PN*PN_ZN) )/PsiH_PH; 
PH_lambda = -( (YH_1lambda-CH_1lambda) + (PsiH_PN*PN_lambda) )/PsiH_PH; 

% Solving for capital-labor ratios kj=kj(lambda,K,Q,ZH,ZN) - 
% sectoral labor Lj=Lj(lambda,K,Q,ZH,ZN) - sectoral output 
% Yj=Yj(lambda,K,Q,ZH,ZN) - Final Solutions
kH_K = (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

kH_ZH = kH_1ZH + (kH_PH*PH_ZH) + (kH_PN*PN_ZH);
kH_ZN = kH_1ZN + (kH_PH*PH_ZN) + (kH_PN*PN_ZN);
kN_ZH = kN_1ZH + (kN_PH*PH_ZH) + (kN_PN*PN_ZH);
kN_ZN = kN_1ZN + (kN_PH*PH_ZN) + (kN_PN*PN_ZN); 

kH_lambda = (kH_PH*PH_lambda) + (kH_PN*PN_lambda);  
kN_lambda = (kN_PH*PH_lambda) + (kN_PN*PN_lambda);  

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

LH_ZH = LH_1ZH + (LH_PH*PH_ZH) + (LH_PN*PN_ZH); 
LH_ZN = LH_1ZN + (LH_PH*PH_ZN) + (LH_PN*PN_ZN); 
LN_ZH = LN_1ZH + (LN_PH*PH_ZH) + (LN_PN*PN_ZH); 
LN_ZN = LN_1ZN + (LN_PH*PH_ZN) + (LN_PN*PN_ZN); 

LH_lambda = LH_1lambda + (LH_PH*PH_lambda) + (LH_PN*PN_lambda);   
LN_lambda = LN_1lambda + (LN_PH*PH_lambda) + (LN_PN*PN_lambda);   

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

YH_ZH = YH_1ZH + (YH_PH*PH_ZH) + (YH_PN*PN_ZH);
YH_ZN = YH_1ZN + (YH_PH*PH_ZN) + (YH_PN*PN_ZN);
YN_ZH = YN_1ZH + (YN_PH*PH_ZH) + (YN_PN*PN_ZH);
YN_ZN = YN_1ZN + (YN_PH*PH_ZN) + (YN_PN*PN_ZN);

YH_lambda = YH_1lambda + (YH_PH*PH_lambda) + (YH_PN*PN_lambda);  
YN_lambda = YN_1lambda + (YN_PH*PH_lambda) + (YN_PN*PN_lambda);  

% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CH_ZH     = (CH_PH*PH_ZH) + (CH_PN*PN_ZH);
CH_ZN     = (CH_PH*PH_ZN) + (CH_PN*PN_ZN);
CH_lambda = CH_1lambda + (CH_PH*PH_lambda) + (CH_PN*PN_lambda); 

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CN_ZH     = (CN_PH*PH_ZH) + (CN_PN*PN_ZH);
CN_ZN     = (CN_PH*PH_ZN) + (CN_PN*PN_ZN);                       
CN_lambda = CN_1lambda + (CN_PH*PH_lambda) + (CN_PN*PN_lambda);  

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q); 
CF_ZH     = (CF_PH*PH_ZH) + (CF_PN*PN_ZH);
CF_ZN     = (CF_PH*PH_ZN) + (CF_PN*PN_ZN);                       
CF_lambda = CF_1lambda + (CF_PH*PH_lambda) + (CF_PN*PN_lambda);  

JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_ZH      = (JH_PH*PH_ZH) + (JH_PN*PN_ZH); 
JH_ZN      = (JH_PH*PH_ZN) + (JH_PN*PN_ZN);
JH_lambda  = (JH_PH*PH_lambda) + (JH_PN*PN_lambda); 

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JN_ZH      = (JN_PH*PH_ZH) + (JN_PN*PN_ZH);          
JN_ZN      = (JN_PH*PH_ZN) + (JN_PN*PN_ZN);          
JN_lambda  = (JN_PH*PH_lambda) + (JN_PN*PN_lambda);  

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 
JF_ZH      = (JF_PH*PH_ZH) + (JF_PN*PN_ZH);         
JF_ZN      = (JF_PH*PH_ZN) + (JF_PN*PN_ZN);         
JF_lambda  = (JF_PH*PH_lambda) + (JF_PN*PN_lambda); 

XH_K      = XH_PH*PH_K; 
XH_Q      = XH_PH*PH_Q; 
XH_ZH     = XH_PH*PH_ZH;
XH_ZN     = XH_PH*PH_ZN;
XH_lambda = XH_PH*PH_lambda;

MF_K      = (CF_K + JF_K); 
MF_Q      = (CF_Q + JF_Q); 
MF_ZH     = (CF_ZH + JF_ZH); 
MF_ZN     = (CF_ZN + JF_ZN); 
MF_lambda = (CF_lambda + JF_lambda); 

% Solution for W as function W=W(lambda,K,Q,ZH,ZN) 
W_K       = (W_PH*PH_K) + (W_PN*PN_K); 
W_Q       = (W_PH*PH_Q) + (W_PN*PN_Q);
W_ZH      = W_1ZH + (W_PH*PH_ZH) + (W_PN*PN_ZH); 
W_ZN      = W_1ZN + (W_PH*PH_ZN) + (W_PN*PN_ZN);
W_lambda  = (W_PH*PH_lambda) + (W_PN*PN_lambda);

% Solution for L as function L=L(lambda,K,Q,ZH,ZN)
L_K  = (L_W*W_K); 
L_Q  = (L_W*W_Q);
L_ZH = (L_W*W_ZH); 
L_ZN = (L_W*W_ZN);
L_lambda  = L_1lambda + (L_W*W_lambda);

% Solution for C as function C=C(lambda,K,Q,ZH,ZN) 
C_1lambda  = -sigmaC*(C/lambda); 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_ZH       = (C_PH*PH_ZH) + (C_PN*PN_ZH);
C_ZN       = (C_PH*PH_ZN) + (C_PN*PN_ZN);
C_lambda   = C_1lambda + (C_PH*PH_lambda) + (C_PN*PN_lambda);

% Solution for PC=PC(PH,PN) - PC = PC(lambda,K,Q,ZH,ZF)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_ZH      = (PC/PH)*alphaC*alphaH*PH_ZH + (PC/PN)*(1-alphaC)*PN_ZH;
PC_ZN      = (PC/PH)*alphaC*alphaH*PH_ZN + (PC/PN)*(1-alphaC)*PN_ZN;
PC_lambda  = (PC/PH)*alphaC*alphaH*PH_lambda + (PC/PN)*(1-alphaC)*PN_lambda;

% Solution for PI=PI(PH,PN) - PI = PI(lambda,K,Q,ZH,ZF)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_ZH      = (PI/PH)*alphaI*alphaIH*PH_ZH + (PI/PN)*(1-alphaI)*PN_ZH;
PI_ZN      = (PI/PH)*alphaI*alphaIH*PH_ZN + (PI/PN)*(1-alphaI)*PN_ZN;
PI_lambda  = (PI/PH)*alphaI*alphaIH*PH_lambda + (PI/PN)*(1-alphaI)*PN_lambda;

% Solution for G=G(PH,PN) - G= G(lambda,K,Q,ZH,ZF)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_ZH       = (PH_ZH*GH) + (PN_ZH*GN);
G_ZN       = (PH_ZN*GH) + (PN_ZN*GN);
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Capital rental rates
RKH = PH*(1-thetaH)*(YH/KH); 
RKN = PN*(1-thetaN)*(YN/KN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(lambda,K,Q,ZH,ZF); 
P = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_ZH = (P/PN)*PN_ZH - (P/PH)*PH_ZH;
P_ZN = (P/PN)*PN_ZN - (P/PH)*PH_ZN;

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,ZH,ZN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_ZH      = (PH_ZH*YH) + (PH*YH_ZH) + (PN_ZH*YN) + (PN*YN_ZH);
Y_ZN      = (PH_ZN*YH) + (PH*YH_ZN) + (PN_ZN*YN) + (PN*YN_ZN);
Y_lambda  = (PH_lambda*YH) + (PH*YH_lambda) + (PN_lambda*YN) + (PN*YN_lambda);

% Marginal revenue of capital R = PN*partial YN/partial KN
RK   = PI*(r+deltaK); 
R_K  = (RK/PN)*PN_K - (RK/kN)*thetaN*kN_K; 
R_Q  = (RK/PN)*PN_Q - (RK/kN)*thetaN*kN_Q; 
R_ZH = (RK/PN)*PN_ZH - (RK/kN)*thetaN*kN_ZH; 
R_ZN = (RK/ZN) + (RK/PN)*PN_ZN - (RK/kN)*thetaN*kN_ZN; 
R_lambda = (RK/PN)*PN_lambda - (RK/kN)*thetaN*kN_lambda; 

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(lambda,K,Q,ZH,ZN) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_ZH = (v_PN*PN_ZH) + (v_PH*PH_ZH); 
v_ZN = (v_PN*PN_ZN) + (v_PH*PH_ZN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Elements of the Jacobian Matrix 
Upsilon_K = (I/IN)*(YN_K-CN_K) - deltaK + alphaI*phiI*I*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q = (I/IN)*(YN_Q-CN_Q) + alphaI*phiI*I*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Sigma_K   = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q   = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 

x11 = Upsilon_K;                                                                         
x12 = Upsilon_Q;                                                                                                                                                                                                                     
x21 = Sigma_K;                        
x22 = Sigma_Q;    

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
B_K   = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q   = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/G; 
omegaGF = GF/G; 

% TFP
a  = (1/((1-alphaI) + alphaI*(thetaH/thetaN))); 
b  = a*(thetaH/thetaN); 
Z  = (ZH^a)/(ZN^b); 

% Investment 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF;  
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
alphaL  = (WN*LN)/(W*L); 
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH =  IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L; 
omegaXHY  = (PH*XH) / Y; 
omegaXHYH = XH / YH;

% Targeted ratios
omegaC    = (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    = G/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model
cond1  = PH*(1-thetaH)*(YH/KH)-RK;                               
cond2  = PN*(1-thetaN)*(YN/KN)-RK;                             
cond3  = PH*thetaH*(YH/LH)-WH;                                   
cond4  = PN*thetaN*(YN/LN)-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LH+LN) - L;  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                                        
cond16 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond17 = Sav;                                                 
cond18 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond19 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond20 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond21 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond22 = 1 - (omegaK + omegaL);    
cond23 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond24 = (PT*CT) - ((PH*CH)+CF); 
cond25 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond26 = (PIT*IT) - ((PH*IH)+IF); 
cond27 = r*B + (PH*XH) - MF; 
cond28 = r*B + (RK*K) + (W*L) - G - (PC*C) - (PI*I); 
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaH  : %5.2f   thetaN   : %5.2f',thetaH,thetaN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f ',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f ',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f ',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GH      : %5.2f   GN       : %5.2f  GF      : %5.2f G      : %5.2f',GH,GN,GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f',IH,IN));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp('Export and import (benchmark)');
disp(sprintf('XH        :   %7.3f   MF : %9.3f',XH,MF));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp('Price of Non Tradables in terms of Imports');
disp(sprintf('PsiN_PH     :   %7.3f  PsiN_PN     : %9.3f',PsiN_PH,PsiN_PN));
disp(sprintf('PN_Q        :   %7.3f  PN_K        : %9.3f',PN_Q,PN_K));
disp(sprintf('PN_ZH       :   %7.3f  PN_ZN       : %9.3f',PN_ZH,PN_ZN));

disp('Terms of Trade');
disp(sprintf('PH_1Q       :   %7.3f  PH_1K       : %9.3f PH_PN       : %9.3f',PH_1Q,PH_1K,PH_PN));
disp(sprintf('PH_1ZH      :   %7.3f  PH_1ZN      : %9.3f',PH_1ZH,PH_1ZN));
disp(sprintf('PsiH_PN     :   %7.3f  PsiH_PH     : %9.3f',PsiH_PN,PsiH_PH));
disp(sprintf('PH_Q        :   %7.3f  PH_K        : %9.3f',PH_Q,PH_K));
disp(sprintf('PH_ZH       :   %7.3f  PH_ZN       : %9.3f',PH_ZH,PH_ZN));

disp('Imports');
disp(sprintf('MF_Q        :   %7.3f  MF_K        : %9.3f',MF_Q,MF_K));
disp(sprintf('MF_ZH       :   %7.3f  MF_ZN       : %9.3f',MF_ZH,MF_ZN));
disp(sprintf('XH_Q        :   %7.3f  XH_K        : %9.3f',XH_Q,XH_K));
disp(sprintf('XH_ZH       :   %7.3f  XH_ZN       : %9.3f',XH_ZH,XH_ZN));

disp(' ');
disp('Partial derivatives CH and CN');
disp(sprintf('CN_K        :   %7.3f  CH_K      : %9.3f',CN_K,CH_K));
disp(sprintf('CN_Q        :   %7.3f  CH_Q      : %9.3f',CN_Q,CH_Q));
disp(sprintf('CN_lamb     :   %7.3f  CH_lamb   : %9.3f',CN_lambda,CH_lambda));
disp(sprintf('CN_ZH       :   %7.3f  CH_ZH     : %9.3f',CN_ZH,CH_ZH));
disp(sprintf('CN_ZN       :   %7.3f  CH_ZN     : %9.3f',CN_ZN,CH_ZN));

disp('Partial derivatives LH and LN');
disp(sprintf('LN_K        :   %7.3f  LH_K      : %9.3f',LN_K,LH_K));
disp(sprintf('LN_Q        :   %7.3f  LH_Q      : %9.3f',LN_Q,LH_Q));
disp(sprintf('LN_lamb     :   %7.3f  LH_lamb   : %9.3f',LN_lambda,LH_lambda));
disp(sprintf('LN_ZH       :   %7.3f  LH_ZH     : %9.3f',LN_ZH,LH_ZH));
disp(sprintf('LN_ZN       :   %7.3f  LH_ZN     : %9.3f',LN_ZN,LH_ZN));


disp('Partial derivatives kH and kN');
disp(sprintf('kN_Q       :   %7.6f  kH_Q       : %9.6f',kN_Q,kH_Q));   
disp(sprintf('kN_K       :   %7.6f  kH_K       : %9.6f',kN_K,kH_K));  
disp(sprintf('kN_lambda  :   %7.3f  kH_lambda  : %9.3f',kN_lambda,kH_lambda));  
disp(sprintf('kN_ZH      :   %7.6f  kH_ZH      : %9.6f',kN_ZH,kH_ZH));
disp(sprintf('kN_ZN      :   %7.6f  kH_ZN      : %9.6f',kN_ZN,kH_ZN));


disp('Partial derivatives LH and LN');
disp(sprintf('LN_Q       :   %7.6f  LH_Q       : %9.6f',LN_Q,LH_Q));
disp(sprintf('LN_K       :   %7.6f  LH_K       : %9.6f',LN_K,LH_K));
disp(sprintf('LN_lambda  :   %7.3f  LH_lambda  : %9.3f',LN_lambda,LH_lambda));
disp(sprintf('LN_ZH      :   %7.6f  LH_ZH      : %9.6f',LN_ZH,LH_ZH));
disp(sprintf('LN_ZN      :   %7.6f  LH_ZN      : %9.6f',LN_ZN,LH_ZN));

disp('Partial derivatives C');
disp(sprintf('YN_Q       :   %7.6f  YH_Q       : %9.6f',YN_Q,YH_Q));
disp(sprintf('YN_K       :   %7.6f  YH_K       : %9.6f',YN_K,YH_K));
disp(sprintf('YN_lambda  :   %7.3f  YH_lambda  : %9.3f',YN_lambda,YH_lambda));
disp(sprintf('YN_ZH      :   %7.6f  YH_ZH      : %9.6f',YN_ZH,YH_ZH));
disp(sprintf('YN_ZN      :   %7.6f  YH_ZN      : %9.6f',YN_ZN,YH_ZN));

disp('Partial derivatives of Y');
disp(sprintf('Y_Q        :   %7.3f  Y_K        : %9.3f',Y_Q,Y_K));
disp(sprintf('Y_ZH       :   %7.3f  Y_ZN       : %9.3f',Y_ZH,Y_ZN));
disp(sprintf('Y_lambda   : %9.3f',Y_lambda));


disp('Partial derivatives of L');
disp(sprintf('L_Q        :   %7.3f  L_K        : %9.3f',L_Q,L_K));
disp(sprintf('L_ZH       :   %7.3f  L_ZN       : %9.3f',L_ZH,L_ZN));
disp(sprintf('L_lambda   :   %7.3f  W_lambda   : %9.3f',L_lambda,W_lambda));

disp('Partial derivatives of W');
disp(sprintf('W_Q        :   %7.3f  W_K        : %9.3f',W_Q,W_K));
disp(sprintf('W_ZH       :   %7.3f  W_ZN       : %9.3f',W_ZH,W_ZN));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');
disp('Linearization');
disp(sprintf('R_lambda  :  %5.4f  R_K       : %5.4f   R_Q     : %5.4f',R_lambda,R_K,R_Q));
disp(sprintf('R_ZH      :  %5.4f  R_ZN      : %5.4f',R_ZH,R_ZN));
disp(sprintf('P_K       : %5.4f   P_Q       : %5.4f',P_K,P_Q));
disp(sprintf('P_ZH      :  %5.4f  P_ZN      : %5.4f',P_ZH,P_ZN));
disp(sprintf('v_K       :  %5.4f  v_Q       : %5.4f',v_K,v_Q));
disp(sprintf('v_ZH      :  %5.4f  v_ZN      : %5.4f',v_ZH,v_ZN))
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('PH*XH/Y  :  %5.3f       XH / YH  :  %5.3f',omegaXHY,omegaXHYH));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Resource Constraint for Labor     : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));
disp(sprintf('Private Savings                   : %9.16f   ',cond17));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond23));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond24));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond25));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond26));
disp(sprintf('Current account                   : %9.16f   ',cond27));
disp(sprintf('Current account                   : %9.16f   ',cond28));

kH_0 = kH;  kN_0 = kN; PN_0 = PN; LH_0 = LH; K_0 = K; C_0 = C;  
LN_0  = LN; L_0 = L; W_0 = W; P_0 = P; 
YH_0  = YH; YN_0  = YN; Y_0  = Y; KH_0  = KH; KN_0  = KN; G_0 = G;     
PC_0 = PC; alphaC_0 = alphaC; CN_0 = CN; CH_0 = CH;  
ZH_0 = ZH; ZN_0 = ZN; Z_0 = Z; GH_0 = GH; GN_0 = GN; 
LH_0 = LH; LN_0 = LN; KH_0 = KH; KN_0 = KN; WH_0 = WH; WN_0 = WN; 
Omega_0 = Omega; YHYN_0 = YHYN; LHLN_0 = LHLN;
IF_0 = IF; CF_0 = CF; XH_0 = XH; MF_0 = MF; GF_0 = GF; PH_0 = PH; 
PT_0 = PT; PIT_0 = PIT; CT_0 = CT; IT_0 = IT; GT_0 = GT; 

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IH_0 = IH; PI_0 = PI; alphaI_0 = alphaI; EI_0 = EI; 
WPC_0 = WPC; WHPC_0 = WHPC; WNPC_0 = WNPC; alphaL_0 = alphaL; RK_0 = RK; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaIHYH_0 = omegaIHYH; omega_IFYH_0 = omegaIFYH; omegaGHYH_0 = omegaGHYH; 
omegaGFYH_0 = omegaGFYH; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYH_0 = omegaYH; omegaYN_0 = omegaYN; omegaLH_0 = omegaLH; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; 
omegaIFYH_0 = omegaIFYH; omegaGFYH_0 = omegaGFYH; omegaIH_0 = omegaIH; 
omegaCH_0 = omegaCH; omegaIF_0 = omegaIF; omegaCF_0 = omegaCF; 
omegaGT_0 = omegaGT; omegaGH_0 = omegaGH; omegaGF_0 = omegaGF; 
omegaKY_0 = omegaKY; omegaIH_0 = omegaIH; omegaIF_0 = omegaIF;
omegaXHY_0 = omegaXHY; omegaXHYH_0 = omegaXHYH; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; 
alphaI_0 = alphaI; alphaH_0 = alphaH; alphaIH_0 = alphaIH; 
sLH_0 = sLH; sLN_0 = sLN;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Permanent Technology Shock                      %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GH       = GH_0; 
GN       = GN_0; 
GF       = GF_0; 
%% Endogenous response of the ratio ZH/ZN to an exogenous technology shock 
%%%%%%%%%%%%%%%%%%% Calibration shock %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
filename = 'Calibration-file'; 
sheet    = 21;
xlRange  = 'B22:I39';
datac = xlsread(filename,sheet,xlRange)
param_OECD = [datac(18,8)/100  datac(18,4)/100 datac(18,7)/100 datac(18,3)/100 datac(18,1) datac(18,2)];
parameters = param_OECD;
gz       = parameters(1);           
gzH      = parameters(2);    
gzN      = ((a*gzH)-gz)/b;   
gz0      = parameters(3);  
gzH0     = parameters(4);    
gzN0     = ((a*gzH0)-gz0)/b; 
barzN    = gzN - gzN0;       
barzH    = gzH - gzH0;       
xiH      = parameters(5);    
xiN      = parameters(6);     
ZH       = ZH_0*(1+gzH);     
ZN       = ZN_0*(1+gzN);     
aH       = -ZH_0*barzH;      
aN       = -ZN_0*barzN;    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 =[C_0 L_0 kH_0 kN_0 W_0 LH_0 LN_0 PN_0 K_0 PH_0 B_0 PC_0 PT_0 CN_0 CH_0 CF_0 PI_0 PIT_0 IN_0 IH_0 IF_0 YH_0 YN_0 XH_0 MF_0 lambda_0];
[x,fval,exitflag]=fsolve('TECH_PML_CAC_TOT_perm',x0,optimset('display','off','TolFun',1e-011));
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LH      = x(6) ; % Labor in sector H
LN      = x(7) ; % Labor in sector N 
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
PC      = x(12) ; % Aggregate consumption price index
PT      = x(13) ; % Consumption price index for tradables
CN      = x(14) ; % Consumption in non tradables 
CH      = x(15) ; % Consumption in tradables 
CF      = x(16) ; % Consumption goods imports
PI      = x(17) ; % Aggregate investment price index
PIT     = x(18) ; % Investment price index for tradables
IN      = x(19) ; % Non tradable investment
IH      = x(20) ; % Investment in home goods
IF      = x(21) ; % Investment in foreign goods
YH      = x(22) ; % Output of home traded goods
YN      = x(23) ; % Output of non traded goods
XH      = x(24) ; % Exports of home traded goods
MF      = x(25) ; % Imports of foreign goods
lambda  = x(26) ; % Marginal utility of wealth lambda

% Shares
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC)));

% Sectoral profits   
KH  = LH*kH;
WH = PH*ZH*thetaH*(kH^(1-thetaH));
RK  = PH*(1-thetaH)*(YH/KH); 
PiH = (PH*YH) - (RK*KH) - (WH*LH);
  
KN  = LN*kN;   
WN = PN*ZN*thetaN*(kN^(1-thetaN));
PiN = (PN*YN) - (RK*KN) - (WN*LN);

% Labor income share in the home traded good and non traded good sector
sLH = WH*LH/(PH*YH);
sLN = WN*LN/(PN*YN); 

% Capital rental rates 
RKH = PH*(1-thetaH)*(YH/KH); 
RKN = PN*(1-thetaN)*(YN/KN); 

% GDP and shares in real terms
Y  = (PH*YH) + (PN*YN); 
YR = (PH_0*YH) + (PN_0*YN);
omegaYHR = (PH_0*YH)/YR; 
omegaYNR = (PN_0*YN)/YR; 

% Government spending 
G       = (PH*GH) + (PN*GN) + GF;   
GT      = GF + (PH*GH); 
omegaGT = GT/G; 
omegaGH = (PH*GH)/G; 
omegaGF = GF/G;  

% TFP
a  = (1/((1-alphaI) + alphaI*(thetaH/thetaN))); 
b  = a*(thetaH/thetaN); 
Z  = (ZH^a)/(ZN^b); 

% Consumption 
CT       = C*varphi*((PT/PC)^(-phi));
C_check  = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
CT_check = ( (varphiH^(1/rho))*(CH^((rho-1)/rho)) + ((1-varphiH)^(1/rho))*(CF^((rho-1)/rho)) )^(rho/(rho-1));
omegaCH  = (PH*CH)/(PC*C); 
omegaCF  = (CF)/(PC*C);

% Investment 
I        = deltaK*K; 
IT       = deltaK*K*iota*((PIT/PI)^(-phiI));
I_check  = ( (iota^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-iota)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
IT_check = ( (iotaH^(1/rhoI))*(IH^((rhoI-1)/rhoI)) + ((1-iotaH)^(1/rhoI))*(IF^((rhoI-1)/rhoI)) )^(rhoI/(rhoI-1));  
I        = deltaK*K; 
EI       = PI*I; 
EIT      = (PH*IH) + IF; 
omegaI   = PI*I/Y;
omegaIH  = (PH*IH)/(PI*I);
omegaIF  = (IF)/(PI*I);

% Net exports, current account and saving
NX  = (PH*XH) - MF; 
CA  = (r*B) + (PH*XH) - MF; 
A   = B + (PI*K); 
Tax = G; 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WHPC = WH/PC;
WNPC = WN/PC;

% Labor income and Capital income shares
alphaL  = (WN*LN)/(W*L); 
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WH); 
YHYN  = (YH/YN); 
LHLN  = (LH/LN);

% Intermediate solutions for kH, kN, LH, LN as functions of P,K 
d11 = -(thetaH/kH); 
d12 = (thetaN/kN);
d21 = ((1-thetaH)/kH); 
d22 = -((1-thetaN)/kN);
                                                          
e11 = (1/PN);                                                                                 
e12 = -(1/PH);                                                                                                                                                                  
e13 = -(1/ZH);                                                                                
e14 = (1/ZN);                                                                                 
e21 = (1/PN);                                                                                        
e22 = -(1/PH);                                                                                                                                                                    
e23 = -(1/ZH);                                                                                                                                                                    
e24 = (1/ZN);                                                                                
                                                                                                                                                                                 
M = [d11 d12; d21 d22];                     
X = [e11 e12 e13 e14; e21 e22 e23 e24];     
JST = inv(M);                                                                                 
MST = JST*X;                                                                                  
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1ZH = MST(1,3); kH_1ZN = MST(1,4); 
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1ZH = MST(2,3); kN_1ZN = MST(2,4);  

% Solution for W=W(PH,PN,ZH,ZN), L=L(lambda,PH,PN,ZH,ZN)
W_PH     = (W/PH) + (1-thetaH)*(W/kH)*kH_PH; 
W_PN     = (1-thetaH)*(W/kH)*kH_PN; 
W_1ZH    = (W/ZH) + (1-thetaH)*(W/kH)*kH_1ZH; 
W_1ZN    = (1-thetaH)*(W/kH)*kH_1ZN; 
L_W      = sigmaL*(L/W); 
L_PN     = L_W*W_PN;
L_PH     = L_W*W_PH;
L_1ZH    = L_W*W_1ZH;
L_1ZN    = L_W*W_1ZN;

% Solutions for Lj=Lj(K,P)
KC_PN  = ( (LH*kH_PN) + (LN*kN_PN) ); 
KC_PH  = ( (LH*kH_PH) + (LN*kN_PH) );
KC_ZH  = ( (LH*kH_1ZH) + (LN*kN_1ZH) ); 
KC_ZN  = ( (LH*kH_1ZN) + (LN*kN_1ZN) );

f11 = 1; 
f12 = 1;  
f21 = kH; 
f22 = kN;

g11 = 0; 
g12 = L_PN;
g13 = L_PH;
g14 = L_1ZH;
g15 = L_1ZN;
g21 = 1; 
g22 = -KC_PN; 
g23 = -KC_PH;
g24 = -KC_ZH; 
g25 = -KC_ZN; 

M = [f11 f12; f21 f22];
X = [g11 g12 g13 g14 g15; g21 g22 g23 g24 g25];
JST = inv(M);
MST = JST*X;
LH_1K = MST(1,1); LH_PN = MST(1,2); LH_PH = MST(1,3); LH_1ZH = MST(1,4); LH_1ZN = MST(1,5);
LN_1K = MST(2,1); LN_PN = MST(2,2); LN_PH = MST(2,3); LN_1ZH = MST(2,4); LN_1ZN = MST(2,5);

% Intermediate solutions for sectoral output - Yj=Yj(PN,PH,K,ZH,ZN)
YH_PN = YH*( (LH_PN/LH) + (1-thetaH)*(kH_PN/kH) ); 
YN_PN = YN*( (LN_PN/LN) + (1-thetaN)*(kN_PN/kN) ); 
YH_PH = YH*( (LH_PH/LH) + (1-thetaH)*(kH_PH/kH) ); 
YN_PH = YN*( (LN_PH/LN) + (1-thetaN)*(kN_PH/kN) );
YH_1K = YH*(LH_1K/LH); 
YN_1K = YN*(LN_1K/LN); 
YH_1ZH     = YH*( (1/ZH) + (LH_1ZH/LH) + (1-thetaH)*(kH_1ZH/kH) ); 
YN_1ZH     = YN*( (LN_1ZH/LN) + (1-thetaN)*(kN_1ZH/kN) );             
YH_1ZN     = YH*( (LH_1ZN/LH) + (1-thetaH)*(kH_1ZN/kH) );  
YN_1ZN     = YN*( (1/ZN) + (LN_1ZN/LN) + (1-thetaN)*(kN_1ZN/kN) );

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q)
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN,PN) -
% Intermediate Solution
PsiH_PH    = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN    = (YH_PN - CH_PN - JH_PN);
PH_PN      = -PsiH_PN/PsiH_PH; 
PH_1K      = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q      = JH_1Q/PsiH_PH; 
PH_1ZH     = -YH_1ZH/PsiH_PH; 
PH_1ZN     = -YH_1ZN/PsiH_PH; 

% Solving for the price of non tradables PN=PN(lambda,K,Q,ZH,ZN)
PsiN_PH   = (YN_PH - CN_PH - JN_PH); 
PsiN_PN   = (YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN);
PN_K      = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q      =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 
PN_ZH     = -( YN_1ZH + (PsiN_PH*PH_1ZH) )/PsiN_PN; 
PN_ZN     = -( YN_1ZN + (PsiN_PH*PH_1ZN) )/PsiN_PN;

% Solving for the price of home goods PH=PH(lambda,K,Q,ZH,ZN) - Final
% Solution
PH_K      = -( (YH_1K - JH_1K) + (PsiH_PN*PN_K) )/PsiH_PH; 
PH_Q      = (JH_1Q - (PsiH_PN*PN_Q) )/PsiH_PH; 
PH_ZH     = -( YH_1ZH + (PsiH_PN*PN_ZH) )/PsiH_PH; 
PH_ZN     = -( YH_1ZN + (PsiH_PN*PN_ZN) )/PsiH_PH; 

% Solving for capital-labor ratios kj=kj(lambda,K,Q,ZH,ZN) - 
% sectoral labor Lj=Lj(lambda,K,Q,ZH,ZN) - sectoral output 
% Yj=Yj(lambda,K,Q,ZH,ZN) - Final Solutions
kH_K = (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 

kH_ZH = kH_1ZH + (kH_PH*PH_ZH) + (kH_PN*PN_ZH);
kH_ZN = kH_1ZN + (kH_PH*PH_ZN) + (kH_PN*PN_ZN);
kN_ZH = kN_1ZH + (kN_PH*PH_ZH) + (kN_PN*PN_ZH);
kN_ZN = kN_1ZN + (kN_PH*PH_ZN) + (kN_PN*PN_ZN); 

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);

LH_ZH = LH_1ZH + (LH_PH*PH_ZH) + (LH_PN*PN_ZH); 
LH_ZN = LH_1ZN + (LH_PH*PH_ZN) + (LH_PN*PN_ZN); 
LN_ZH = LN_1ZH + (LN_PH*PH_ZH) + (LN_PN*PN_ZH); 
LN_ZN = LN_1ZN + (LN_PH*PH_ZN) + (LN_PN*PN_ZN); 

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

YH_ZH = YH_1ZH + (YH_PH*PH_ZH) + (YH_PN*PN_ZH);
YH_ZN = YH_1ZN + (YH_PH*PH_ZN) + (YH_PN*PN_ZN);
YN_ZH = YN_1ZH + (YN_PH*PH_ZH) + (YN_PN*PN_ZH);
YN_ZN = YN_1ZN + (YN_PH*PH_ZN) + (YN_PN*PN_ZN);

% Solving for consumption Cj=Cj(lambda,K,Q,ZH,ZN), investment inputs 
% Jj=Jj(K,Q,ZH,ZN), imports MF=MF(lambda,K,Q,ZH,ZN), exports 
%XH=XH(lambda,K,Q,ZH,ZN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CH_ZH     = (CH_PH*PH_ZH) + (CH_PN*PN_ZH);
CH_ZN     = (CH_PH*PH_ZN) + (CH_PN*PN_ZN);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CN_ZH     = (CN_PH*PH_ZH) + (CN_PN*PN_ZH);
CN_ZN     = (CN_PH*PH_ZN) + (CN_PN*PN_ZN);                       

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q); 
CF_ZH     = (CF_PH*PH_ZH) + (CF_PN*PN_ZH);
CF_ZN     = (CF_PH*PH_ZN) + (CF_PN*PN_ZN);                       
 
JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_ZH      = (JH_PH*PH_ZH) + (JH_PN*PN_ZH); 
JH_ZN      = (JH_PH*PH_ZN) + (JH_PN*PN_ZN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JN_ZH      = (JN_PH*PH_ZH) + (JN_PN*PN_ZH);          
JN_ZN      = (JN_PH*PH_ZN) + (JN_PN*PN_ZN);          

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 
JF_ZH      = (JF_PH*PH_ZH) + (JF_PN*PN_ZH);         
JF_ZN      = (JF_PH*PH_ZN) + (JF_PN*PN_ZN);         

XH_K      = XH_PH*PH_K; 
XH_Q      = XH_PH*PH_Q; 
XH_ZH     = XH_PH*PH_ZH;
XH_ZN     = XH_PH*PH_ZN;

MF_K      = (CF_K + JF_K); 
MF_Q      = (CF_Q + JF_Q); 
MF_ZH     = (CF_ZH + JF_ZH); 
MF_ZN     = (CF_ZN + JF_ZN); 

% GDP and output shares in real terms
Y   = (PH*YH) +(PN*YN);

% Solution for Y as function Y=Y(K,Q,lambda,ZH,ZN) 
Y_K       = (PH_K*YH) + (PH*YH_K) + (PN_K*YN) + (PN*YN_K); 
Y_Q       = (PH_Q*YH) + (PH*YH_Q) + (PN_Q*YN) + (PN*YN_Q);
Y_ZH      = (PH_ZH*YH) + (PH*YH_ZH) + (PN_ZH*YN) + (PN*YN_ZH);
Y_ZN      = (PH_ZN*YH) + (PH*YH_ZN) + (PN_ZN*YN) + (PN*YN_ZN);
             
% Solution for W as function W=W(lambda,K,Q,ZH,ZN) 
W_K       = (W_PH*PH_K) + (W_PN*PN_K); 
W_Q       = (W_PH*PH_Q) + (W_PN*PN_Q);
W_ZH      = W_1ZH + (W_PH*PH_ZH) + (W_PN*PN_ZH); 
W_ZN      = W_1ZN + (W_PH*PH_ZN) + (W_PN*PN_ZN);

% Solution for L as function L=L(lambda,K,Q,ZH,ZN)
L_K  = (L_W*W_K); 
L_Q  = (L_W*W_Q);
L_ZH = (L_W*W_ZH); 
L_ZN = (L_W*W_ZN);

% Solving for sectoral wages - Wj=Wj(lambda,K,Q,ZH,ZN)
WH_K      = W_K; 
WH_Q      = W_Q; 
WH_ZH     = W_ZH;
WH_ZN     = W_ZN;

WN_K      = W_K; 
WN_Q      = W_Q; 
WN_ZH     = W_ZH;
WN_ZN     = W_ZN;

% Solution for C as function C=C(lambda,K,Q,ZH,ZN) 
C_1lambda  = -sigmaC*(C/lambda); 
C_PH       = -sigmaC*alphaC*alphaH*(C/PH); 
C_PN       = -sigmaC*(1-alphaC)*(C/PN); 
C_K        = (C_PH*PH_K) + (C_PN*PN_K); 
C_Q        = (C_PH*PH_Q) + (C_PN*PN_Q);
C_ZH       = (C_PH*PH_ZH) + (C_PN*PN_ZH);
C_ZN       = (C_PH*PH_ZN) + (C_PN*PN_ZN);
C_lambda   = C_1lambda + (C_PH*PH_lambda) + (C_PN*PN_lambda);

% Marginal revenue of capital R = PN*partial YN/partial KN
RK   = PI*(r+deltaK); 
R_K  = (RK/PN)*PN_K - (RK/kN)*thetaN*kN_K; 
R_Q  = (RK/PN)*PN_Q - (RK/kN)*thetaN*kN_Q; 
R_ZH = (RK/PN)*PN_ZH - (RK/kN)*thetaN*kN_ZH; 
R_ZN = (RK/ZN) + ((RK/PN)*PN_ZN) - (RK/kN)*thetaN*kN_ZN; 
R_lambda = (RK/PN)*PN_lambda - (RK/kN)*thetaN*kN_lambda; 

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(lambda,K,Q,ZH,ZN) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_ZH = (v_PN*PN_ZH) + (v_PH*PH_ZH); 
v_ZN = (v_PN*PN_ZN) + (v_PH*PH_ZN);
v_lambda = (v_PN*PN_lambda) + (v_PH*PH_lambda);

% Eigenvalues and Eigenvectors 
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + (alphaI*phiI*I)*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + (alphaI*phiI*I)*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Upsilon_ZH = (I/IN)*(YN_ZH-CN_ZH) + (alphaI*phiI*I)*( (PN_ZH/PN) - (alphaIH/PH)*PH_ZH );
Upsilon_ZN = (I/IN)*(YN_ZN-CN_ZN) + (alphaI*phiI*I)*( (PN_ZN/PN) - (alphaIH/PH)*PH_ZN );
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 
Sigma_ZH    = -( R_ZH + (PI*kappa*v_ZH*deltaK) ); 
Sigma_ZN    = -( R_ZN + (PI*kappa*v_ZN*deltaK) ); 
 
x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x13   = Upsilon_ZH; 
x14   = Upsilon_ZN; 
x21   = Sigma_K;                        
x22   = Sigma_Q;
x23   = Sigma_ZH; 
x24   = Sigma_ZN; 
x31   = 0; 
x32   = 0; 
x33   = -xiH; 
x34   = 0; 
x41   = 0; 
x42   = 0; 
x43   = 0; 
x44   = -xiN;      

J = [x11 x12 x13 x14; x21 x22 x23 x24; x31 x32 x33 x34; x41 x42 x43 x44];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
nu_1 = nu(1,1);             
nu_2 = nu(2,2);             
nu_3 = nu(3,3);             
nu_4 = nu(4,4);             
                            
omega_11 = V(1,1)/V(1,1);   
omega_21 = V(2,1)/V(1,1);   
omega_31 = V(3,1)/V(1,1);   
omega_41 = V(4,1)/V(1,1);   
                            
omega_12 = V(1,2)/V(1,2);   
omega_22 = V(2,2)/V(1,2);   
omega_32 = V(3,2)/V(1,2);   
omega_42 = V(4,2)/V(1,2);   
                            
omega_13 = V(1,3)/V(3,3);   
omega_23 = V(2,3)/V(3,3);   
omega_33 = V(3,3)/V(3,3);   
omega_43 = V(4,3)/V(3,3);   
                            
omega_14 = V(1,4)/V(4,4);   
omega_24 = V(2,4)/V(4,4);   
omega_34 = V(3,4)/V(4,4);   
omega_44 = V(4,4)/V(4,4);   

TrJ = trace(J); 
DetJ = det(J); 

J1 = [x11 x12; x21 x22];
TrJ1 = trace(J1); 
DetJ1 = det(J1);

% Check for Eigenvectors
omega13 = -( x13*(x22+xiH) - (x12*x23) )/( (nu_1+xiH)*(nu_2+xiH) ); 
omega14 = -( x14*(x22+xiN) - (x12*x24) )/( (nu_1+xiN)*(nu_2+xiN) );
omega23 =  ( (x13*x21) - (x11+xiH)*x23 )/( (nu_1+xiH)*(nu_2+xiH) );
omega24 =  ( (x14*x21) - (x11+xiN)*x24 )/( (nu_1+xiN)*(nu_2+xiN) );

% Solve for Arbitrary Constants 
D3 = aH; 
D4 = aN; 
D1 = (K0 - K) - (omega_13*D3) - (omega_14*D4); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q,ZH,ZN);
% Xi_Q=0
B_K          = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_ZH         = (PH_ZH*XH) + (PH*XH_ZH) - MF_ZH; 
B_ZN         = (PH_ZN*XH) + (PH*XH_ZN) - MF_ZN;
N1           = (B_K + (B_Q*omega_21)); 
N2           = ((B_K*omega_13) + (B_Q*omega_23) + B_ZH); 
N3           = ((B_K*omega_14) + (B_Q*omega_24) + B_ZN); 
wB1          = N1/(r-nu_1); 
wBH          = N2/(r+xiH); 
wBN          = N3/(r+xiN);

% Solution for the price of non traded goods in terms of home traded goods
% - P = P(lambda,K,Q,ZH,ZF); 
P = PN/PH; 
P_K  = (P/PN)*PN_K - (P/PH)*PH_K; 
P_Q  = (P/PN)*PN_Q - (P/PH)*PH_Q;
P_ZH = (P/PN)*PN_ZH - (P/PH)*PH_ZH;
P_ZN = (P/PN)*PN_ZN - (P/PH)*PH_ZN;

% Solution for PC=PC(PH,PN) - PC = PC(lambda,K,Q,ZH,ZF)
PC_K       = (PC/PH)*alphaC*alphaH*PH_K + (PC/PN)*(1-alphaC)*PN_K; 
PC_Q       = (PC/PH)*alphaC*alphaH*PH_Q + (PC/PN)*(1-alphaC)*PN_Q;
PC_ZH      = (PC/PH)*alphaC*alphaH*PH_ZH + (PC/PN)*(1-alphaC)*PN_ZH;
PC_ZN      = (PC/PH)*alphaC*alphaH*PH_ZN + (PC/PN)*(1-alphaC)*PN_ZN;
PC_lambda  = (PC/PH)*alphaC*alphaH*PH_lambda + (PC/PN)*(1-alphaC)*PN_lambda;

% Solution for PI=PI(PH,PN) - PI = PI(lambda,K,Q,ZH,ZF)
PI_K       = (PI/PH)*alphaI*alphaIH*PH_K + (PI/PN)*(1-alphaI)*PN_K; 
PI_Q       = (PI/PH)*alphaI*alphaIH*PH_Q + (PI/PN)*(1-alphaI)*PN_Q;
PI_ZH      = (PI/PH)*alphaI*alphaIH*PH_ZH + (PI/PN)*(1-alphaI)*PN_ZH;
PI_ZN      = (PI/PH)*alphaI*alphaIH*PH_ZN + (PI/PN)*(1-alphaI)*PN_ZN;
PI_lambda  = (PI/PH)*alphaI*alphaIH*PH_lambda + (PI/PN)*(1-alphaI)*PN_lambda;

% Solution for G=G(PH,PN) - G= G(lambda,K,Q,ZH,ZF)
G_K        = (PH_K*GH) + (PN_K*GN); 
G_Q        = (PH_Q*GH) + (PN_Q*GN);
G_ZH       = (PH_ZH*GH) + (PN_ZH*GN);
G_ZN       = (PH_ZN*GH) + (PN_ZN*GN);
G_lambda   = (PH_lambda*GH) + (PN_lambda*GN);

% Solution for the stock of financial wealth
A0        = B0 + (PI*K0); 
A_K       = (W_K*L) + (W*L_K) - G_K - (PC_K*C) - (PC*C_K); 
A_Q       = (W_Q*L) + (W*L_Q) - G_Q - (PC_Q*C) - (PC*C_Q); 
A_ZH      = (W_ZH*L) + (W*L_ZH) - G_ZH - (PC_ZH*C) - (PC*C_ZH);
A_ZN      = (W_ZN*L) + (W*L_ZN) - G_ZN - (PC_ZN*C) - (PC*C_ZN);
M1        = A_K + (A_Q*omega_21); 
M2        = ((A_K*omega_13) + (A_Q*omega_23) + A_ZH); 
M3        = ((A_K*omega_14) + (A_Q*omega_24) + A_ZN); 
wA1       = M1/(r-nu_1); 
wAH       = M2/(r+xiH); 
wAN       = M3/(r+xiN);
A         = A0 + (wA1*D1) + (wAH*D3) + (wAN*D4); 

% Solution for the labor income share sLj=sLj(K,Q,ZH,ZN)
sLH_K  = sLH*( (WH_K/WH) + (LH_K/LH) - (PH_K/PH) - (YH_K/YH) ); 
sLH_Q  = sLH*( (WH_Q/WH) + (LH_Q/LH) - (PH_Q/PH) - (YH_Q/YH) );
sLH_ZH = sLH*( (WH_ZH/WH) + (LH_ZH/LH) - (PH_ZH/PH) - (YH_ZH/YH) );
sLH_ZN = sLH*( (WH_ZN/WH) + (LH_ZN/LH) - (PH_ZN/PH) - (YH_ZN/YH) );

sLN_K  = sLN*( (WN_K/WN) + (LN_K/LN) - (PN_K/PN) - (YN_K/YN) );       
sLN_Q  = sLN*( (WN_Q/WN) + (LN_Q/LN) - (PN_Q/PN) - (YN_Q/YN) );       
sLN_ZH = sLN*( (WN_ZH/WN) + (LN_ZH/LN) - (PN_ZH/PN) - (YN_ZH/YN) );   
sLN_ZN = sLN*( (WN_ZN/WN) + (LN_ZN/LN) - (PN_ZN/PN) - (YN_ZN/YN) ); 

% Sectoral ratios
omegaINYN = IN/YN; 
omegaIHYH = IH /YH; 
omegaIFYH = IF/YH;
omegaGHYH = GH / YH;
omegaGFYH = GF / (PH*YH);
omegaGNYN = GN / YN;
omegaGN   = (PN*GN) / G;
omegaYH   = (PH*YH) / Y;
omegaYN   = (PN*YN) /Y; 
omegaLH   = LH / L;
omegaLN   = LN / L;

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GH+PN*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
% Check the closure of the model
cond1  = PH*(1-thetaH)*(YH/KH)-RK;                               
cond2  = PN*(1-thetaN)*(YN/KN)-RK;                             
cond3  = PH*thetaH*(YH/LH)-WH;                                   
cond4  = PN*thetaN*(YN/LN)-WN;                                 
cond5  = (LH*kH)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YH-CH-GH-IH-XH;                                   
cond9  = (B-B0) - (wB1*D1) - (wBH*D3) - (wBN*D4);
cond10 = DetJ1 - (nu_1*nu_2);
cond11 = TrJ1 - (nu_1+nu_2);                                   
cond12 = (LH+LN) - L;  
cond13 = (CT/CN) - (varphi/(1-varphi))*(PN/PT)^(phi);               
cond14 = (PC*C) - ((PT*CT)+(PN*CN));                                
cond15 = (W*L) - ((WH*LH)+(WN*LN));                                        
cond16 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond17 = Sav;                                                 
cond18 = (PC*C) - (CF+(PH*CH)+(PN*CN));                                
cond19 = (IT/IN) - (iota/(1-iota))*(PN/PIT)^(phiI);            
cond20 = (PI*I) - ((PIT*IT)+(PN*IN));                                
cond21 = (RK*K) - ((RKH*KH)+(RKN*KN));                        
cond22 = 1 - (omegaK + omegaL);    
cond23 = (CH/CF) - (varphiH/(1-varphiH))*(PH)^(-rho);    
cond24 = (PT*CT) - ((PH*CH)+CF); 
cond25 = (IH/IF) - (iotaH/(1-iotaH))*(PH)^(-rhoI);    
cond26 = (PIT*IT) - ((PH*IH)+IF); 
cond27 = r*B + (PH*XH) - MF; 
cond28 = omega_13 - omega13; 
cond29 = omega_14 - omega14; 
cond30 = omega_23 - omega23; 
cond31 = omega_24 - omega24; 
cond32 = nu_3 + xiH; 
cond33 = nu_4 + xiN; 

% Define New steady-state values
kH_pmlcactot = kH; kN_pmlcactot = kN; PN_pmlcactot = PN; LH_pmlcactot = LH; K_pmlcactot = K; C_pmlcactot = C;  
LN_pmlcactot = LN; L_pmlcactot  = L; W_pmlcactot = W; P_pmlcactot = P; 
YH_pmlcactot = YH; YN_pmlcactot = YN; Y_pmlcactot = Y; KH_pmlcactot  = KH; KN_pmlcactot  = KN; G_pmlcactot = G;     
PC_pmlcactot = PC; alphaC_pmlcactot = alphaC; CN_pmlcactot = CN; CH_pmlcactot = CH;  
GH_pmlcactot = GH; GN_pmlcactot = GN; ZH_pmlcactot = ZH; ZN_pmlcactot = ZN; Z_pmlcactot = Z; 
LH_pmlcactot = LH; LN_pmlcactot = LN; KH_pmlcactot = KH; KN_pmlcactot = KN; WH_pmlcactot = WH; WN_pmlcactot = WN; 
Omega_pmlcactot = Omega; WPC_pmlcactot = WPC; WHPC_pmlcactot = WHPC; WNPC_pmlcactot = WNPC;
IF_pmlcactot = IF; CF_pmlcactot = CF; XH_pmlcactot = XH; MF_pmlcactot = MF; GF_pmlcactot = GF; PH_pmlcactot = PH; 
PT_pmlcactot = PT; PIT_pmlcactot = PIT; CT_pmlcactot = CT; IT_pmlcactot = IT; GT_pmlcactot = GT; 

YHYN_pmlcactot = YHYN; LHLN_pmlcactot = LHLN; IH_pmlcactot = IH; IN_pmlcactot = IN; PI_pmlcactot = PI; 
EI_pmlcactot = EI; CA_pmlcactot = CA; Sav_pmlcactot = Sav; NX_pmlcactot = NX; I_pmlcactot = I; A_pmlcactot = A; 
B_pmlcactot = B; lambda_pmlcactot  = lambda; RK_pmlcactot = RK; YR_pmlcactot = YR; 

omegaL_pmlcactot = omegaL; omegaK_pmlcactot = omegaK; omegaI_pmlcactot = omegaI; omegaINYN_pmlcactot = omegaINYN;
omegaIHYH_pmlcactot = omegaIHYH; omega_IFYH_pmlcactot = omegaIFYH; omegaGHYH_pmlcactot = omegaGHYH; 
omegaGFYH_pmlcactot = omegaGFYH; omegaGNYN_pmlcactot = omegaGNYN; omegaGN_pmlcactot = omegaGN;
omegaYH_pmlcactot = omegaYH; omegaYN_pmlcactot = omegaYN; omegaLH_pmlcactot = omegaLH; omegaLN_pmlcactot = omegaLN; 
omegaC_pmlcactot =omegaC; omegaNX_pmlcactot =omegaNX; omegaG_pmlcactot =omegaG; omegaB_pmlcactot =omegaB; 
omegaKY_pmlcactot = omegaKY; omegaIH_pmlcactot = omegaIH; omegaIF_pmlcactot = omegaIF; 
omegaGT_pmlcactot = omegaGT; omegaGH_pmlcactot = omegaGH; omegaGF_pmlcactot = omegaGF;
alphaL_pmlcactot = alphaL; alphaK_pmlcactot = alphaK; alphaC_pmlcactot = alphaC; 
alphaI_pmlcactot = alphaI; alphaH_pmlcactot = alphaH; alphaIH_pmlcactot = alphaIH;
omegaYHR_pmlcactot = omegaYHR; omegaYNR_pmlcactot = omegaYNR; sLH_pmlcactot = sLH, sLN_pmlcactot = sLN;

% Steady-State Changes
dC       = C_pmlcactot - C_0; % Steady-state change of real consumption 
dK       = K_pmlcactot - K_0; % Steady-state change of real capital 
dL       = L_pmlcactot - L_0; % Steady-state change of employment 
dPN      = PN_pmlcactot - PN_0; % Steady-state change of non traded good prices
dPH      = PH_pmlcactot - PH_0; % Steady-state change of terms of trade (price of exports in terms if imports)
dP       = P_pmlcactot - P_0; % Steady-state change of non traded goods prices relative to tradable home goods prices
dB       = B_pmlcactot - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_pmlcactot - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = ( (PH_pmlcactot*YH_pmlcactot) + (PN_pmlcactot*YN_pmlcactot) ) - Y_0; % Steady-state change of GDP 
dY_check = Y_pmlcactot - Y_0; % Steady-state change of GDP - Check
dYR      = YR_pmlcactot - Y_0; % Steady-state change of real GDP 
dA       = A_pmlcactot - A_0; % Steady-state change of financial wealth 
dW       = W_pmlcactot - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_pmlcactot - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_pmlcactot - Omega_0; % Steady-state change of the sector wage ratio

dCH   = CH_pmlcactot - CH_0; % Steady-state change of cT
dCN   = CN_pmlcactot - CN_0; % Steady-state change of cT
dLH   = LH_pmlcactot - LH_0; % Steady-state change of real capital 
dLN   = LN_pmlcactot - LN_0; % Steady-state change of employment 
dKH   = KH_pmlcactot - KH_0; % Steady-state change of real capital 
dKN   = KN_pmlcactot - KN_0; % Steady-state change of employment 
dYH   = YH_pmlcactot - YH_0; % Steady-state change of YH
dYN   = YN_pmlcactot - YN_0; % Steady-state change of YN
dWH   = WH_pmlcactot - WH_0; % Steady-state change of WH
dWN   = WN_pmlcactot - WN_0; % Steady-state change of WN
dWHPC = WHPC_pmlcactot - WHPC_0; % Steady-state change of WH/PC
dWNPC = WNPC_pmlcactot - WNPC_0; % Steady-state change of WN/PC
dkH   = kH_pmlcactot - kH_0; % Steady-state change of kH 
dkN   = kN_pmlcactot - kN_0; % Steady-state change of kN
dLHLN = LHLN_pmlcactot - LHLN_0; % Steady-state change of LH/LN
dYHYN = YHYN_pmlcactot - YHYN_0; % Steady-state change of LH/LN

dZH   = ZH_pmlcactot - ZH_0; 
dZN   = ZN_pmlcactot - ZN_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% Solution for investment PI*K, 
EK_1  = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*V1(t) + EK2*X2(t)
EK_H  = (PI*omega_13) + (K*omega_23);
EK_N  = (PI*omega_14) + (K*omega_24);

% Solution for the Consumption Price index PC=PC(lambda,K,Q,ZH,ZN)
wPC_1  =  PC_K + (PC_Q*omega_21); 
wPC_H  = (PC_K*omega_13) + (PC_Q*omega_23) + PC_ZH;
wPC_N  = (PC_K*omega_14) + (PC_Q*omega_24) + PC_ZN;

% Solution for the Investment Price index PI=PI(lambda,K,Q,ZH,ZN)
wPI_1  =  PI_K + (PI_Q*omega_21); 
wPI_H  = (PI_K*omega_13) + (PI_Q*omega_23) + PI_ZH;
wPI_N  = (PI_K*omega_14) + (PI_Q*omega_24) + PI_ZN;

% Solution for the Relative Price of Non tradables PN=PN(lambda,K,Q,ZH,ZN)
wPN_1  =  PN_K + (PN_Q*omega_21); 
wPN_H  = (PN_K*omega_13) + (PN_Q*omega_23) + PN_ZH;
wPN_N  = (PN_K*omega_14) + (PN_Q*omega_24) + PN_ZN;

% Solution for the Terms of Trade PH=PH(lambda,K,Q,ZH,ZN)
wPH_1  =  PH_K + (PH_Q*omega_21); 
wPH_H  = (PH_K*omega_13) + (PH_Q*omega_23) + PH_ZH;
wPH_N  = (PH_K*omega_14) + (PH_Q*omega_24) + PH_ZN;
 
% Solution for the Price of non tradables in terms of home tradable goods P=P(lambda,K,Q,ZH,ZN)
wP_1  = (P/PN)*wPN_1 - (P/PH)*wPH_1; 
wP_H  = (P/PN)*wPN_H - (P/PH)*wPH_H; 
wP_N  = (P/PN)*wPN_N - (P/PH)*wPH_N; 

% Solution for Q(t)/PI(P(t))
wQPI_1 = (omega_21/PI) - (wPI_1/PI); 
wQPI_H = (omega_23/PI) - (wPI_H/PI);
wQPI_N = (omega_24/PI) - (wPI_N/PI);

% Solution for Consumption C=C(lambda,P)
wC_1 =  C_K + (C_Q*omega_21); 
wC_H = (C_K*omega_13) + (C_Q*omega_23) + C_ZH; 
wC_N = (C_K*omega_14) + (C_Q*omega_24) + C_ZN;

% Solution for the Aggregate Wage Index W=W(K,Q,ZH,ZN)
wW_1  =  W_K + (W_Q*omega_21); 
wW_H  = (W_K*omega_13) + (W_Q*omega_23) + W_ZH; 
wW_N  = (W_K*omega_14) + (W_Q*omega_24) + W_ZN;  

% Solution for the Capital Rental Rate RK=R(K,Q,ZH,ZN)
wR_1  =  R_K + (R_Q*omega_21); 
wR_H  = (R_K*omega_13) + (R_Q*omega_23) + R_ZH; 
wR_N  = (R_K*omega_14) + (R_Q*omega_24) + R_ZN; 

% Solution for the Real Consumption Wage W(K,Q,ZH,ZN)/PC(P)
wWPC_1 = WPC*( (wW_1/W) - (wPC_1/PC) ); 
wWPC_H = WPC*( (wW_H/W) - (wPC_H/PC) );
wWPC_N = WPC*( (wW_N/W) - (wPC_N/PC) );

% Solution for Labor L=L(lambda,W)=L(lambda,K,Q,ZH,ZN)
wL_1 =  L_K + (L_Q*omega_21); 
wL_H = (L_K*omega_13) + (L_Q*omega_23) + L_ZH; 
wL_N = (L_K*omega_14) + (L_Q*omega_24) + L_ZN;

% Solutions for the Sectoral Labor kj=kj(lambda,K,Q,ZH,ZN)
wkH_1  =  kH_K + (kH_Q*omega_21); 
wkH_H  = (kH_K*omega_13) + (kH_Q*omega23) + kH_ZH;
wkH_N  = (kH_K*omega_14) + (kH_Q*omega_24) + kH_ZN; 

wkN_1  =  kN_K + (kN_Q*omega_21); 
wkN_H  = (kN_K*omega_13) + (kN_Q*omega23) + kN_ZH;
wkN_N  = (kN_K*omega_14) + (kN_Q*omega_24) + kN_ZN;  

% Solutions for the Sectoral Labor Lj=Lj(lambda,K,Q,ZH,ZN)
wLH_1  =  LH_K + (LH_Q*omega_21); 
wLH_H  = (LH_K*omega_13) + (LH_Q*omega_23) + LH_ZH;
wLH_N  = (LH_K*omega_14) + (LH_Q*omega_24) + LH_ZN;

wLN_1  =  LN_K + (LN_Q*omega_21); 
wLN_H  = (LN_K*omega_13) + (LN_Q*omega_23) + LN_ZH;
wLN_N  = (LN_K*omega_14) + (LN_Q*omega_24) + LN_ZN;

% Solution for GDP Y=Y(lambda,K,Q,ZH,ZN)
wY_1   = Y_K + (Y_Q*omega_21);  
wY_H   = (Y_K*omega_13) + (Y_Q*omega_23) + Y_ZH;
wY_N   = (Y_K*omega_14) + (Y_Q*omega_24) + Y_ZN;

wYR_1  = (PH_0*YH_K) + (PN_0*YN_K) + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_21;  
wYR_H  = ((PH_0*YH_K) + (PN_0*YN_K))*omega_13 + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_23 + ((PH_0*YH_ZH) + (PN_0*YN_ZH));
wYR_N  = ((PH_0*YH_K) + (PN_0*YN_K))*omega_14 + ((PH_0*YH_Q) + (PN_0*YN_Q))*omega_24 + ((PH_0*YH_ZN) + (PN_0*YN_ZN));

% Solutions for the Sectoral Output Yj=Yj(lambda,K,Q,ZH,ZN)
wYH_1  = YH_K + (YH_Q*omega_21); 
wYH_H  = (YH_K*omega_13) + (YH_Q*omega_23) + YH_ZH;
wYH_N  = (YH_K*omega_14) + (YH_Q*omega_24) + YH_ZN;

wYN_1  = YN_K + (YN_Q*omega_21); 
wYN_H  = (YN_K*omega_13) + (YN_Q*omega_23) + YN_ZH;
wYN_N  = (YN_K*omega_14) + (YN_Q*omega_24) + YN_ZN;

% Solutions for the Sectoral Wages Wj=Wj(K,Q,ZH,ZN)
wWH_1  = WH_K + (WH_Q*omega_21);                    
wWH_H  = (WH_K*omega_13) + (WH_Q*omega_23) + WH_ZH;  
wWH_N  = (WH_K*omega_14) + (WH_Q*omega_24) + WH_ZN; 
                                              
wWN_1  = WN_K + (WN_Q*omega_21);                    
wWN_H  = (WN_K*omega_13) + (WN_Q*omega_23) + WN_ZH; 
wWN_N  = (WN_K*omega_14) + (WN_Q*omega_24) + WN_ZN; 

% Solutions for the Real Sectoral Wages Wj(K,P)/PC(P) 
wWHPC_1 = WHPC*( (wWH_1/WH) - (wPC_1/PC) );
wWHPC_H = WHPC*( (wWH_H/WH) - (wPC_H/PC) );
wWHPC_N = WHPC*( (wWH_N/WH) - (wPC_N/PC) );
                                           
wWNPC_1 = WNPC*( (wWN_1/WN) - (wPC_1/PC) );
wWNPC_H = WNPC*( (wWN_H/WN) - (wPC_H/PC) );
wWNPC_N = WNPC*( (wWN_N/WN) - (wPC_N/PC) );

% Solution for Omega = WN(K,P)/WH(K,P)
wOmega_1 = Omega*( (wWN_1/WN) - (wWH_1/WH) ); 
wOmega_H = Omega*( (wWN_H/WN) - (wWH_H/WH) ); 
wOmega_N = Omega*( (wWN_N/WN) - (wWH_N/WH) ); 

% Solution for YH(lambda,K,Q,ZH,ZN)/YN(lambda,K,Q,ZH,ZN)
wYHYN_1 = YHYN*( (wYH_1/YH) - (wYN_1/YN) );  
wYHYN_H = YHYN*( (wYH_H/YH) - (wYN_H/YN) );  
wYHYN_N = YHYN*( (wYH_N/YH) - (wYN_N/YN) );  

% Solution for LH(lambda,K,Q,ZH,ZN)/LN(lambda,K,Q,ZH,ZN)
wLHLN_1 = LHLN*( (wLH_1/LH) - (wLN_1/LN) );  
wLHLN_H = LHLN*( (wLH_H/LH) - (wLN_H/LN) );  
wLHLN_N = LHLN*( (wLH_N/LH) - (wLN_N/LN) );  

% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(lambda,K,Q,ZH,ZN)
wYHS_1  = omegaYHR*( (wYH_1/YH) - (wYR_1/YR) ); 
wYHS_H  = omegaYHR*( (wYH_H/YH) - (wYR_H/YR) ); 
wYHS_N  = omegaYHR*( (wYH_N/YH) - (wYR_N/YR) ); 
                                         
wYNS_1  = omegaYNR*( (wYN_1/YN) - (wYR_1/YR) ); 
wYNS_H  = omegaYNR*( (wYN_H/YN) - (wYR_H/YR) ); 
wYNS_N  = omegaYNR*( (wYN_N/YN) - (wYR_N/YR) ); 

% Solutions for the labor income shares sLj=sLj(lambda,K,Q,ZH,ZN)
wLHS_1  = omegaLH*((wLH_1/LH)-(wL_1/L)); 
wLHS_H  = omegaLH*((wLH_H/LH)-(wL_H/L)); 
wLHS_N  = omegaLH*((wLH_N/LH)-(wL_N/L)); 
                                      
wLNS_1  = omegaLN*((wLN_1/LN)-(wL_1/L)); 
wLNS_H  = omegaLN*((wLN_H/LN)-(wL_H/L)); 
wLNS_N  = omegaLN*((wLN_N/LN)-(wL_N/L)); 

% Solutions for the labor income shares sLj=LISj(lambda,K,Q,ZH,ZN) -
% sLj = Wj*Lj/(Pj*Yj) - 
wLISH_1 = sLH_K + (sLH_Q*omega_21); 
wLISH_H = (sLH_K*omega_13) + (sLH_Q*omega_23) + sLH_ZH;
wLISH_N = (sLH_K*omega_14) + (sLH_Q*omega_24) + sLH_ZN; 

wLISN_1 = sLN_K + (sLN_Q*omega_21); 
wLISN_H = (sLN_K*omega_13) + (sLN_Q*omega_23) + sLN_ZH;
wLISN_N = (sLN_K*omega_14) + (sLN_Q*omega_24) + sLN_ZN;   

% Solutions for the relative wages Wj/W: WjW=WjW(lambda,K,Q,ZH,ZN) -
wWHW_1 = (WH/W)*( (wWH_1/WH) - (wW_1/W) ); 
wWHW_H = (WH/W)*( (wWH_H/WH) - (wW_H/W) ); 
wWHW_N = (WH/W)*( (wWH_N/WH) - (wW_N/W) ); 
                                           
wWNW_1 = (WN/W)*( (wWN_1/WN) - (wW_1/W) ); 
wWNW_H = (WN/W)*( (wWN_H/WN) - (wW_H/W) ); 
wWNW_N = (WN/W)*( (wWN_N/WN) - (wW_N/W) ); 

% Transitional Paths 
Tm = 0; Tu = 1; Tg = 10;
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdZH0    = (ZH_0 - ZH_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathdZ0     = (Z_0 - Z_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdLHL0   = (LN_0 - LN_0) + 0*time0;
pathdLNL0   = (LH_0 - LH_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWH0    = (WH_0 - WH_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYHYN0  = (YHYN_0 - YHYN_0) + 0*time0;
pathdLHLN0  = (LHLN_0 - LHLN_0) + 0*time0;
pathdIHY0   = (IN_0 - IN_0) + 0*time0;
pathdINY0   = (IH_0 - IH_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0; 
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLISH0  = (sLH_0 - sLH_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..10]
V1           = D1*exp(nu_1*time1); 
VH           = aH*exp(-xiH*time1);
VN           = aN*exp(-xiN*time1);
%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pathdZH1     = (( (ZH_pmlcactot-ZH_0) +  VH )/ZH_0)*100;
pathdZN1     = (( (ZN_pmlcactot-ZN_0) +  VN )/ZN_0)*100;
pathdZ1       = a*( (((ZH_pmlcactot-ZH_0) + VH)/ZH_0) - b*(((ZN_pmlcactot-ZN_0) + VN)/ZN_0) )*100; 
pathdQ1      = (((PI_pmlcactot-PI_0) + (omega_21*V1) + (omega_23*VH) + (omega_23*VN))/PI_0)*100;
pathdPH1     = (((PH_pmlcactot-PH_0) + (wPH_1*V1) + (wPH_H*VH) + (wPH_N*VN) )/PH_0)*100;
pathdPN1     = (((PN_pmlcactot-PN_0) + (wPN_1*V1) + (wPN_H*VH) + (wPN_N*VN) )/PN_0)*100; 
pathdP1      = (((P_pmlcactot-P_0) + (wP_1*V1) + (wP_H*VH) + (wP_N*VN) )/P_0)*100;
pathCY1      = ( PC_0*((C_pmlcactot-C_0) + (wC_1*V1) + (wC_H*VH) + (wC_N*VN) )/Y_0 )*100;
pathdQPI1    = ( (wQPI_1*V1) + (wQPI_H*VH) + (wQPI_N*VN) )*100;
pathdL1      = (((L_pmlcactot-L_0)  + (wL_1*V1) + (wL_H*VH) + (wL_N*VN) )/L_0)*100;
pathdLHL1    = ( (1-alphaL_0)*((LH_pmlcactot-LH_0) + (wLH_1*V1) + (wLH_H*VH) + (wLH_N*VN) )/LH_0)*100;
pathdLNL1    = ( alphaL_0*((LN_pmlcactot-LN_0) + (wLN_1*V1) + (wLN_H*VH) + (wLN_N*VN) )/LN_0)*100;
pathdkHK1    = ( LH_0*((kH_pmlcactot-kH_0) + (wkH_1*V1) + (wkH_H*VH) + (wkH_N*VN) )/K_0)*100;
pathdkNK1    = ( LN_0*((kN_pmlcactot-kN_0) + (wkN_1*V1) + (wkN_H*VH) + (wkN_N*VN) )/K_0)*100;
pathdW1      = (((W_pmlcactot-W_0) + (wW_1*V1) + (wW_H*VH) + (wW_N*VN) )/W_0)*100;
pathdR1      = (((RK_pmlcactot-RK_0) + (wR_1*V1) + (wR_H*VH) + (wR_N*VN) )/RK_0)*100;                    
pathdWPC1    = (((WPC_pmlcactot-WPC_0) + (wWPC_1*V1) + (wWPC_H*VH) + (wWPC_N*VN) )/WPC_0)*100;           
pathdY1      = (((Y_pmlcactot-Y_0) + (wY_1*V1) + (wY_H*VH) + (wY_N*VN) )/Y_0)*100;                       
pathdYR1     = (((YR_pmlcactot-Y_0) + (wYR_1*V1) + (wYR_H*VH) + (wYR_N*VN) )/Y_0)*100;                   
pathdYHY1    = (PH_0*((YH_pmlcactot-YH_0) + (wYH_1*V1) + (wYH_H*VH) + (wYH_N*VN) )/Y_0)*100;                  
pathdYNY1    = (PN_0*((YN_pmlcactot-YN_0) + (wYN_1*V1) + (wYN_H*VH) + (wYN_N*VN) )/Y_0)*100;            
pathdWH1     = (((WH_pmlcactot-WH_0) + (wWH_1*V1) + (wWH_H*VH) + (wWH_N*VN) )/WH_0)*100;                 
pathdWN1     = (((WN_pmlcactot-WN_0) + (wWN_1*V1) + (wWN_H*VH) + (wWN_N*VN) )/WN_0)*100;                 
pathdWHPC1   = (((WHPC_pmlcactot-WHPC_0) + (wWHPC_1*V1) + (wWHPC_H*VH) + (wWHPC_N*VN) )/WHPC_0)*100;     
pathdWNPC1   = (((WNPC_pmlcactot-WNPC_0) + (wWNPC_1*V1) + (wWNPC_H*VH) + (wWNPC_N*VN) )/WNPC_0)*100;
pathdWHW1    = (( ((WH_pmlcactot/W_pmlcactot)-(WH_0/W_0)) + (wWHW_1*V1) + (wWHW_H*VH) + (wWHW_N*VN) )/(WH_0/W_0) )*100;     
pathdWNW1    = (( ((WN_pmlcactot/W_pmlcactot)-(WN_0/W_0)) + (wWNW_1*V1) + (wWNW_H*VH) + (wWNW_N*VN) )/(WN_0/W_0) )*100;  

pathCAY1     = (( -(nu_1*wB1*V1) + (xiH*wBH*VH) + (xiN*wBN*VN) )/Y_0 )*100;
pathSY1      = (( -(nu_1*wA1*V1) + (xiH*wAH*VH) + (xiN*wAN*VN) )/Y_0 )*100;
pathIY1      = (( (nu_1*EK_1*V1) - (xiH*EK_H*VH) - (xiN*EK_N*VN) )/Y_0)*100; 

pathdOmega1  = (((Omega_pmlcactot-Omega_0) + (wOmega_1*V1) + (wOmega_H*VH) + (wOmega_N*VN) )/Omega_0)*100; 
pathdYHYN1   = (PH_0/PN_0)*( (YHYN_pmlcactot-YHYN_0) + (wYHYN_1*V1) + (wYHYN_H*VH) + (wYHYN_N*VN) )*100;
pathdLHLN1   = (WH_0/WN_0)*( (LHLN_pmlcactot-LHLN_0) + (wLHLN_1*V1) + (wLHLN_H*VH) + (wLHLN_N*VN) )*100;

pathdLHS1    = (1-alphaL_0)*(( (omegaLH_pmlcactot-omegaLH_0) + (wLHS_1*V1) + (wLHS_H*VH) + (wLHS_N*VN) )/omegaLH_0)*100;    
pathdLNS1    = alphaL_0*(( (omegaLN_pmlcactot-omegaLN_0) + (wLNS_1*V1) + (wLNS_H*VH) + (wLNS_N*VN) )/omegaLN_0)*100;  
pathdYHS1    = ( (omegaYHR_pmlcactot-omegaYH_0) + (wYHS_1*V1) + (wYHS_H*VH) + (wYHS_N*VN) )*100;   
pathdYNS1    = ( (omegaYNR_pmlcactot-omegaYN_0) + (wYNS_1*V1) + (wYNS_H*VH) + (wYNS_N*VN) )*100;  

pathdLISH1   = ( (sLH_pmlcactot-sLH_0) + (wLISH_1*V1) + (wLISH_H*VH) + (wLISH_N*VN) )*100;
pathdLISN1   = ( (sLN_pmlcactot-sLN_0) + (wLISN_1*V1) + (wLISN_H*VH) + (wLISN_N*VN) )*100;

% Temporal paths over entire period
timeperm = [time0 time1];
pathdZH_pmlcactot    = [pathdZH0  pathdZH1];
pathdZN_pmlcactot    = [pathdZN0  pathdZN1];
pathdZ_pmlcactot     = [pathdZ0   pathdZ1];
pathdQ_pmlcactot     = [pathdQ0  pathdQ1];
pathdQPI_pmlcactot   = [pathdQ0  pathdQPI1];
pathdPH_pmlcactot    = [pathdP0  pathdPH1];
pathdPN_pmlcactot    = [pathdP0  pathdPN1];
pathdP_pmlcactot     = [pathdP0  pathdP1]; 
pathCY_pmlcactot     = [pathCY0  pathCY1];                                             
pathdL_pmlcactot     = [pathdL0  pathdL1];                
pathdLHL_pmlcactot   = [pathdLHL0 pathdLHL1];             
pathdLNL_pmlcactot   = [pathdLNL0 pathdLNL1]; 
pathdkHK_pmlcactot   = [pathdLHL0 pathdkHK1];             
pathdkNK_pmlcactot   = [pathdLNL0 pathdkNK1]; 
pathdW_pmlcactot     = [pathdW0 pathdW1]; 
pathdR_pmlcactot     = [pathdR0 pathdR1]; 
pathdWPC_pmlcactot   = [pathdWPC0 pathdWPC1]; 
pathdY_pmlcactot     = [pathdY0 pathdY1]; 
pathdYR_pmlcactot    = [pathdY0 pathdYR1];
pathdYHY_pmlcactot   = [pathdY0 pathdYHY1];               
pathdYNY_pmlcactot   = [pathdY0 pathdYNY1];               
pathdWH_pmlcactot    = [pathdWH0  pathdWH1];              
pathdWN_pmlcactot    = [pathdWN0  pathdWN1]; 
pathdWHPC_pmlcactot  = [pathdWH0 pathdWHPC1];
pathdWNPC_pmlcactot  = [pathdWN0 pathdWNPC1];
pathdWHW_pmlcactot   = [pathdWH0 pathdWHW1];
pathdWNW_pmlcactot   = [pathdWN0 pathdWNW1];

pathIY_pmlcactot     = [pathIY0  pathIY1];                        
pathCAY_pmlcactot    = [pathCAY0 pathCAY1];               
pathSY_pmlcactot     = [pathSY0  pathSY1];

pathdOmega_pmlcactot = [pathdOmega0 pathdOmega1];         
pathdYHYN_pmlcactot  = [pathdYHYN0 pathdYHYN1];           
pathdLHLN_pmlcactot  = [pathdLHLN0 pathdLHLN1];

pathdLHS_pmlcactot   = [pathdLHL0 pathdLHS1];             
pathdLNS_pmlcactot   = [pathdLNL0 pathdLNS1];
pathdYHS_pmlcactot   = [pathdY0 pathdYHS1];             
pathdYNS_pmlcactot   = [pathdY0 pathdYNS1];

pathdLISH_pmlcactot  = [pathdLISH0 pathdLISH1];             
pathdLISN_pmlcactot  = [pathdLISN0 pathdLISN1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZH/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Impact Effects of an Unanticipated Rise in dZH(0) = aH and dZN(0) = aN
V10           = D1; 
VH0           = aH;
VN0           = aN;

pathZHtime0       = ZH_pmlcactot + VH0;  % initial level of TFP in the traded sector                                                                    
pathZNtime0       = ZN_pmlcactot + VN0;  % initial level of TFP in the non traded sector                                                                
pathQtime0        = PI_pmlcactot + (omega_21*V10) + (omega_23*VH0) + (omega_24*VN0);  % initial level of the shadow value of investment                                                       
pathCYtime0       = C_pmlcactot + (wC_1*V10) + (wC_H*VH0) + (wC_N*VN0);  % initial level of real consumption                                            
pathLtime0        = L_pmlcactot + (wL_1*V10) + (wL_H*VH0) + (wL_N*VN0);  % initial level of employment                                                  
pathLHtime0       = LH_pmlcactot + (wLH_1*V10) + (wLH_H*VH0) + (wLH_N*VN0);  % initial level of employment in sector H                                  
pathLNtime0       = LN_pmlcactot + (wLN_1*V10) + (wLN_H*VH0) + (wLN_N*VN0);  % initial level of employment in sector N        
pathPHtime0       = PH_pmlcactot + (wPH_1*V10) + (wPH_H*VH0) + (wPH_N*VN0);  % initial level of  PH   
pathPNtime0       = PN_pmlcactot + (wPN_1*V10) + (wPN_H*VH0) + (wPN_N*VN0);  % initial level of  PN  
pathPtime0        = P_pmlcactot + (wP_1*V10) + (wP_H*VH0) + (wP_N*VN0);  % initial level of  PN/PH                                         
pathWtime0        = W_pmlcactot + (wW_1*V10) + (wW_H*VH0) + (wW_N*VN0);  % initial level of the wage rate                                               
pathWPCtime0      = WPC_pmlcactot + (wWPC_1*V10) + (wWPC_H*VH0) + (wWPC_N*VN0);  % initial level of W/PC                                                
pathYtime0        = Y_pmlcactot + (wY_1*V10) + (wY_H*VH0) + (wY_N*VN0);  % initial level of Y                                                           
pathYRtime0       = YR_pmlcactot + (wYR_1*V10) + (wYR_H*VH0) + (wYR_N*VN0);  % initial level of Y once non tradable inflation is controlled for         
pathYHtime0       = YH_pmlcactot + (wYH_1*V10) + (wYH_H*VH0) + (wYH_N*VN0);  % initial level of YH                                                      
pathYNtime0       = YN_pmlcactot + (wYN_1*V10) + (wYN_H*VH0) + (wYN_N*VN0);  % initial level of YN                                                      
pathWHtime0       = WH_pmlcactot + (wWH_1*V10) + (wWH_H*VH0) + (wWH_N*VN0);  % initial level of WH                                                      
pathWNtime0       = WN_pmlcactot + (wWN_1*V10) + (wWN_H*VH0) + (wWN_N*VN0);  % initial level of WN                                                      
pathWHPCtime0     = WHPC_pmlcactot + (wWHPC_1*V10) + (wWHPC_H*VH0) + (wWHPC_N*VN0);  % initial level of WHPC                                            
pathWNPCtime0     = WNPC_pmlcactot + (wWNPC_1*V10) + (wWNPC_H*VH0) + (wWNPC_N*VN0);  % initial level of WNPC      
pathdkHKtime0     = kH_pmlcactot + (wkH_1*V10) + (wkH_H*VH0) + (wkH_N*VN0);
pathdkNKtime0     = kN_pmlcactot + (wkN_1*V10) + (wkN_H*VH0) + (wkN_N*VN0);
pathWHWtime0      = (WH_pmlcactot/W_pmlcactot) + (wWHW_1*V10) + (wWHW_H*VH0) + (wWHW_N*VN0);  % initial level of WH/W                                           
pathWNWtime0      = (WN_pmlcactot/W_pmlcactot) + (wWNW_1*V10) + (wWNW_H*VH0) + (wWNW_N*VN0);  % initial level of WN/W     
                                                                                                                                                    
pathOmegatime0    = Omega_pmlcactot + (wOmega_1*V10) + (wOmega_H*VH0) + (wOmega_N*VN0);  % initial level of the sector wage ratio                       
pathYHYNtime0     = YHYN_pmlcactot + (wYHYN_1*V10) + (wYHYN_H*VH0) + (wYHYN_N*VN0);  % initial level of ratio YH/YN                                     
pathLHLNtime0     = LHLN_pmlcactot + (wLHLN_1*V10) + (wLHLN_H*VH0) + (wLHLN_N*VN0);  % initial level of ratio LH/LN                                     
                                                                                                                                                    
pathLHStime0      =  omegaLH_pmlcactot + (wLHS_1*V10) + (wLHS_H*VH0) + (wLHS_N*VN0);                                                                    
pathLNStime0      =  omegaLN_pmlcactot + (wLNS_1*V10) + (wLNS_H*VH0) + (wLNS_N*VN0);                                                                    
pathYHStime0      =  omegaYHR_pmlcactot + (wYHS_1*V10) + (wYHS_H*VH0) + (wYHS_N*VN0);                                                                   
pathYNStime0      =  omegaYNR_pmlcactot + (wYNS_1*V10) + (wYNS_H*VH0) + (wYNS_N*VN0);   

pathLISHtime0      =  sLH_pmlcactot + (wLISH_1*V10) + (wLISH_H*VH0) + (wLISH_N*VN0);                                                                   
pathLISNtime0      =  sLN_pmlcactot + (wLISN_1*V10) + (wLISN_H*VH0) + (wLISN_N*VN0);
                                                                                                                                                    
dZHtime0_pmlcactot      = ((pathZHtime0 - ZH_0)/ZH_0)*100;  % initial response of TFP in the traded sector
dZNtime0_pmlcactot      = ((pathZNtime0 - ZN_0)/ZN_0)*100;  % initial response of TFP in the non traded sector
dZtime0_pmlcactot       = (a*((pathZHtime0 - ZH_0)/ZH_0) - b*((pathZNtime0 - ZN_0)/ZN_0))*100;  % initial response of the productivity differential
dCYtime0_pmlcactot      = (PC_0*(pathCYtime0 - C_0)/Y_0)*100;  % initial response of real consumption 
dLtime0_pmlcactot       = ((pathLtime0 - L_0)/L_0)*100; % initial response of employment
dLHtime0_pmlcactot      = ((1-alphaL_0)*(pathLHtime0 - LH_0)/LH_0)*100; % initial response of employment in sector H 
dLNtime0_pmlcactot      = (alphaL_0*(pathLNtime0 - LN_0)/LN_0)*100; % initial response of employment in sector N 
dLHLNtime0_pmlcactot    = (WH_0/WN_0)*(pathLHLNtime0 - LHLN_0)*100; % initial response of ratio LH/LN 
dPHtime0_pmlcactot      = ((pathPHtime0 - PH_0)/PH_0)*100; % initial response of PH
dPNtime0_pmlcactot      = ((pathPNtime0 - PN_0)/PN_0)*100; % initial response of PN
dPtime0_pmlcactot       = ((pathPtime0 - P_0)/P_0)*100; % initial response of PN/PH
dWtime0_pmlcactot       = ((pathWtime0 - W_0)/W_0)*100; % initial response of W 
dWPCtime0_pmlcactot     = ((pathWPCtime0 - WPC_0)/WPC_0)*100; % initial response of W/PC 
dYtime0_pmlcactot       = ((pathYtime0 - Y_0)/Y_0)*100; % initial response of Y
dYRtime0_pmlcactot      = ((pathYRtime0 - Y_0)/Y_0)*100; % initial response of real GDP 
dYHtime0_pmlcactot      = (PH_0*(pathYHtime0 - YH_0)/Y_0)*100; % initial response of YH
dYNtime0_pmlcactot      = (PN_0*(pathYNtime0 - YN_0)/Y_0)*100; % initial response of YN
dYHYNtime0_pmlcactot    = (PH_0/PN_0)*((pathYHYNtime0 - YHYN_0))*100; % initial response of ratio YH/YN 
dWHtime0_pmlcactot      = ((pathWHtime0 - WH_0)/WH_0)*100; % initial response of wage in sector H 
dWNtime0_pmlcactot      = ((pathWNtime0 - WN_0)/WN_0)*100; % initial response of wage in sector N 
dWHPCtime0_pmlcactot    = ((pathWHPCtime0 - WHPC_0)/WHPC_0)*100; % initial response of real wage in sector H 
dWNPCtime0_pmlcactot    = ((pathWNPCtime0 - WNPC_0)/WNPC_0)*100; % initial response of real wage in sector N 
dOmegatime0_pmlcactot   = ((pathOmegatime0 - Omega_0)/Omega_0)*100; % initial response of the sector wage ratio
dkHKtime0_pmlcactot     = (LH_0*(pathdkHKtime0-kH_0)/K_0)*100;
dkNKtime0_pmlcactot     = (LN_0*(pathdkNKtime0-kN_0)/K_0)*100;
dLISHtime0_pmlcactot    = (pathLISHtime0-sLH_0)*100;
dLISNtime0_pmlcactot    = (pathLISNtime0-sLN_0)*100;
dWHWtime0_pmlcactot     = ((pathWHWtime0 - (WH_0/W_0))/(WH_0/W_0))*100; % initial response of WH/W
dWNWtime0_pmlcactot     = ((pathWNWtime0 - (WN_0/W_0))/(WN_0/W_0))*100; % initial response of WN/W 

dCAYtime0_pmlcactot     = (( -(nu_1*wB1*V10) + (xiH*wBH*VH0) + (xiN*wBN*VN0) )/Y_0 )*100; % initial response of current account dot{B}(0)
dSYtime0_pmlcactot      = (( -(nu_1*wA1*V10) + (xiH*wAH*VH0) + (xiN*wAN*VN0) )/Y_0 )*100; % initial response of saving dot{A}(0)
dIYtime0_pmlcactot      = (( (nu_1*EK_1*V10) - (xiH*EK_H*VH0) - (xiN*EK_N*VN0) )/Y_0)*100; % initial response of investment dot{Q*K}(0)

dCAYtime0_pmlcactot_check = dSYtime0_pmlcactot - dIYtime0_pmlcactot; 

%dLHStime0_pmlcactot     = (pathLHStime0-omegaLH_0)*100; % Initial response of LH/L
%dLNStime0_pmlcactot     = (pathLNStime0-omegaLN_0)*100; % Initial response of LN/L
dLHStime0_pmlcactot     = ((pathLHStime0-omegaLH_0)/omegaLH_0)*(1-alphaL_0)*100; % Initial response of LH/L
dLNStime0_pmlcactot     = ((pathLNStime0-omegaLN_0)/omegaLN_0)*alphaL_0*100; % Initial response of LN/L
dYHStime0_pmlcactot     = (pathYHStime0-omegaYH_0)*100; % Initial response of YH/Y
dYNStime0_pmlcactot     = (pathYNStime0-omegaYN_0)*100; % Initial response of YN/Y

% Changes at t=10
hatt        = 10; % span of time t = [0..10]
V1_10           = D1*exp(nu_1*hatt);
VH_10           = aH*exp(-xiH*hatt);
VN_10           = aH*exp(-xiH*hatt);
VAN_10          = aN*exp(-xiN*hatt);
VBN_10          = aN*exp(-xiN*hatt);

pathLHtime10     = LH_pmlcactot + (wLH_1*V1_10) + (wLH_H*VH_10) + (wLH_N*VN_10);  %  level of employment in sector H
pathLNtime10     = LN_pmlcactot + (wLN_1*V1_10) + (wLN_H*VH_10) + (wLN_N*VN_10);  %  level of employment in sector N
pathYHtime10     = YH_pmlcactot + (wYH_1*V1_10) + (wYH_H*VH_10) + (wYH_N*VN_10);  %  level of YH
pathYNtime10     = YN_pmlcactot + (wYN_1*V1_10) + (wYN_H*VH_10) + (wYN_N*VN_10);  %  level of YN
pathPHtime10     = PH_pmlcactot + (wPH_1*V1_10) + (wPH_H*VH_10) + (wPH_N*VN_10);  %  level of  PH
pathPtime10      = P_pmlcactot + (wP_1*V1_10) + (wP_H*VH_10) + (wP_N*VN_10);  %  level of  PN
pathLHStime10    = omegaLH_pmlcactot + (wLHS_1*V1_10) + (wLHS_H*VH_10) + (wLHS_N*VN_10);  % Home traded labor share
pathYHStime10    = omegaYHR_pmlcactot + (wYHS_1*V1_10) + (wYHS_H*VH_10) + (wYHS_N*VN_10); % Home traded output share
pathdkHKtime10   = kH_pmlcactot + (wkH_1*V1_10) + (wkH_H*VH_10) + (wkH_N*VN_10);
pathdkNKtime10   = kN_pmlcactot + (wkN_1*V1_10) + (wkN_H*VH_10) + (wkN_N*VN_10);
pathLISHtime10   = sLH_pmlcactot + (wLISH_1*V1_10) + (wLISH_H*VH_10) + (wLISH_N*VN_10);  % Home traded labor income share
pathLISNtime10   = sLN_pmlcactot + (wLISN_1*V1_10) + (wLISN_H*VH_10) + (wLISN_N*VN_10);  % Non traded labor income share
pathWHWtime10    = (WH_pmlcactot/W_pmlcactot) + (wWHW_1*V1_10) + (wWHW_H*VH_10) + (wWHW_N*VN_10);  % level of WH/W
pathWNWtime10    = (WN_pmlcactot/W_pmlcactot) + (wWNW_1*V1_10) + (wWNW_H*VH_10) + (wWNW_N*VN_10);  % level of WN/W

dLHtime10_pmlcactot      = ((1-alphaL_0)*(pathLHtime10 - LH_0)/LH_0)*100; %  response of employment in sector H
dLNtime10_pmlcactot      = (alphaL_0*(pathLNtime10 - LN_0)/LN_0)*100; %  response of employment in sector N
dYHtime10_pmlcactot      = (PH_0*(pathYHtime10 - YH_0)/Y_0)*100; %  response of YH
dYNtime10_pmlcactot      = (PN_0*(pathYNtime10 - YN_0)/Y_0)*100; % response of YN at time t=10 in % of GDP
dPHtime10_pmlcactot      = ((pathPHtime10 - PH_0)/PH_0)*100; %  response of PH
dPtime10_pmlcactot       = ((pathPtime10 - P_0)/P_0)*100; %  response of PN/PH
dLHStime10_pmlcactot     = ((pathLHStime10-omegaLH_0)/omegaLH_0)*(1-alphaL_0)*100; %  response of LH/L
dYHStime10_pmlcactot     = (pathYHStime10-omegaYH_0)*100; %  response of YH/Y
dkHKtime10_pmlcactot     = (LH_0*(pathdkHKtime10-kH_0)/K_0)*100;
dkNKtime10_pmlcactot     = (LN_0*(pathdkNKtime10-kN_0)/K_0)*100;
dLISHtime10_pmlcactot    = (pathLISHtime10-sLH_0)*100;
dLISNtime10_pmlcactot    = (pathLISNtime10-sLN_0)*100;
dWHWtime10_pmlcactot     = ((pathWHWtime0 - (WH_0/W_0))/(WH_0/W_0))*100; % response of WH/W
dWNWtime10_pmlcactot     = ((pathWNWtime0 - (WN_0/W_0))/(WN_0/W_0))*100; % response of WN/W

% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_pmlcactot       = (dlambda/lambda_0)*100; 
dCoverY_pmlcactot         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
hatZN_pmlcactot           = (dZN/ZN_0)*100; % Rate of change of the TFP in the non traded sector
hatZH_pmlcactot           = (dZH/ZH_0)*100; % Rate of change of the TFP in the traded sector
hatZ_pmlcactot            = (a*(dZH/ZH_0) - b*(dZN/ZN_0))*100; % Rate of change of the productivity differential
hatL_pmlcactot            = (dL/L_0)*100; % Rate of change of employment
hatK_pmlcactot            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLHoverL_pmlcactot        = (dLH/L_0)*100; % Rate of change of LH
dLNoverL_pmlcactot        = (dLN/L_0)*100; % Rate of change of LN
dLHLN_pmlcactot           =  dLHLN*100; %  Change of LH/LN
hatPH_pmlcactot           = (dPH/PH_0)*100; % Rate of change of PH
hatPN_pmlcactot           = (dPN/PN_0)*100; % Rate of change of PN
hatP_pmlcactot            = (dP/P_0)*100; % Rate of change of PN/PH
dBoverY_pmlcactot         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_pmlcactot         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_pmlcactot            = (dW/W_0)*100; % Rate of change of wage
hatWPC_pmlcactot          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_pmlcactot            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_pmlcactot           = ((YR_pmlcactot-Y_0)/Y_0)*100; % Rate of change of Real GDP
dYHoverY_pmlcactot        = (PH_0*dYH/Y_0)*100; % Rate of change of YH
dYNoverY_pmlcactot        = (PN_0*dYN/Y_0)*100; % Rate of change of YN
dYHYN_pmlcactot           = (dYHYN)*100; % Rate of change of YH/YN
hatWH_pmlcactot           = (dWH/WH_0)*100; % Rate of change of WH
hatWN_pmlcactot           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_pmlcactot        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWHPC_pmlcactot         = (dWHPC/WHPC_0)*100; % Rate of change of WH/PC
hatWNPC_pmlcactot         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkH_pmlcactot             = LH_0*(dkH/K_0)*100; % Rate of change of kH
dkN_pmlcactot             = LN_0*(dkN/K_0)*100; % Rate of change of kN
domegaLH_pmlcactot        = (omegaLH_pmlcactot-omegaLH_0)*100; % change in  the labor share of T
domegaLN_pmlcactot        = (omegaLN_pmlcactot-omegaLN_0)*100; % change in the labor share of NT
domegaYHS_pmlcactot       = (omegaYHR_pmlcactot-omegaYH_0)*100; % change in the output share of T
domegaYNS_pmlcactot       = (omegaYNR_pmlcactot-omegaYN_0)*100; % change in the output share of NT
dLISH_pmlcactot           = (sLH_pmlcactot-sLH_0)*100; % Change in the labor income share H
dLISN_pmlcactot           = (sLN_pmlcactot-sLN_0)*100; % Change in the labor income share N
dWHW_pmlcactot            = (((WH_pmlcactot/W_pmlcactot)-(WH_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage H
dWNW_pmlcactot            = (((WN_pmlcactot/W_pmlcactot)-(WN_0/W_0))/((WH_0/W_0)))*100; % Change in the relative wage N


disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kH > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaH  : %5.2f   thetaN   : %5.2f',thetaH,thetaN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('rho     : %5.2f   varphiH  : %5.2f ',rho,varphiH));
disp(sprintf('phiI    : %5.2f   iota     : %5.2f ',phiI,iota)); 
disp(sprintf('rhoI    : %5.2f   iotaH    : %5.2f ',rhoI,iotaH))
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZH      : %5.2f   ZN       : %5.2f',ZH,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GH      : %5.2f   GN       : %5.2f  GF      : %5.2f G      : %5.2f',GH,GN,GF,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kH       : %9.3f    kN   : %9.3f',kH,kN));
disp(sprintf('LH       : %9.3f    LN   : %9.3f',LH,LN));
disp(sprintf('KH       : %9.3f    KN   : %9.3f',KH,KN));
disp(sprintf('YH       : %9.3f    YN   : %9.3f',YH,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('CT       :   %7.3f  CT_check : %9.3f',CT,CT_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('PT       :   %7.3f    alphaH : %9.3f',PT,alphaH));
disp(sprintf('CH       :   %7.3f    CN     : %9.3f',CH,CN));
disp(sprintf('CF       :   %7.3f',CF));


disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('IT       :   %7.3f  IT_check : %9.3f',IT,IT_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('PIT      :   %7.3f   alphaIH : %9.3f',PIT,alphaIH));
disp(sprintf('IH       :   %7.3f    IN     : %9.3f IF     : %9.3f',IH,IN,IF));
disp(sprintf('EI       :   %7.3f    EIT    : %9.3f',EI,EIT));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector H');
disp(sprintf('Gross output (YH)  : %9.3f',YH));
disp(sprintf('WH                 : %9.3f',WH));
disp(sprintf('Profit             : %9.10f',PiH));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp('Linearization');
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_Q : %5.4f',Upsilon_K,Upsilon_Q));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_Q   : %5.4f',Sigma_K,Sigma_Q));
disp(sprintf('Sigma_ZH  :  %5.4f  Sigma_ZH  : %5.4f',Sigma_ZH,Sigma_ZH));
disp(sprintf('Sigma_ZN  :  %5.4f  Sigma_ZN  : %5.4f',Sigma_ZN,Sigma_ZN));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));
disp(sprintf('B_ZH      :  %5.4f  B_ZN      : %5.4f',B_ZH,B_ZN));
disp(sprintf('A_K       :  %5.4f  A_Q       : %5.4f',A_K,A_Q));
disp(sprintf('A_ZH      :  %5.4f  A_ZN      : %5.4f',A_ZH,A_ZN));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('nu3        :   %5.6f  nu4        : %5.6f',nu_3,nu_4));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));
disp(sprintf('TrJ1        :   %5.6f  DetJ1     : %5.6f',TrJ1,DetJ1));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega_21,omega_22));
disp(sprintf('omega13    :   %5.6f  omega14    : %5.6f',omega_13,omega_14));
disp(sprintf('omega23    :   %5.6f  omega24    : %5.6f',omega_23,omega_24));
disp(sprintf('omega31    :   %5.6f  omega32    : %5.6f',omega_31,omega_32));
disp(sprintf('omega41    :   %5.6f  omega42    : %5.6f',omega_41,omega_42));
disp(sprintf('omega33    :   %5.6f  omega34    : %5.6f',omega_33,omega_34));
disp(sprintf('omega43    :   %5.6f  omega44    : %5.6f',omega_43,omega_44));

disp('solutions at time t = 0 V10 X20');
disp(sprintf('V10       :   %5.3f  X20     : %5.3f VN0   : %5.3f',V10,VH0,VN0));
disp(sprintf('D1        :   %5.3f  D3      : %5.3f D4    : %5.3f',D1,D3,D4));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f      PN*YN / Y  : %5.3f',omegaYH,omegaYN));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('PN*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH,omegaGNYN,omegaGN));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f  GT/G       : %5.3f',omegaGH,omegaGF,omegaGT));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f  (r*B)/Y    : %5.3f',omegaINYN,omegaIHYH,omegaB));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH,omegaGFYH));
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL,alphaK));
disp(sprintf('PIT*IT/PI*I :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI,alphaC));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH,alphaH));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH,omegaCH));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF,omegaCF));
disp(sprintf('W*L/Y       :  %5.3f R*K/Y       :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y         :  %5.3f',omegaKY));
disp(' ');
disp(' ');
disp(sprintf('Marginal product of KH = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LH = WH       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good H  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Resource Constraint for Labor     : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond16));
disp(sprintf('Private Savings                   : %9.16f   ',cond17));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond18));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond19));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond20));
disp(sprintf('Capital income R*K                : %9.16f   ',cond21));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond22));
disp(sprintf('relative consumption  CH/CF       : %9.16f   ',cond23));
disp(sprintf('Consumption expenditure in T PT*CT: %9.16f   ',cond24));
disp(sprintf('relative investment   IH/IF       : %9.16f   ',cond25));
disp(sprintf('Investment expenditure in T PIT*JT: %9.16f   ',cond26));
disp(sprintf('Current account                   : %9.16f   ',cond27));
disp(sprintf('omega_13 - omega13                : %9.16f   ',cond28));
disp(sprintf('omega_14 - omega14                : %9.16f   ',cond29));
disp(sprintf('omega_23 - omega23                : %9.16f   ',cond30));
disp(sprintf('omega_24 - omega24                : %9.16f   ',cond31));
disp(sprintf('nu_3 + xiH                        : %9.16f   ',cond32));
disp(sprintf('nu_4 + xiN                        : %9.16f   ',cond33));



disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_pmlcactot        :         |           |%10.3f',hatlambda_pmlcactot));
disp(sprintf('dZoverZ_pmlcactot          :         |           |%10.3f',hatZ_pmlcactot));
disp(sprintf('dZHoverZH_pmlcactot        :         |           |%10.3f',hatZH_pmlcactot));
disp(sprintf('dZNoverZN_pmlcactot        :         |           |%10.3f',hatZN_pmlcactot));
disp(sprintf('dCoverY_pmlcactot          :         |           |%10.3f',dCoverY_pmlcactot));
disp(sprintf('dLoverL_pmlcactot          :         |           |%10.3f',hatL_pmlcactot));
disp(sprintf('dYoverY_pmlcactot          :         |           |%10.3f',hatY_pmlcactot));
disp(sprintf('dYRoverY_pmlcactot         :         |           |%10.3f',hatYR_pmlcactot));
disp(sprintf('dKoverK_pmlcactot          :         |           |%10.3f',hatK_pmlcactot));
disp(sprintf('dLHoverL_pmlcactot         :         |           |%10.3f',dLHoverL_pmlcactot));
disp(sprintf('dLNover_pmlcactot          :         |           |%10.3f',dLNoverL_pmlcactot));
disp(sprintf('dLHLN_pmlcactot            :         |           |%10.3f',dLHLN_pmlcactot));
disp(sprintf('dYHoverY_pmlcactot         :         |           |%10.3f',dYHoverY_pmlcactot));
disp(sprintf('dYNoverY_pmlcactot         :         |           |%10.3f',dYNoverY_pmlcactot));
disp(sprintf('dYHYN_pmlcactot            :         |           |%10.3f',dYHYN_pmlcactot));
disp(sprintf('hatPH_pmlcactot            :         |           |%10.3f',hatPH_pmlcactot));
disp(sprintf('hatPN_pmlcactot            :         |           |%10.3f',hatPN_pmlcactot));
disp(sprintf('hatP_pmlcactot             :         |           |%10.3f',hatP_pmlcactot));
disp(sprintf('dBoverY_pmlcactot          :         |           |%10.3f',dBoverY_pmlcactot));
disp(sprintf('dAoverY_pmlcactot          :         |           |%10.3f',dAoverY_pmlcactot));
disp(sprintf('dWoverW_pmlcactot          :         |           |%10.3f',hatW_pmlcactot));
disp(sprintf('dWPCoverWPC_pmlcactot      :         |           |%10.3f',hatWPC_pmlcactot));
disp(sprintf('dWHoverWH_pmlcactot        :         |           |%10.3f',hatWH_pmlcactot));
disp(sprintf('dWNoverWN_pmlcactot        :         |           |%10.3f',hatWN_pmlcactot));
disp(sprintf('hatOmega_pmlcactot         :         |           |%10.3f',hatOmega_pmlcactot));
disp(sprintf('dWHPCoverWHPC_pmlcactot    :         |           |%10.3f',hatWHPC_pmlcactot));
disp(sprintf('dWNPCoverWNPC_pmlcactot    :         |           |%10.3f',hatWNPC_pmlcactot));
disp(sprintf('dkHoverK_pmlcactot         :         |           |%10.3f',dkH_pmlcactot));
disp(sprintf('dkNoverK_pmlcactot         :         |           |%10.3f',dkN_pmlcactot));
disp(sprintf('domegaLH_pmlcactot         :         |           |%10.3f',domegaLH_pmlcactot));
disp(sprintf('domegaLN_pmlcactot         :         |           |%10.3f',domegaLN_pmlcactot));
disp(sprintf('domegaYHS_imlcac           :         |           |%10.3f',domegaYHS_pmlcactot));
disp(sprintf('domegaYNS_imlcac           :         |           |%10.3f',domegaYNS_pmlcactot));
disp(sprintf('dLISH_pmlcactot            :         |           |%10.3f',dLISH_pmlcactot));
disp(sprintf('dLISN_pmlcactot            :         |           |%10.3f',dLISN_pmlcactot));
disp(sprintf('dWHW_pmlcactot             :         |           |%10.3f',dWHW_pmlcactot));
disp(sprintf('dWNW_pmlcactot             :         |           |%10.3f',dWNW_pmlcactot));

%disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dZtime0_pmlcactot         :                |                 |%10.3f',dZtime0_pmlcactot));
disp(sprintf('dZHtime0_pmlcactot        :                |                 |%10.3f',dZHtime0_pmlcactot));
disp(sprintf('dZNtime0_pmlcactot        :                |                 |%10.3f',dZNtime0_pmlcactot));
disp(sprintf('dCYtime0_pmlcactot        :                |                 |%10.3f',dCYtime0_pmlcactot));
disp(sprintf('dLtime0_pmlcactot         :                |                 |%10.3f',dLtime0_pmlcactot));
disp(sprintf('dLHtime0_pmlcactot        :                |                 |%10.3f',dLHtime0_pmlcactot));
disp(sprintf('dLNtime0_pmlcactot        :                |                 |%10.3f',dLNtime0_pmlcactot));
disp(sprintf('dLHLNtime0_pmlcactot      :                |                 |%10.3f',dLHLNtime0_pmlcactot));
disp(sprintf('dYtime0_pmlcactot         :                |                 |%10.3f',dYtime0_pmlcactot));
disp(sprintf('dYRtime0_pmlcactot        :                |                 |%10.3f',dYRtime0_pmlcactot));
disp(sprintf('dYHtime0_pmlcactot        :                |                 |%10.3f',dYHtime0_pmlcactot));
disp(sprintf('dYNtime0_pmlcactot        :                |                 |%10.3f',dYNtime0_pmlcactot));
disp(sprintf('dYHYNtime0_pmlcactot      :                |                 |%10.3f',dYHYNtime0_pmlcactot));
disp(sprintf('dPHtime0_pmlcactot        :                |                 |%10.3f',dPHtime0_pmlcactot));
disp(sprintf('dPNtime0_pmlcactot        :                |                 |%10.3f',dPNtime0_pmlcactot));
disp(sprintf('dPtime0_pmlcactot         :                |                 |%10.3f',dPtime0_pmlcactot));
disp(sprintf('dSYtime0_pmlcactot        :                |                 |%10.3f',dSYtime0_pmlcactot));
disp(sprintf('dIYtime0_pmlcactot        :                |                 |%10.3f',dIYtime0_pmlcactot));
disp(sprintf('dCAYtime0_pmlcactot       :                |                 |%10.5f',dCAYtime0_pmlcactot)); 
disp(sprintf('dCAYtime0_pmlcactot_check :                |                 |%10.5f',dCAYtime0_pmlcactot_check)); 
disp(sprintf('dWtime0_pmlcactot         :                |                 |%10.3f',dWtime0_pmlcactot));
disp(sprintf('dWPCtime0_pmlcactot       :                |                 |%10.3f',dWPCtime0_pmlcactot));
disp(sprintf('dWHtime0_pmlcactot        :                |                 |%10.3f',dWHtime0_pmlcactot));
disp(sprintf('dWNtime0_pmlcactot        :                |                 |%10.3f',dWNtime0_pmlcactot));
disp(sprintf('dOmegatime0_pmlcactot     :                |                 |%10.3f',dOmegatime0_pmlcactot));
disp(sprintf('dWHPCtime0_pmlcactot      :                |                 |%10.3f',dWHPCtime0_pmlcactot));
disp(sprintf('dWNPCtime0_pmlcactot      :                |                 |%10.3f',dWNPCtime0_pmlcactot));
disp(sprintf('dWHPCtime0_pmlcactot      :                |                 |%10.3f',dWHPCtime0_pmlcactot));
disp(sprintf('dWNPCtime0_pmlcactot      :                |                 |%10.3f',dWNPCtime0_pmlcactot));
disp(sprintf('dkHKtime0_pmlcactot       :                |                 |%10.3f',dkHKtime0_pmlcactot));
disp(sprintf('dkNKtime0_pmlcactot       :                |                 |%10.3f',dkNKtime0_pmlcactot));
disp(sprintf('dLHStime0_pmlcactot       :                |                 |%10.3f',dLHStime0_pmlcactot));
disp(sprintf('dLNStime0_pmlcactot       :                |                 |%10.3f',dLNStime0_pmlcactot));
disp(sprintf('dYHStime0_pmlcactot       :                |                 |%10.3f',dYHStime0_pmlcactot));
disp(sprintf('dYNStime0_pmlcactot       :                |                 |%10.3f',dYNStime0_pmlcactot));
disp(sprintf('dWHWtime0_pmlcactot       :                |                 |%10.3f',dWHWtime0_pmlcactot));
disp(sprintf('dWNWtime0_pmlcactot       :                |                 |%10.3f',dWNWtime0_pmlcactot));
disp(sprintf('dLISHtime0_pmlcactot      :                |                 |%10.3f',dLISHtime0_pmlcactot));
disp(sprintf('dLISNtime0_pmlcactot      :                |                 |%10.3f',dLISNtime0_pmlcactot));


disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YH / Y    :  %5.3f     PN*YN / Y  : %5.3f',omegaYH_0,omegaYN_0));
disp(sprintf('LH / L    :  %5.3f      LN / L    : %5.3f',omegaLH_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('PI*I / Y  :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GH / YH     :  %5.3f  GN / YN    :  %5.3f  (PN*GN)/G  : %5.3f',omegaGHYH_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('(PH*GH)/G   :  %5.3f  GF / G     :  %5.3f    GT/G     : %5.3f',omegaGH_0,omegaGF_0,omegaGT_0));
disp(sprintf('IN / YN     :  %5.3f  IH / YH    :  %5.3f',omegaINYN_0,omegaIHYH_0));
disp(sprintf('IF / YH     :  %5.3f  GF / YH    :  %5.3f',omegaIFYH_0,omegaGFYH_0))
disp(sprintf('WN*LN/W*L   :  %5.3f RN*KN/R*K   :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('PT*IT/PI*I  :  %5.3f PT*CT/PC*C  :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('PH*IH/PT*IT :  %5.3f PH*CH/PT*CT :  %5.3f',alphaIH_0,alphaH_0));
disp(sprintf('PH*IH/PI*I  :  %5.3f PH*CH/PC*C  :  %5.3f',omegaIH_0,omegaCH_0));
disp(sprintf('IF/PI*I     :  %5.3f    CF/PC*C  :  %5.3f',omegaIF_0,omegaCF_0));
disp(sprintf('PH*XH/Y     :  %5.3f    XH / YH  :  %5.3f',omegaXHY_0,omegaXHYH_0));
disp(sprintf('W*L/PN*Y    :  %5.3f R*K/PN*Y    :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y         :  %5.3f (r*B)/Y     :  %5.3f',omegaKY_0,omegaB_0));

