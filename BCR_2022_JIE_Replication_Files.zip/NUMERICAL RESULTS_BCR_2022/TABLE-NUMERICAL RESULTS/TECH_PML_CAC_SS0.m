function g = TECH_PML_CAC_SS0(x)

global sigmaC phi varphi 
global gammaL sigmaL phiI varphiI
global r deltaK omegaG omegaGN
global ZT ZN thetaT thetaN kappa
global B0 K0 GT GN 
global xiT xiN barzT barzN gzT gzN aT aN

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    VARAIABLES of the MODEL                      %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LT      = x(6) ; % Labor in sector T
LN      = x(7) ; % Labor in sector N 
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
CN      = x(11) ; % Consumption in non tradables 
CT      = x(12) ; % Consumption in tradables 
PC      = x(13) ; % Consumption price index
alphaC  = x(14) ; % Non tradable share of consumption - alphaC
IN      = x(15) ; % Non tradable investment
IT      = x(16) ; % Tradable investment 
PI      = x(17) ; % Investment price index
alphaI  = x(18) ; % Non tradable share of investment 
PIprime = x(19) ; % Partial derivative of PI
GT      = x(20) ; % Government spending in tradables
GN      = x(21) ; % Government spending in non tradables 
YT      = x(22) ; % Output in sector T 
YN      = x(23) ; % Output in sector N 
CT_P    = x(24) ; % Partial derivative of CT=CT(P,lambda)
CN_P    = x(25) ; % Partial derivative of CN=CN(P,lambda)
lambda  = x(26) ; % Intertemporal Solvency Condition   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%                    STEADY STATE of the MODEL                    %%%%%%%%%%%
%%%%%%%%%%%                                                                 %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
% Aggregate Consumption -  C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors  - kT and
% kN
g(3)= ZT*(1-thetaT)*(kT^(-thetaT)) -  P*ZN*(1-thetaN)*(kN^(-thetaN));

% Wage rate in sector T  - kT and kN
g(4)= ZT*thetaT*(kT^(1-thetaT)) - P*ZN*thetaN*(kN^(1-thetaN));

% Aggregate wage index  - W
g(5)= W - ZT*thetaT*(kT^(1-thetaT));

% sectoral labor allocation  - LT and LN 
g(6)= (LT+LN) - L;

% sectoral capital allocation  -  LT and LN - 
g(7)= (LT*kT) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate  
g(8)= P*ZN*(1-thetaN)*(kN^(-thetaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - GN - IN;

% Traded good market clearing condition - B
g(10)= (r*B) + YT - CT - GT - IT;

% Consumption in non tradables - CN
g(11)= CN - C*(1-varphi)*(P/PC)^(-phi);

% Consumption in tradables - CT 
g(12)= CT - C*varphi*(1/PC)^(-phi);

% Consumption price index - PC
g(13)= PC - (varphi+(1-varphi)*P^(1-phi))^(1/(1-phi));

% Non tradable share of consumption - alphaC
g(14)= alphaC - (1-varphi)*(P/PC)^(1-phi);

% Non tradable Investment - IN
g(15)= IN - (alphaI*PI*(deltaK*K)/P);

% Tradable Investment - IT 
g(16)= IT - (1-alphaI)*PI*(deltaK*K);

% Investment price index - PI
g(17)= PI - (varphiI+(1-varphiI)*P^(1-phiI))^(1/(1-phiI));

% Non tradable share of investment - alphaI
g(18)= alphaI - (1-varphiI)*(P/PI)^(1-phiI);

% Partial derivative of Investment price index - PIprime
g(19)= PIprime - (1-varphiI)*(P/PI)^(-phiI);

% Total government spending - GT
g(20)= (GT+(P*GN)) - omegaG*(YT + (P*YN)); 

% Non tradable share of government spending 
g(21)= (P*GN) - omegaGN*(GT+(P*GN)); 

% Output per worker in the traded sector - YT
g(22)= YT - ZT*LT*(kT^(1-thetaT)); 

% Output per worker in the non traded sector - YN
g(23)= YN - ZN*LN*(kN^(1-thetaN));

% Partial CT/partial P - CT_P
g(24)= CT_P - alphaC*(CT/P)*(phi-sigmaC);

% Partial CN/partial P - CN_P
g(25)= CN_P + (CN/P)*(phi*(1-alphaC)+ (sigmaC*alphaC));

% Solutions for kj=kj(P,Zj)
d11 = -(thetaT/kT); 
d12 = (thetaN/kN);
d21 = (1-thetaT)/kT; 
d22 = -(1-thetaN)/kN;  

e11 = (1/P); 
e21 = (1/P); 

M = [d11 d12; d21 d22];
X = [e11; e21];
JST = inv(M);
MST = JST*X;
kT_P = MST(1,1); 
kN_P = MST(2,1); 

% Solution for W=W(P,ZT,ZN), L=L(lambda,P,ZT,ZN)
W_P       = (1-thetaT)*(W/kT)*kT_P; 
L_W      = sigmaL*(L/W);  
L_P      = L_W*W_P;

% Solutions for Lj=Lj(K,P)
KC_P  = ( (LT*kT_P) + (LN*kN_P) ); 

f11 = 1; 
f12 = 1;  
f21 = kT; 
f22 = kN;

g11 = 0; 
g12 = L_P;
g21 = 1; 
g22 = -KC_P; 

M = [f11 f12; f21 f22];
X = [g11 g12; g21 g22];
JST = inv(M);
MST = JST*X;
LT_K = MST(1,1); LT_P = MST(1,2);    
LN_K = MST(2,1); LN_P = MST(2,2); 

% Solutions for sectoral sectoral output Yj=Yj(K,P,ZT,ZN)
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YT_K = YT*(LT_K/LT); 
YN_K = YN*(LN_K/LN); 

% Investment function I/K = v(Q/PI(P))+delta_K
v_Q = 1/(kappa*PI); 
v_P = -alphaI/(kappa*P); 

% Solution for R as function R=R(K,P,ZT,ZN) 
RK  = PI*(r+deltaK); 
R_P = -(RK/kT)*thetaT*kT_P; 

% Solving for the relative price P=P(lambda,K,Q,ZT,ZN)
PsiP  = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime) - K*v_P; 
P_K   = -(1/PsiP)*( (YN_K/PIprime) - deltaK ); 
P_Q   = (K/PsiP)*v_Q; 

% Elements of the Jacobian Matrix 
Upsilon_K = ( (YN_K/PIprime) - deltaK);                                                                        
Upsilon_P = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime); 
Sigma_K   = 0; 
Sigma_P   = -(R_P + (PI*kappa*v_P*deltaK)); 
Sigma_Q   = (r+deltaK) - (PI*kappa*v_Q*deltaK); 
 
x11 = Upsilon_K + (Upsilon_P*P_K);                                                                         
x12 = (Upsilon_P*P_Q);                                                                                                                                                                                                                     
x21 = Sigma_K + (Sigma_P*P_K);                        
x22 = Sigma_Q + (Sigma_P*P_Q);    
                                                                      
J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
 
% Intertemporal solvency condition - lambda 
Xi_K  = (YT_K - ((1-alphaI)/alphaI)*P*YN_K); 
Xi_P  = ( (YT_P-CT_P) - ((1-alphaI)/alphaI)*P*(YN_P-CN_P) - phiI*((1-alphaI)/alphaI)*IN ); 
B_K   = (Xi_K + (Xi_P*P_K)); 
B_Q   = (Xi_P*P_Q); 
N1    = (B_K + (B_Q*omega_21));
H1    = N1/(nu_1-r); 
g(26) = (B - B0) - H1*(K-K0);


