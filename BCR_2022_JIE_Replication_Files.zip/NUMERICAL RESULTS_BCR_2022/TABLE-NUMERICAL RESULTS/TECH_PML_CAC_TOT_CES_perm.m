function g = TECH_PML_CAC_TOT_CES_perm(x)

global sigmaC phi varphi rho varphiH
global phiI iota rhoI iotaH 
global ex nuX
global gammaL sigmaL 
global r deltaK kappa
global omegaG omegaGN omegaGH GH GN GF
global BH BN AH AN gammaH gammaN sigmaH sigmaN
global B0 K0 
global xiAH xiBH xiAN xiBN barzH barzN gzH gzN aAH aBH aAN aBN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kH      = x(3)  ; % Capital-labor ratio in sector H
kN      = x(4)  ; % Capital-labor ratio in sector N
W       = x(5)  ; % Aggregate wage index
LH      = x(6) ; % Labor in sector H
LN      = x(7) ; % Labor in sector N 
PN      = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
PH      = x(10) ; % Terms of trade : PH/PF with PF = numeraire
B       = x(11) ; % Stock of Traded Bonds
PC      = x(12) ; % Aggregate consumption price index
PT      = x(13) ; % Consumption price index for tradables
CN      = x(14) ; % Consumption in non tradables 
CH      = x(15) ; % Consumption in tradables 
CF      = x(16) ; % Consumption goods imports
PI      = x(17) ; % Aggregate investment price index
PIT     = x(18) ; % Investment price index for tradables
IN      = x(19) ; % Non tradable investment
IH      = x(20) ; % Investment in home goods
IF      = x(21) ; % Investment in foreign goods
yH      = x(22) ; % Output of home traded goods per worker
YH      = x(23) ; % Output of home traded goods
yN      = x(24) ; % Output of non traded goods per worker
YN      = x(25) ; % Output of non traded goods
XH      = x(26) ; % Exports of home traded goods
MF      = x(27) ; % Imports of foreign goods
lambda  = x(28) ; % Marginal utility of wealth lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Aggregate Consumption - C
g(1)= (C^(-1/sigmaC)) - (PC*lambda);

% Aggregate labor supply - L
g(2)= gammaL*(L^(1/sigmaL)) - (lambda*W);

% equality of marginal product of capital across the two sectors - kH and
% kN
g(3)= PH*(1-gammaH)*(BH^((sigmaH-1)/sigmaH))*((yH/kH)^(1/sigmaH)) - PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((yN/kN)^(1/sigmaN)); 

% Wage rate in sector H - kH and kN
g(4)= PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH)) - PN*gammaN*(AN^((sigmaN-1)/sigmaN))*(yN^(1/sigmaN));

%  Aggregate wage index - W
g(5)= PH*gammaH*(AH^((sigmaH-1)/sigmaH))*(yH^(1/sigmaH)) - W;

% sectoral labor allocation  - LH and LN 
g(6)= (LH+LN) - L;

% sectoral capital allocation - LH and LN - 
g(7)= (LH*kH) + (LN*kN) - K;

% equality of marginal product of capital in the non traded sector to the world interest rate - PN 
g(8)= PN*(1-gammaN)*(BN^((sigmaN-1)/sigmaN))*((yN/kN)^(1/sigmaN)) - (deltaK + r)*PI;

% Non traded market good market clearing condition - K 
g(9)= YN - CN - IN - GN;

% Homme good market clearing condition - PH
g(10)= YH - CH - IH - GH - XH;

% Traded good market clearing condition - B
g(11)= (r*B) + (PH*XH) - MF;

% Consumption price index - PC=PC(PT,PN)
g(12)= PC - (varphi*(PT^(1-phi))+(1-varphi)*(PN^(1-phi)))^(1/(1-phi));

% Consumption price index for tradables - PT=PT(PH)
g(13)= PT - (varphiH*(PH^(1-rho))+(1-varphiH))^(1/(1-rho));

% Consumption in non tradables - CN
g(14)= CN - C*(1-varphi)*((PN/PC)^(-phi));

% Consumption in home goods - CH
g(15)= CH - C*varphi*((PT/PC)^(-phi))*varphiH*((PH/PT)^(-rho));

% Consumption in foreign goods - CF
g(16)= CF - C*varphi*((PT/PC)^(-phi))*(1-varphiH)*((1/PT)^(-rho));

% Investment price index - PI=PI(PT,PN)
g(17)= PI - (iota*(PIT^(1-phiI))+(1-iota)*(PN^(1-phiI)))^(1/(1-phiI));

% Investment price index for tradables - PIT=PIT(PH)
g(18)= PIT - (iotaH*(PH^(1-rhoI))+(1-iotaH))^(1/(1-rhoI));

% Investment in non tradables - IN
g(19)= IN - (deltaK*K)*(1-iota)*((PN/PI)^(-phiI));

% Investment in home goods - IH
g(20)= IH - (deltaK*K)*iota*((PIT/PI)^(-phiI))*iotaH*((PH/PIT)^(-rhoI));

% Investment in foreign goods - IF
g(21)= IF - (deltaK*K)*iota*((PIT/PI)^(-phiI))*(1-iotaH)*((1/PIT)^(-rhoI));

% Output in the home good sector - YH
% Output per worker in the home traded sector - kH,yH - and Labor
% income share in sector H, sLH
g(22)= yH - ( gammaH*(AH^((sigmaH-1)/sigmaH)) + (1-gammaH)*((BH*kH)^((sigmaH-1)/sigmaH)) )^(sigmaH/(sigmaH-1));  
g(23)= YH  - (LH*yH); 

% Output per worker in the non traded sector - kN,yN - and Labor
% income share in sector N, sLN
g(24)= yN  - ( gammaN*(AN)^((sigmaN-1)/sigmaN) + (1-gammaN)*((BN*kN)^((sigmaN-1)/sigmaN)) )^(sigmaN/(sigmaN-1)); 
g(25)= YN  - (LN*yN); 

% Export of home goods - XH
g(26)= XH - ex*(PH)^(-nuX);

% Import of foreign goods - MF
g(27)= MF - (CF+IF+GF);

% Non tradable shares of consumption, investment, labor compensation, labor
% income share
I       = deltaK*K;
alphaC  = varphi*(PT/PC)^(1-phi);
alphaH  = varphiH*(PH/PT)^(1-rho);
alphaI  = iota*(PIT/PI)^(1-phiI);
alphaIH = iotaH*(PH/PIT)^(1-rhoI);
sLH     = gammaH*(AH/yH)^((sigmaH-1)/sigmaH);
sLN     = gammaN*(AN/yN)^((sigmaN-1)/sigmaN);

% Intermediate solution for CN, CH, CF - Cj=Cj(lambda,PN,PH)
CN_PN = - (CN/PN)*( (alphaC*phi) + sigmaC*(1-alphaC) ); 
CN_PH = (CN/PH)*alphaC*alphaH*(phi-sigmaC); 
CH_PN = (CH/PN)*(phi-sigmaC)*(1-alphaC); 
CH_PH = -(CH/PH)*( rho*(1-alphaH) + alphaH*( phi*(1-alphaC) + (sigmaC*alphaC) ) ); 
CF_PN = (CF/PN)*(1-alphaC)*(phi-sigmaC); 
CF_PH = (CF/PH)*alphaH*(rho - (phi*(1-alphaC)+(sigmaC*alphaC))); 

% Intermediate solutions for kj=kj(PN,PH,Aj,Bj)
d11 = -(1/sigmaH)*(sLH/kH); 
d12 = (1/sigmaN)*(sLN/kN);
d21 = (1/sigmaH)*((1-sLH)/kH); 
d22 = -(1/sigmaN)*((1-sLN)/kN);
                                                          
e11 = (1/PN); 
e12 = -(1/PH);
e13 = -(1/sigmaH)*(sLH/AH); 
e14 = -(1/sigmaH)*((sigmaH-sLH)/BH);
e15 = (1/sigmaN)*(sLN/AN); 
e16 = (1/sigmaN)*((sigmaN-sLN)/BN);
e21 = (1/PN); 
e22 = -(1/PH);
e23 = -(1/sigmaH)*(((sigmaH-1)+sLH)/AH); 
e24 = -(1/sigmaH)*((1-sLH)/BH); 
e25 = (1/sigmaN)*(((sigmaN-1)+sLN)/AN); 
e26 = (1/sigmaN)*((1-sLN)/BN); 
                                                                                                                                                                               
M = [d11 d12; d21 d22];                     
X = [e11 e12 e13 e14 e15 e16; e21 e22 e23 e24 e25 e26];     
JST = inv(M);                                                                                 
MST = JST*X;                                                                                  
kH_PN = MST(1,1); kH_PH = MST(1,2); kH_1AH = MST(1,3); kH_1BH = MST(1,4); kH_1AN = MST(1,5); kH_1BN = MST(1,6);     
kN_PN = MST(2,1); kN_PH = MST(2,2); kN_1AH = MST(2,3); kN_1BH = MST(2,4); kN_1AN = MST(2,5); kN_1BN = MST(2,6);   

% Solution for W=W(PH,PN,AH,BH,AN,BN), L=L(lambda,W)
W_PH     = (W/PH) + (W/sigmaH)*((1-sLH)/kH)*kH_PH; 
W_PN     = (W/sigmaH)*((1-sLH)/kH)*kH_PN; 
W_1AH    = (W/sigmaH)*( (((sigmaH-1)+sLH)/AH)  + ((1-sLH)/kH)*kH_1AH ); 
W_1BH    = (W/sigmaH)*(1-sLH)*( (1/BH) + (kH_1BH/kH) ); 
W_1AN    = (W/sigmaH)*((1-sLH)/kH)*kH_1AN; 
W_1BN    = (W/sigmaH)*((1-sLH)/kH)*kH_1BN; 
L_W      = sigmaL*(L/W); 
L_PN     = L_W*W_PN;
L_PH     = L_W*W_PH;
L_1AH    = L_W*W_1AH;
L_1BH    = L_W*W_1BH;
L_1AN    = L_W*W_1AN;
L_1BN    = L_W*W_1BN;

% Solutions for Lj=Lj(K,PH,PN,AH,BH,AN,BN)
KC_PN  = ( (LH*kH_PN) + (LN*kN_PN) ); 
KC_PH  = ( (LH*kH_PH) + (LN*kN_PH) );
KC_AH  = ( (LH*kH_1AH) + (LN*kN_1AH) ); 
KC_BH  = ( (LH*kH_1BH) + (LN*kN_1BH) ); 
KC_AN  = ( (LH*kH_1AN) + (LN*kN_1AN) );
KC_BN  = ( (LH*kH_1BN) + (LN*kN_1BN) );

f11 = 1; 
f12 = 1;  
f21 = kH; 
f22 = kN;

g11 = 0; 
g12 = L_PN;
g13 = L_PH;
g14 = L_1AH;
g15 = L_1BH;
g16 = L_1AN;
g17 = L_1BN;
g21 = 1; 
g22 = -KC_PN; 
g23 = -KC_PH;
g24 = -KC_AH; 
g25 = -KC_BH; 
g26 = -KC_AN; 
g27 = -KC_BN;

M = [f11 f12; f21 f22];
X = [g11 g12 g13 g14 g15 g16 g17; g21 g22 g23 g24 g25 g26 g27];
JST = inv(M);
MST = JST*X;
LH_1K = MST(1,1); LH_PN = MST(1,2); LH_PH = MST(1,3); LH_1AH = MST(1,4); LH_1BH = MST(1,5); LH_1AN = MST(1,6); LH_1BN = MST(1,7);
LN_1K = MST(2,1); LN_PN = MST(2,2); LN_PH = MST(2,3); LN_1AH = MST(2,4); LN_1BH = MST(2,5); LN_1AN = MST(2,6); LN_1BN = MST(2,7);

% Intermediate solutions for sectoral output - Yj=Yj(PN,PH,K,AH,BH,AN,BN)
yH_PN  = (yH/kH)*(1-sLH)*kH_PN;   
yN_PN  = (yN/kN)*(1-sLN)*kN_PN;
yH_PH  = (yH/kH)*(1-sLH)*kH_PH;   
yN_PH  = (yN/kN)*(1-sLN)*kN_PH;   
yH_1AH = (yH/AH)*sLH + (yH/kH)*(1-sLH)*kH_1AH;   
yN_1AH = (yN/kN)*(1-sLN)*kN_1AH;
yH_1BH =  yH*(1-sLH)*( (1/BH) + (kH_1BH/kH) );   
yN_1BH = (yN/kN)*(1-sLN)*kN_1BH;
yH_1AN =  (yH/kH)*(1-sLH)*kH_1AN;   
yN_1AN = (yN/AN)*sLN + (yN/kN)*(1-sLN)*kN_1AN;
yH_1BN =  (yH/kH)*(1-sLH)*kH_1BN;   
yN_1BN =  yN*(1-sLN)*( (1/BN) + (kN_1BN/kN) );

YH_PN = (LH*yH_PN) + (yH*LH_PN);
YN_PN = (LN*yN_PN) + (yN*LN_PN);
YH_PH = (LH*yH_PH) + (yH*LH_PH);
YN_PH = (LN*yN_PH) + (yN*LN_PH);
YH_1K = (yH*LH_1K);
YN_1K = (yN*LN_1K); 
YH_1AH = (LH*yH_1AH) + (yH*LH_1AH);
YN_1AH = (LN*yN_1AH) + (yN*LN_1AH);
YH_1BH = (LH*yH_1BH) + (yH*LH_1BH);
YN_1BH = (LN*yN_1BH) + (yN*LN_1BH);
YH_1AN = (LH*yH_1AN) + (yH*LH_1AN);
YN_1AN = (LN*yN_1AN) + (yN*LN_1AN);
YH_1BN = (LH*yH_1BN) + (yH*LH_1BN);
YN_1BN = (LN*yN_1BN) + (yN*LN_1BN);

% Investment function I/K = v(Q/PI(PN,PH))+delta_K - intermediate solution
v_1Q = 1/(kappa*PI); 
v_PN = - (1-alphaI)/(kappa*PN); 
v_PH = -(alphaI*alphaIH)/(kappa*PH); 

% Solution for J = J(K,Q,PN,PH)
J_K  = deltaK; 
J_Q  = K*v_1Q; 
J_PN = K*v_PN; 
J_PH = K*v_PH; 

% Solution for JN, JH, JF - Jj=Jj(PN,PH,K,Q) 
JN_PN  = -(IN/PN)*(phiI*alphaI) + (IN/I)*J_PN; 
JN_PH  = (IN/PH)*(phiI*alphaI*alphaIH) + (IN/I)*J_PH; 
JN_1K  = (IN/I)*J_K; 
JN_1Q  = (IN/I)*J_Q; 

JH_PN  =  (IH/PN)*phiI*(1-alphaI) + (IH/I)*J_PN; 
JH_PH  = -(IH/PH)*( rhoI*(1-alphaIH) + phiI*alphaIH*(1-alphaI) ) + (IH/I)*J_PH; 
JH_1K  = (IH/I)*J_K; 
JH_1Q  = (IH/I)*J_Q; 

JF_PN  = (IF/PN)*phiI*(1-alphaI) + (IF/I)*J_PN; 
JF_PH  = (IF/PH)*alphaIH*( rhoI - phiI*(1-alphaI) ) + (IF/I)*J_PH; 
JF_1K  = (IF/I)*J_K; 
JF_1Q  = (IF/I)*J_Q; 

% Solution for export of home goods - XH = XH(PH)
XH_PH  = -(XH/PH)*nuX; 

% Solving for the price of home goods PH=PH(lambda,K,Q,AH,BH,AN,BN,PN) -
% Intermediate Solution
PsiH_PH    = (YH_PH - CH_PH - JH_PH - XH_PH);
PsiH_PN    = (YH_PN - CH_PN - JH_PN);
PH_PN      = -PsiH_PN/PsiH_PH; 
PH_1K      = -(YH_1K - JH_1K)/PsiH_PH; 
PH_1Q      = JH_1Q/PsiH_PH; 
PH_1AH     = -YH_1AH/PsiH_PH; 
PH_1BH     = -YH_1BH/PsiH_PH;
PH_1AN     = -YH_1AN/PsiH_PH; 
PH_1BN     = -YH_1BN/PsiH_PH;  

% Solving for the price of non tradables PN=PN(lambda,K,Q,AH,BH,AN,BN)
PsiN_PH   = (YN_PH - CN_PH - JN_PH); 
PsiN_PN   = (YN_PN - CN_PN - JN_PN) + (PsiN_PH*PH_PN);
PN_K      = -( (YN_1K - JN_1K) + (PsiN_PH*PH_1K) )/PsiN_PN; 
PN_Q      =  ( JN_1Q - (PsiN_PH*PH_1Q) )/PsiN_PN; 
PN_AH     = -( YN_1AH + (PsiN_PH*PH_1AH) )/PsiN_PN; 
PN_BH     = -( YN_1BH + (PsiN_PH*PH_1BH) )/PsiN_PN; 
PN_AN     = -( YN_1AN + (PsiN_PH*PH_1AN) )/PsiN_PN;
PN_BN     = -( YN_1BN + (PsiN_PH*PH_1BN) )/PsiN_PN;

% Solving for the price of home goods PH=PH(lambda,K,Q,Aj,Bj) - Final
% Solution
PH_K     = PH_1K + (PH_PN*PN_K); 
PH_Q     = PH_1Q + (PH_PN*PN_Q);
PH_AH    = PH_1AH + (PH_PN*PN_AH);  
PH_BH    = PH_1BH + (PH_PN*PN_BH);  
PH_AN    = PH_1AN + (PH_PN*PN_AN);  
PH_BN    = PH_1BN + (PH_PN*PN_BN);   

% Solving for capital-labor ratios kj=kj(lambda,K,Q,AH,BH,AN,BN) - 
% sectoral labor Lj=Lj(lambda,K,Q,AH,BH,AN,BN) - sectoral output 
% Yj=Yj(lambda,K,Q,AH,BH,AN,BN) - Final Solutions
kH_K = (kH_PH*PH_K) + (kH_PN*PN_K); 
kH_Q = (kH_PH*PH_Q) + (kH_PN*PN_Q); 
kN_K = (kN_PH*PH_K) + (kN_PN*PN_K);
kN_Q = (kN_PH*PH_Q) + (kN_PN*PN_Q); 
kH_AH = kH_1AH + (kH_PH*PH_AH) + (kH_PN*PN_AH);
kH_BH = kH_1BH + (kH_PH*PH_BH) + (kH_PN*PN_BH);
kH_AN = kH_1AN + (kH_PH*PH_AN) + (kH_PN*PN_AN);
kH_BN = kH_1BN + (kH_PH*PH_BN) + (kH_PN*PN_BN);
kN_AH = kN_1AH + (kN_PH*PH_AH) + (kN_PN*PN_AH);
kN_BH = kN_1BH + (kN_PH*PH_BH) + (kN_PN*PN_BH);
kN_AN = kN_1AN + (kN_PH*PH_AN) + (kN_PN*PN_AN); 
kN_BN = kN_1BN + (kN_PH*PH_BN) + (kN_PN*PN_BN);

LH_K = LH_1K + (LH_PH*PH_K) + (LH_PN*PN_K); 
LH_Q = (LH_PH*PH_Q) + (LH_PN*PN_Q); 
LN_K = LN_1K + (LN_PH*PH_K) + (LN_PN*PN_K);
LN_Q = (LN_PH*PH_Q) + (LN_PN*PN_Q);
LH_AH = LH_1AH + (LH_PH*PH_AH) + (LH_PN*PN_AH); 
LH_BH = LH_1BH + (LH_PH*PH_BH) + (LH_PN*PN_BH);
LH_AN = LH_1AN + (LH_PH*PH_AN) + (LH_PN*PN_AN); 
LH_BN = LH_1BN + (LH_PH*PH_BN) + (LH_PN*PN_BN);
LN_AH = LN_1AH + (LN_PH*PH_AH) + (LN_PN*PN_AH); 
LN_BH = LN_1BH + (LN_PH*PH_BH) + (LN_PN*PN_BH);
LN_AN = LN_1AN + (LN_PH*PH_AN) + (LN_PN*PN_AN); 
LN_BN = LN_1BN + (LN_PH*PH_BN) + (LN_PN*PN_BN);

YH_K = YH_1K + (YH_PH*PH_K) + (YH_PN*PN_K); 
YH_Q = (YH_PH*PH_Q) + (YH_PN*PN_Q); 
YN_K = YN_1K + (YN_PH*PH_K) + (YN_PN*PN_K);
YN_Q = (YN_PH*PH_Q) + (YN_PN*PN_Q);

YH_AH = YH_1AH + (YH_PH*PH_AH) + (YH_PN*PN_AH);
YH_BH = YH_1BH + (YH_PH*PH_BH) + (YH_PN*PN_BH);
YH_AN = YH_1AN + (YH_PH*PH_AN) + (YH_PN*PN_AN);
YH_BN = YH_1BN + (YH_PH*PH_BN) + (YH_PN*PN_BN);
YN_AH = YN_1AH + (YN_PH*PH_AH) + (YN_PN*PN_AH);
YN_BH = YN_1BH + (YN_PH*PH_BH) + (YN_PN*PN_BH);
YN_AN = YN_1AN + (YN_PH*PH_AN) + (YN_PN*PN_AN);
YN_BN = YN_1BN + (YN_PH*PH_BN) + (YN_PN*PN_BN);

% Solving for consumption Cj=Cj(lambda,K,Q,AH,BH,AN,BN), investment inputs 
% Jj=Jj(K,Q,AH,BH,AN,BN), imports MF=MF(lambda,K,Q,AH,BH,AN,BN), exports 
%XH=XH(lambda,K,Q,AH,BH,AN,BN)- Final Solutions
CH_K      = (CH_PH*PH_K) + (CH_PN*PN_K); 
CH_Q      = (CH_PH*PH_Q) + (CH_PN*PN_Q); 
CH_AH     = (CH_PH*PH_AH) + (CH_PN*PN_AH);
CH_BH     = (CH_PH*PH_BH) + (CH_PN*PN_BH);
CH_AN     = (CH_PH*PH_AN) + (CH_PN*PN_AN);
CH_BN     = (CH_PH*PH_BN) + (CH_PN*PN_BN);

CN_K      = (CN_PH*PH_K) + (CN_PN*PN_K); 
CN_Q      = (CN_PH*PH_Q) + (CN_PN*PN_Q); 
CN_AH     = (CN_PH*PH_AH) + (CN_PN*PN_AH);
CN_BH     = (CN_PH*PH_BH) + (CN_PN*PN_BH);
CN_AN     = (CN_PH*PH_AN) + (CN_PN*PN_AN);   
CN_BN     = (CN_PH*PH_BN) + (CN_PN*PN_BN);                       

CF_K      = (CF_PH*PH_K) + (CF_PN*PN_K); 
CF_Q      = (CF_PH*PH_Q) + (CF_PN*PN_Q); 
CF_AH     = (CF_PH*PH_AH) + (CF_PN*PN_AH);
CF_BH     = (CF_PH*PH_BH) + (CF_PN*PN_BH);
CF_AN     = (CF_PH*PH_AN) + (CF_PN*PN_AN); 
CF_BN     = (CF_PH*PH_BN) + (CF_PN*PN_BN);                       
 
JH_K       = JH_1K + (JH_PH*PH_K) + (JH_PN*PN_K); 
JH_Q       = JH_1Q + (JH_PH*PH_Q) + (JH_PN*PN_Q);
JH_AH      = (JH_PH*PH_AH) + (JH_PN*PN_AH);
JH_BH      = (JH_PH*PH_BH) + (JH_PN*PN_BH);
JH_AN      = (JH_PH*PH_AN) + (JH_PN*PN_AN);
JH_BN      = (JH_PH*PH_BN) + (JH_PN*PN_BN);

JN_K       = JN_1K + (JN_PH*PH_K) + (JN_PN*PN_K); 
JN_Q       = JN_1Q + (JN_PH*PH_Q) + (JN_PN*PN_Q); 
JN_AH      = (JN_PH*PH_AH) + (JN_PN*PN_AH); 
JN_BH      = (JN_PH*PH_BH) + (JN_PN*PN_BH);
JN_AN      = (JN_PH*PH_AN) + (JN_PN*PN_AN);   
JN_BN      = (JN_PH*PH_BN) + (JN_PN*PN_BN);         

JF_K       = JF_1K + (JF_PH*PH_K) + (JF_PN*PN_K); 
JF_Q       = JF_1Q + (JF_PH*PH_Q) + (JF_PN*PN_Q); 
JF_AH      = (JF_PH*PH_AH) + (JF_PN*PN_AH);   
JF_BH      = (JF_PH*PH_BH) + (JF_PN*PN_BH);
JF_AN      = (JF_PH*PH_AN) + (JF_PN*PN_AN);   
JF_BN      = (JF_PH*PH_BN) + (JF_PN*PN_BN);        

XH_K      = XH_PH*PH_K; 
XH_Q      = XH_PH*PH_Q; 
XH_AH     = XH_PH*PH_AH;
XH_BH     = XH_PH*PH_BH;
XH_AN     = XH_PH*PH_AN;
XH_BN     = XH_PH*PH_BN;

MF_K      = (CF_K + JF_K); 
MF_Q      = (CF_Q + JF_Q); 
MF_AH     = (CF_AH + JF_AH);
MF_BH     = (CF_BH + JF_BH);
MF_AN     = (CF_AN + JF_AN); 
MF_BN     = (CF_BN + JF_BN);

% Marginal revenue of capital R = PN*partial YN/partial KN
RK   = PI*(r+deltaK); 
R_K  = (RK/PN)*PN_K - (RK/kN)*(sLN/sigmaN)*kN_K; 
R_Q  = (RK/PN)*PN_Q - (RK/kN)*(sLN/sigmaN)*kN_Q;  
R_AH = (RK/PN)*PN_AH - (RK/kN)*(sLN/sigmaN)*kN_AH;  
R_BH = (RK/PN)*PN_BH - (RK/kN)*(sLN/sigmaN)*kN_BH;
R_AN = (RK/AN)*(sLN/sigmaN) + (RK/PN)*PN_AN - (RK/kN)*(sLN/sigmaN)*kN_AN;
R_BN = (RK/BN)*((sigmaN-sLN)/sigmaN) + (RK/PN)*PN_BN - (RK/kN)*(sLN/sigmaN)*kN_BN;

% Solving for investment function I/K = v(Q/PI)+delta_K - 
% v=v(lambda,K,Q,AH,BH,AN,BN) final solution
v_Q  = v_1Q + (v_PN*PN_Q) + (v_PH*PH_Q); 
v_K  = (v_PN*PN_K) + (v_PH*PH_K); 
v_AH = (v_PN*PN_AH) + (v_PH*PH_AH); 
v_BH = (v_PN*PN_BH) + (v_PH*PH_BH); 
v_AN = (v_PN*PN_AN) + (v_PH*PH_AN);
v_BN = (v_PN*PN_BN) + (v_PH*PH_BN);

% Eigenvalues and Eigenvectors 
Upsilon_K  = (I/IN)*(YN_K-CN_K) - deltaK + (alphaI*phiI*I)*( (PN_K/PN) - (alphaIH/PH)*PH_K );                                                                        
Upsilon_Q  = (I/IN)*(YN_Q-CN_Q) + (alphaI*phiI*I)*( (PN_Q/PN) - (alphaIH/PH)*PH_Q );
Upsilon_AH = (I/IN)*(YN_AH-CN_AH) + (alphaI*phiI*I)*( (PN_AH/PN) - (alphaIH/PH)*PH_AH );
Upsilon_BH = (I/IN)*(YN_BH-CN_BH) + (alphaI*phiI*I)*( (PN_BH/PN) - (alphaIH/PH)*PH_BH );
Upsilon_AN = (I/IN)*(YN_AN-CN_AN) + (alphaI*phiI*I)*( (PN_AN/PN) - (alphaIH/PH)*PH_AN );
Upsilon_BN = (I/IN)*(YN_BN-CN_BN) + (alphaI*phiI*I)*( (PN_BN/PN) - (alphaIH/PH)*PH_BN );
Sigma_K    = -( R_K + (PI*kappa*v_K*deltaK) ); 
Sigma_Q    = (r+deltaK) - ( R_Q + (PI*kappa*v_Q*deltaK) ); 
Sigma_AH   = -( R_AH + (PI*kappa*v_AH*deltaK) ); 
Sigma_BH   = -( R_BH + (PI*kappa*v_BH*deltaK) ); 
Sigma_AN   = -( R_AN + (PI*kappa*v_AN*deltaK) ); 
Sigma_BN   = -( R_BN + (PI*kappa*v_BN*deltaK) );

x11   = Upsilon_K;                                                                         
x12   = Upsilon_Q;     
x13   = Upsilon_AH; 
x14   = Upsilon_BH;
x15   = Upsilon_AN; 
x16   = Upsilon_BN;
x21   = Sigma_K;                        
x22   = Sigma_Q;
x23   = Sigma_AH; 
x24   = Sigma_BH;
x25   = Sigma_AN; 
x26   = Sigma_BN;
x31   = 0; 
x32   = 0; 
x33   = -xiAH; 
x34   = 0; 
x35   = 0; 
x36   = 0; 
x41   = 0; 
x42   = 0; 
x43   = 0; 
x44   = -xiBH;    
x45   = 0; 
x46   = 0; 
x51   = 0; 
x52   = 0; 
x53   = 0; 
x54   = 0;    
x55   = -xiAN; 
x56   = 0; 
x61   = 0; 
x62   = 0; 
x63   = 0; 
x64   = 0;    
x65   = 0; 
x66   = -xiBN;

J = [x11 x12; x21 x22];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[mu order] = sort(diag(mu),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu_1 = nu_sorted(1,1); 
nu_2 = nu_sorted(2,2); 
omega_11 = V_sorted(1,1)/V_sorted(1,1); 
omega_21 = V_sorted(2,1)/V_sorted(1,1); 
omega_12 = V_sorted(1,2)/V_sorted(1,2); 
omega_22 = V_sorted(2,2)/V_sorted(1,2); 

% Solutions
omega_13 = -( x13*(x22+xiAH) - (x12*x23) )/( (nu_1+xiAH)*(nu_2+xiAH) ); 
omega_14 = -( x14*(x22+xiBH) - (x12*x24) )/( (nu_1+xiBH)*(nu_2+xiBH) );
omega_15 = -( x15*(x22+xiAN) - (x12*x25) )/( (nu_1+xiAN)*(nu_2+xiAN) );
omega_16 = -( x16*(x22+xiBN) - (x12*x26) )/( (nu_1+xiBN)*(nu_2+xiBN) );

omega_23 = ( (x13*x21) - (x11+xiAH)*x23 )/( (nu_1+xiAH)*(nu_2+xiAH) );
omega_24 = ( (x14*x21) - (x11+xiBH)*x24 )/( (nu_1+xiBH)*(nu_2+xiBH) );
omega_25 = ( (x15*x21) - (x11+xiAN)*x25 )/( (nu_1+xiAN)*(nu_2+xiAN) );
omega_26 = ( (x16*x21) - (x11+xiBN)*x26 )/( (nu_1+xiBN)*(nu_2+xiBN) );

D3 = aAH; 
D4 = aBH; 
D5 = aAN; 
D6 = aBN;
D1 = (K0 - K) - (omega_13*D3) - (omega_14*D4) - (omega_15*D5) - (omega_16*D6); 

% Intertemporal solvency condition - lambda 
B_K          = (PH_K*XH) + (PH*XH_K) - MF_K; 
B_Q          = (PH_Q*XH) + (PH*XH_Q) - MF_Q;
B_AH         = (PH_AH*XH) + (PH*XH_AH) - MF_AH; 
B_BH         = (PH_BH*XH) + (PH*XH_BH) - MF_BH; 
B_AN         = (PH_AN*XH) + (PH*XH_AN) - MF_AN;
B_BN         = (PH_BN*XH) + (PH*XH_BN) - MF_BN;
N1           = (B_K + (B_Q*omega_21)); 
N2           = ((B_K*omega_13) + (B_Q*omega_23) + B_AH); 
N3           = ((B_K*omega_14) + (B_Q*omega_24) + B_BH); 
N4           = ((B_K*omega_15) + (B_Q*omega_25) + B_AN); 
N5           = ((B_K*omega_16) + (B_Q*omega_26) + B_BN); 
wB1          = N1/(r-nu_1); 
wBAH         = N2/(r+xiAH); 
wBBH         = N3/(r+xiBH);
wBAN         = N4/(r+xiAN);
wBBN         = N5/(r+xiBN);
g(28) = (B - B0) - (wB1*D1) - (wBAH*aAH) - (wBBH*aBH) - (wBAN*aAN) - (wBBN*aBN);


