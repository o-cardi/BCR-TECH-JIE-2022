clc
clear

% Maximum duration for graphics
Tg = 10;
       
% Minimum duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

IML_CAC; 
IML_CAC_TOT_CES_BIAS_NORM; 
%%%%%%%%%%% Impulse functions %%%%%%%%%% 

%%%%% PVARMODEL10
[xdata10, ~, ~]=xlsread('TECH-Z-ZT-ZN-RESCALED.xlsx'); scaling=[1 1 1 1];                                                     
namvar=char('EPSILONZ1','DLZT','DLZN','DLRZ4'); nbPVAR  = 10; %chartbounds = [-2 2; -2 2; -3 2; -2 2; -3 2]; 

[obs nbvar10]=size(xdata10);
nptless    = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar    = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar10     = nbvar10/3;                         % number of variables included in VAR
irf10      = xdata10(1:obs,nvar10+1:2*nvar10);    % IRF of variables 
lowerb10   = xdata10(1:obs,1:nvar10);           % lower bound of IRF
upperb10   = xdata10(1:obs,2*nvar10+1:3*nvar10);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar10
  irf10(:,k)      = scaling(k)*irf10(1:obs,k);  
  lowerb10(:,k)   = scaling(k)*lowerb10(1:obs,k); 
  upperb10(:,k)   = scaling(k)*upperb10(1:obs,k);
end

%%%%% PVARMODEL1
[xdata1]=xlsread('TECH-Z-Y-L-WPC.xlsx');  scaling=[1 1 1 1];               
namvar= char('DLRZ4','DY','DLABH','DWHIPC');  nbPVAR  = 1; %chartbounds = [0 1.2; -10 4; -3 3; -8 4; -8 4]; %chartbounds = [-2 2; -2 2; -2 2; -2 2]; % max and min of the x-axis  

[obs nbvar1]=size(xdata1);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar1     = nbvar1/3;                       % number of variables included in VAR
irf1      = xdata1(1:obs,nvar1+1:2*nvar1);    % IRF of variables 
lowerb1   = xdata1(1:obs,1:nvar1);           % lower bound of IRF
upperb1   = xdata1(1:obs,2*nvar1+1:3*nvar1);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar1
  irf1(:,k)      = scaling(k)*irf1(1:obs,k);  
  lowerb1(:,k)   = scaling(k)*lowerb1(1:obs,k); 
  upperb1(:,k)   = scaling(k)*upperb1(1:obs,k);
end

%%%%%%%%%%% Impulse functions %%%%%%%%%% 

figure(1)
%subplot(3,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb10(1:11,4)',fliplr(lowerb10(1:11,4)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdZ_bias(2:12),'-ks','LineWidth',5);
%plot(timeperm(2:12),pathdZ_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf10(1:11,4)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb10(1:11,4)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb10(1:11,4)','blue','LineWidth',2,'LineStyle','--');
hold off


figure(2)
%subplot(3,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb10(1:11,2)',fliplr(lowerb10(1:11,2)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdZH_bias(2:12),'-ks','LineWidth',5);
%plot(timeperm(2:12),pathdZH_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf10(1:11,2)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb10(1:11,2)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb10(1:11,2)','blue','LineWidth',2,'LineStyle','--');

xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb10(1:11,3)',fliplr(lowerb10(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdZN_bias(2:12),'-ks','LineWidth',5);
%plot(timeperm(2:12),pathdZN_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf10(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb10(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb10(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off


figure(3)
%subplot(3,2,2)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb1(1:11,2)',fliplr(lowerb1(1:11,2)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
bands.Annotation.LegendInformation.IconDisplayStyle = 'off';
plot(timeperm(2:12),pathdYR_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdYR_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf1(1:11,2)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb1(1:11,2)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb1(1:11,2)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of initial steady-state');  %title('GDP, Y=YT+(P*YN)'); 
legend('Baseline (MaCurdy [1981] pref.)','GHH pref.','Empirical IRF');

figure(4)
%subplot(3,2,3)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb1(1:11,3)',fliplr(lowerb1(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdL_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdL_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf1(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb1(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb1(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation in % of steady-state');  %title('Aggregate Hours Worked, L=LT+LN'); 


%%%%% PVARMODEL4
[xdata4, ~, ~]=xlsread('TECH-Z-LTLN-WNWT.xlsx'); scaling=[1 1 1];                                                                           
namvar=char('DLRZ4','DRLH','DLRWH'); nbPVAR  = 4; %chartbounds = [-2 2; -3 2; -2 3]; %chartbounds = [-2 2; -3 2; -2 3];  

[obs nbvar4]=size(xdata4);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar4     = nbvar4/3;                       % number of variables included in VAR
irf4      = xdata4(1:obs,nvar4+1:2*nvar4);    % IRF of variables 
lowerb4   = xdata4(1:obs,1:nvar4);           % lower bound of IRF
upperb4   = xdata4(1:obs,2*nvar4+1:3*nvar4);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar4
  irf4(:,k)      = scaling(k)*irf4(1:obs,k);  
  lowerb4(:,k)   = scaling(k)*lowerb4(1:obs,k); 
  upperb4(:,k)   = scaling(k)*upperb4(1:obs,k);
end


%%%%% PVARMODEL5
[xdata5, ~, ~]=xlsread('TECH-Z-YTYN-PNPT.xlsx'); scaling=[1 1 1];                                                                             
namvar=char('DLRZ4','DRY','DLRP'); nbPVAR  = 5; %chartbounds = [-2 2; -3 2; -2 4];   %chartbounds = [-2 2; -3 2; -2 4];  

[obs nbvar5]=size(xdata5);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar5     = nbvar5/3;                       % number of variables included in VAR
irf5      = xdata5(1:obs,nvar5+1:2*nvar5);    % IRF of variables 
lowerb5   = xdata5(1:obs,1:nvar5);           % lower bound of IRF
upperb5   = xdata5(1:obs,2*nvar5+1:3*nvar5);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar5
  irf5(:,k)      = scaling(k)*irf5(1:obs,k);  
  lowerb5(:,k)   = scaling(k)*lowerb5(1:obs,k); 
  upperb5(:,k)   = scaling(k)*upperb5(1:obs,k);
end

%%%%% PVARMODEL15                                                                                                                                              
[xdata13, ~, ~]=xlsread('TECH-Z-YTYN-PTPF.xlsx'); scaling=[1 1 1];                                                                                             
namvar=char('DLRZ4','DRY','DLRPTF'); nbPVAR  = 13; %chartbounds = [-2 2; -3 2; -2 4];   %chartbounds = [-2 2; -3 2; -2 4];                                   
                                                                                                                                                               
[obs nbvar13]=size(xdata13);                                                                                                                                   
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8)              
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)                                                      
nvar13    = nbvar13/3;                       % number of variables included in VAR                                                                             
irf13     = xdata13(1:obs,nvar13+1:2*nvar13);    % IRF of variables                                                                                            
lowerb13  = xdata13(1:obs,1:nvar13);           % lower bound of IRF                                                                                            
upperb13  = xdata13(1:obs,2*nvar13+1:3*nvar13);  % upper bound of IRF                                                                                          
                                                                                                                                                               
%nbc=3;  % for graph with consumption                                                                                                                          
                                                                                                                                                               
for k=1:nvar13                                                                                                                                              
  irf13(:,k)      = scaling(k)*irf13(1:obs,k);                                                                                                                 
  lowerb13(:,k)   = scaling(k)*lowerb13(1:obs,k);                                                                                                              
  upperb13(:,k)   = scaling(k)*upperb13(1:obs,k);                                                                                                              
end 

 
figure(5)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb5(1:11,3)',fliplr(lowerb5(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdP_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdP_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf5(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb5(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb5(1:11,3)','blue','LineWidth',2,'LineStyle','--');
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb13(1:11,3)',fliplr(lowerb13(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdPH_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdPT_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf13(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb13(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb13(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off
%legend('Model','Data');
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Relative Output, Y^{T}/Y^{N}'); 

%%%%% PVARMODEL6
[xdata6, ~, ~]=xlsread('TECH-Z-YN-LN-WNPC.xlsx'); scaling=[1 1 1 1];                                                                           
namvar=char('DLRZ4','DYN','DLHN','DWNHIPC'); nbPVAR  = 6; %chartbounds = [-2 2; -3 2; -2 3]; %chartbounds = [-2 2; -3 2; -2 3];  

[obs nbvar6]=size(xdata6);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar6     = nbvar6/3;                       % number of variables included in VAR
irf6      = xdata6(1:obs,nvar6+1:2*nvar6);    % IRF of variables 
lowerb6   = xdata6(1:obs,1:nvar6);           % lower bound of IRF
upperb6   = xdata6(1:obs,2*nvar6+1:3*nvar6);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar6
  irf6(:,k)      = scaling(k)*irf6(1:obs,k);  
  lowerb6(:,k)   = scaling(k)*lowerb6(1:obs,k); 
  upperb6(:,k)   = scaling(k)*upperb6(1:obs,k);
end


figure(6)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb6(1:11,3)',fliplr(lowerb6(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdLNL_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdLNL_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf6(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb6(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb6(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non traded output, dLN/L');

%%%%% PVARMODEL7
[xdata7, ~, ~]=xlsread('TECH-Z-YT-LT-WTPC.xlsx'); scaling=[1 1 1 1];                                                                           
namvar=char('DLRZ4','DYT','DLHT','DWTHIPC'); nbPVAR  = 7; %chartbounds = [-2 2; -3 2; -2 3]; %chartbounds = [-2 2; -3 2; -2 3];  

[obs nbvar7]=size(xdata7);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar7     = nbvar7/3;                       % number of variables included in VAR
irf7      = xdata7(1:obs,nvar7+1:2*nvar7);    % IRF of variables 
lowerb7   = xdata7(1:obs,1:nvar7);           % lower bound of IRF
upperb7   = xdata7(1:obs,2*nvar7+1:3*nvar7);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar7
  irf7(:,k)      = scaling(k)*irf7(1:obs,k);  
  lowerb7(:,k)   = scaling(k)*lowerb7(1:obs,k); 
  upperb7(:,k)   = scaling(k)*upperb7(1:obs,k);
end

figure(7)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb7(1:11,2)',fliplr(lowerb7(1:11,2)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdYHY_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdYTY_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf7(1:11,2)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb7(1:11,2)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb7(1:11,2)','blue','LineWidth',2,'LineStyle','--');
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb6(1:11,2)',fliplr(lowerb6(1:11,2)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdYNY_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdYNY_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf6(1:11,2)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb6(1:11,2)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb6(1:11,2)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non traded output, dYT/Y'); 

figure(8)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb7(1:11,3)',fliplr(lowerb7(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdLHL_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdLTL_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf7(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb7(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb7(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non traded output, dLT/L');

%%%%% PVARMODEL8
[xdata8, ~, ~]=xlsread('TECH-Z-YNY-LNL-WNW.xlsx'); scaling=[1 1 1 1];                                                                           
namvar=char('DLRZ4','DLYNY','DLHNH','DLRWNW'); nbPVAR  = 8; %chartbounds = [-2 2; -3 2; -2 3]; %chartbounds = [-2 2; -3 2; -2 3]; 

[obs nbvar8]=size(xdata8);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar8    = nbvar8/3;                       % number of variables included in VAR
irf8     = xdata8(1:obs,nvar8+1:2*nvar8);    % IRF of variables 
lowerb8  = xdata8(1:obs,1:nvar8);           % lower bound of IRF
upperb8  = xdata8(1:obs,2*nvar8+1:3*nvar8);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar8
  irf8(:,k)      = scaling(k)*irf8(1:obs,k);  
  lowerb8(:,k)   = scaling(k)*lowerb8(1:obs,k); 
  upperb8(:,k)   = scaling(k)*upperb8(1:obs,k);
end

[xdata9, ~, ~]=xlsread('TECH-Z-YTY-LTL-WTW.xlsx'); scaling=[1 1 1 1];                                                                           
namvar=char('DLRZ4','DLYTY','DLHTH','DLRWTW'); nbPVAR  = 9; %chartbounds = [-2 2; -3 2; -2 3]; %chartbounds = [-2 2; -3 2; -2 3];

[obs nbvar9]=size(xdata9);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar9    = nbvar9/3;                       % number of variables included in VAR
irf9     = xdata9(1:obs,nvar9+1:2*nvar9);    % IRF of variables 
lowerb9  = xdata9(1:obs,1:nvar9);           % lower bound of IRF
upperb9  = xdata9(1:obs,2*nvar9+1:3*nvar9);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar9
  irf9(:,k)      = scaling(k)*irf9(1:obs,k);  
  lowerb9(:,k)   = scaling(k)*lowerb9(1:obs,k); 
  upperb9(:,k)   = scaling(k)*upperb9(1:obs,k);
end

figure(9)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb9(1:11,2)',fliplr(lowerb9(1:11,2)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdYHS_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdYTS_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf9(1:11,2)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb9(1:11,2)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb9(1:11,2)','blue','LineWidth',2,'LineStyle','--');
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb9(1:11,3)',fliplr(lowerb9(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdLHS_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdLTS_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf9(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb9(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb9(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Non Traded Real Value Added Share, YN/Y');


figure(10)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb8(1:11,4)',fliplr(lowerb8(1:11,4)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdWNW_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdWNW_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf8(1:11,4)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb8(1:11,4)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb8(1:11,4)','blue','LineWidth',2,'LineStyle','--');
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb9(1:11,4)',fliplr(lowerb9(1:11,4)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdWHW_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdWTW_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf9(1:11,4)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb9(1:11,4)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb9(1:11,4)','blue','LineWidth',2,'LineStyle','--');
hold off


[xdata14, ~, ~]=xlsread('TECH-Z-LISN-kN_N=17_p=2.xlsx'); scaling=[1 1 1];                                                                           
namvar=char('DLRZ4','DLLSN0','DLKLN'); nbPVAR  = 14; %chartbounds = [-2 2; -3 2; -2 3]; %chartbounds = [-2 2; -3 2; -2 3]; 

[obs nbvar14]=size(xdata14);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar14    = nbvar14/3;                       % number of variables included in VAR
irf14     = xdata14(1:obs,nvar14+1:2*nvar14);    % IRF of variables 
lowerb14  = xdata14(1:obs,1:nvar14);           % lower bound of IRF
upperb14  = xdata14(1:obs,2*nvar14+1:3*nvar14);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar14
  irf14(:,k)      = scaling(k)*irf14(1:obs,k);  
  lowerb14(:,k)   = scaling(k)*lowerb14(1:obs,k); 
  upperb14(:,k)   = scaling(k)*upperb14(1:obs,k);
end


figure(11)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb14(1:11,2)',fliplr(lowerb14(1:11,2)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdLISN_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdLISN_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf14(1:11,2)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb14(1:11,2)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb14(1:11,2)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Labor income share, LISN');

figure(12)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb14(1:11,3)',fliplr(lowerb14(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdkNK_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdkNK_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf14(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb14(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb14(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Capital-labor ratio, kN');

[xdata15, ~, ~]=xlsread('TECH-Z-LIST-kT_N=17_p=2.xlsx'); scaling=[1 1 1];                                                                           
namvar=char('DLRZ4','DLLST0','DLKLT'); nbPVAR  = 15; %chartbounds = [-2 2; -3 2; -2 3]; %chartbounds = [-2 2; -3 2; -2 3];   

[obs nbvar15]=size(xdata15);
nptless  = 0;                             % number of points that we want to delete (obs = 11, if nptless=2, graphs start from t=0 to t=11-1-2=8) 
nptsvar  = obs-nptless;                   % number of points of IRF in VAR (starting from 0 to nptsvar-1)
nvar15    = nbvar15/3;                       % number of variables included in VAR
irf15     = xdata15(1:obs,nvar15+1:2*nvar15);    % IRF of variables 
lowerb15  = xdata15(1:obs,1:nvar15);           % lower bound of IRF
upperb15  = xdata15(1:obs,2*nvar15+1:3*nvar15);  % upper bound of IRF

%nbc=3;  % for graph with consumption 

for k=1:nvar14
  irf14(:,k)      = scaling(k)*irf15(1:obs,k);  
  lowerb14(:,k)   = scaling(k)*lowerb15(1:obs,k); 
  upperb14(:,k)   = scaling(k)*upperb15(1:obs,k);
end


figure(13)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb15(1:11,2)',fliplr(lowerb15(1:11,2)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdLISH_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdLIST_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf15(1:11,2)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb15(1:11,2)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb15(1:11,2)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Labor income share, LISN');

figure(14)
%subplot(2,2,1)
hold on
xpoints=[timeperm(2:12),fliplr(timeperm(2:12))];
area=[upperb15(1:11,3)',fliplr(lowerb15(1:11,3)')];
bands = patch(xpoints,area,[1 1 1]*0.85,'LineStyle','non');
plot(timeperm(2:12),pathdkHK_bias(2:12),'-ks','LineWidth',5);
plot(timeperm(2:12),pathdkTK_imlcac(2:12),'red','LineWidth',3,'LineStyle','--');
plot(timeperm(2:12),irf15(1:11,3)','blue','LineWidth',3);
%plot(timeperm(2:12),lowerb15(1:11,3)','blue','LineWidth',2,'LineStyle','--');
%plot(timeperm(2:12),upperb15(1:11,3)','blue','LineWidth',2,'LineStyle','--');
hold off
%xlabel('Time'); ylabel('Deviation from initial steady-state');  %title('Capital-labor ratio, kN');

clear



