global sigmaC phi varphi  
global gammaL sigmaL phiI varphiI
global r deltaK omegaG omegaGN
global ZT ZN thetaT thetaN kappa
global epsilon vartheta 
global B0 K0 GT GN 
global xiT xiN barzT barzN gzT gzN gz gzT0 gzN0 aT aN

% Maxim duration for graphics
Tg = 10;
       
% Minim duration for graphics
Tm = 0; 

% unit for graph
Tu = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% IML CAC- epsilon = 1.04, sigmaL=0.5, kT>kN              %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ZT_0         = 1.00;  
ZN_0         = 1.00;
omegaG       = 0.196; 
omegaGN      = 0.90; 
thetaT_0     = 0.631; 
thetaN_0     = 0.682; 
sigmaL_0     = 1.6; 
gammaL       = 1; 
sigmaC_0     = 2;  
phi_0        = 0.44;
varphi_0     = 0.513;                   
epsilon_0    = 1.6; 
vartheta_0   = 0.395;
phiI_0       = 1.00000000001;                    
varphiI_0    = 0.379;  
kappa_0      = 17; 
  
r            = 0.04; 
beta         = r; 
deltaK       = 0.093;

B0           = 6.1;
K0           = 0;

ZT           = ZT_0;       
ZN           = ZN_0;       
thetaT       = thetaT_0;   
thetaN       = thetaN_0;   
sigmaC       = sigmaC_0 ;  
sigmaL       = sigmaL_0;   
phi          = phi_0 ;     
varphi       = varphi_0 ;  
phiI         = phiI_0 ;    
varphiI      = varphiI_0 ; 
epsilon      = epsilon_0;  
vartheta     = vartheta_0;    
kappa        = kappa_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_ini        = 1.024   ; % Consumption 
L_ini        = 1.035   ; % Labor supply 
kT_ini       = 5.084  ; % Capital-labor ratio in sector T
WT_ini       = 1.725   ; % Wage rate in sector T
WN_ini       = 1.568   ; % Wage rate in sector N
W_ini        = 1.616   ; % Aggregate wage index
kN_ini       = 2.971  ; % Capital-labor ratio in sector N
P_ini        = 2.262   ; % Relative price of non tradables
K_ini        = 3.785  ; % Stock of capital
B_ini        = -1.58  ; % Stock of Traded Bonds
alphaL_ini   = 0.664    ; % Non tradable share of compensation of employees
CN_ini       = 0.299   ; % Consumption in non tradables 
CT_ini       = 0.589   ; % Consumption in tradables 
PC_ini       = 1.186   ; % Consumption price index
alphaC_ini   = 0.430   ; % Non tradables share of consumption expenditure
IN_ini       = 0.235   ; % Non traded investment
IT_ini       = 0.000   ; % Traded investment
alphaI_ini   = 1.000    ; % Non tradable share of investment expenditure
PI_ini       = 1.486   ; % Investment price index
PIprime_ini  = 1.000   ; % partial derivative of the investment price index
LT_ini       = 0.322   ; % Labor in sector T
LN_ini       = 0.712   ; % Labor in sector N 
GT_ini       = 0.03    ; % Government spending in tradables
GN_ini       = 0.21    ; % Government spending in non tradables 
f_ini        = 1.935   ; % Output per worker in sector T 
h_ini        = 1.408   ; % Output per worker in sector N     
CT_P_ini     =  0.000  ; % Partial derivative of CT=CT(P,lambda)
CN_P_ini     =  -0.410 ; % Partial derivative of CN=CN(P,lambda)    
LT_WT_ini    = 0.195   ; % Partial derivative of LT=LT(lambda,WT,WN) 
LT_WN_ini    = -0.060  ; % Partial derivative of LT=LT(lambda,WT,WN) 
LN_WT_ini    = -0.060  ; % Partial derivative of LN=LN(lambda,WT,WN) 
LN_WN_ini    = 0.393   ; % Partial derivative of LN=LN(lambda,WT,WN) 
lambda_ini   = 0.967    ; % Intertemporal Solvency Condition          
                                                          
x0 =[C_ini L_ini kT_ini WT_ini WN_ini W_ini kN_ini P_ini K_ini B_ini alphaL_ini CN_ini CT_ini PC_ini alphaC_ini IN_ini IT_ini alphaI_ini PI_ini PIprime_ini LT_ini LN_ini GT_ini GN_ini f_ini h_ini CT_P_ini CN_P_ini LT_WT_ini LT_WN_ini LN_WT_ini LN_WN_ini lambda_ini];
[x,fval,exitflag]=fsolve('TECH_IML_CAC_SS0',x0,optimset('display','off','TolFun',1e-011));

C       = x(1)  ; % Consumption 
L       = x(2)  ; % Labor supply 
kT      = x(3)  ; % Capital-labor ratio in sector T
WT      = x(4)  ; % Wage rate in sector T
WN      = x(5)  ; % Wage rate in sector N
W       = x(6)  ; % Aggregate wage index
kN      = x(7)  ; % Capital-labor ratio in sector N
P       = x(8)  ; % Relative price of non tradables
K       = x(9)  ; % Stock of capital
B       = x(10) ; % Stock of Traded Bonds
alphaL  = x(11) ; % Output per worker in sector N 
CN      = x(12) ; % Consumption in non tradables 
CT      = x(13) ; % Consumption in tradables 
PC      = x(14) ; % Consumption price index
alphaC  = x(15) ; % Non tradable share of consumption - alphaC
IN      = x(16) ; % Non tradable investment
IT      = x(17) ; % Tradable investment 
PI      = x(18) ; % Investment price index
alphaI  = x(19) ; % Non tradable share of investment 
PIprime = x(20) ; % Partial derivative of PI
LT      = x(21) ; % Labor in sector T
LN      = x(22) ; % Labor in sector N 
GT      = x(23) ; % Government spending in tradables
GN      = x(24) ; % Government spending in non tradables 
f       = x(25) ; % Output per worker in sector T 
h       = x(26) ; % Output per worker in sector N 
CT_P    = x(27) ; % Partial derivative of CT=CT(P,lambda)
CN_P    = x(28) ; % Partial derivative of CN=CN(P,lambda)
LT_WT   = x(29) ; % Partial derivative of LT=LT(lambda,WT,WN)
LT_WN   = x(30) ; % Partial derivative of LT=LT(lambda,WT,WN)
LN_WT   = x(31) ; % Partial derivative of LN=LN(lambda,WT,WN)
LN_WN   = x(32) ; % Partial derivative of LN=LN(lambda,WT,WN) 
lambda  = x(33) ; % Intertemporal Solvency Condition     

% Sectoral outputs and sectoral profits   
KT  = LT*kT;  
YT  = ZT*(LT^thetaT)*(KT^(1-thetaT));  
RK  = (1-thetaT)*(YT/KT); 
PiT = YT - (RK*KT) - (WT*LT);
  
KN  = LN*kN;  
YN  = ZN*(LN^thetaN)*(KN^(1-thetaN));   
PiN = (P*YN) - (RK*KN) - (WN*LN);

% Labor income share in the traded good and non traded good sector
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN); 

% Partial derivatives of LT and LN
LT_1lamb   = sigmaL*LT/lambda; 
LN_1lamb   = sigmaL*LN/lambda;

% Solutions for kT, kN, LT, LN as functions of P,K,ZT,ZN 
Psi_WT   = ( (kT*LT_WT) + (kN*LN_WT) );
Psi_WN   = ( (kT*LT_WN) + (kN*LN_WN) );
Psi_lamb = ( (kT*LT_1lamb) + (kN*LN_1lamb) ); 

d11 = -(thetaT/kT); 
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaT)/kT); 
d22 = 0;  
d23 = -(1/WT); 
d24 = 0; 
d31 = 0; 
d32 = ((1-thetaN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LT; 
d42 = LN; 
d43 = Psi_WT; 
d44 = Psi_WN; 

e11 = (1/P); 
e12 = 0;
e13 = 0;
e14 = -(1/ZT);
e15 = (1/ZN); 
e21 = 0; 
e22 = 0; 
e23 = 0;
e24 = -(1/ZT); 
e25 = 0; 
e31 = -(1/P); 
e32 = 0; 
e33 = 0;
e34 = 0; 
e35 = -(1/ZN); 
e41 = 0; 
e42 = 1; 
e43 = -Psi_lamb;
e44 = 0; 
e45 = 0; 
    
M = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X = [e11 e12 e13 e14 e15; e21 e22 e23 e24 e25; e31 e32 e33 e34 e35; e41 e42 e43 e44 e45];
JST = inv(M);
MST = JST*X;
kT_P = MST(1,1); kT_K = MST(1,2); kT_lambda = MST(1,3); kT_ZT = MST(1,4); kT_ZN = MST(1,5);
kN_P = MST(2,1); kN_K = MST(2,2); kN_lambda = MST(2,3); kN_ZT = MST(2,4); kN_ZN = MST(2,5);
WT_P = MST(3,1); WT_K = MST(3,2); WT_lambda = MST(3,3); WT_ZT = MST(3,4); WT_ZN = MST(3,5);
WN_P = MST(4,1); WN_K = MST(4,2); WN_lambda = MST(4,3); WN_ZT = MST(4,4); WN_ZN = MST(4,5);  

% Solutions for sectoral labor and sectoral output Lj=Lj(lambda,P,K,ZT,ZN),
% Yj=Yj(lambda,P,K,ZT,ZN)
LT_P = (LT_WT*WT_P) + (LT_WN*WN_P); 
LN_P = (LN_WT*WT_P) + (LN_WN*WN_P); 
LT_K = (LT_WT*WT_K) + (LT_WN*WN_K); 
LN_K = (LN_WT*WT_K) + (LN_WN*WN_K);
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YT_K = YT*( (LT_K/LT) + (1-thetaT)*(kT_K/kT) ); 
YN_K = YN*( (LN_K/LN) + (1-thetaN)*(kN_K/kN) ); 

LT_lambda = LT_1lamb + (LT_WT*WT_lambda) + (LT_WN*WN_lambda);
LN_lambda = LN_1lamb + (LN_WT*WT_lambda) + (LN_WN*WN_lambda);
YT_lambda = YT*( (LT_lambda/LT) + (1-thetaT)*(kT_lambda/kT) ); 
YN_lambda = YN*( (LN_lambda/LN) + (1-thetaN)*(kN_lambda/kN) ); 

LT_ZT = (LT_WT*WT_ZT) + (LT_WN*WN_ZT); 
LN_ZT = (LN_WT*WT_ZT) + (LN_WN*WN_ZT);
YT_ZT = YT*( (1/ZT) + (LT_ZT/LT) + (1-thetaT)*(kT_ZT/kT) ); 
YN_ZT = YN*( (LN_ZT/LN) + (1-thetaN)*(kN_ZT/kN) ); 

LT_ZN = (LT_WT*WT_ZN) + (LT_WN*WN_ZN);               
LN_ZN = (LN_WT*WT_ZN) + (LN_WN*WN_ZN);               
YT_ZN = YT*( (LT_ZN/LT) + (1-thetaT)*(kT_ZN/kT) );  
YN_ZN = YN*( (1/ZN) + (LN_ZN/LN) + (1-thetaN)*(kN_ZN/kN) ); 

% Solution for L as function L=L(K,lambda,P,ZT,ZN)
L_lambda = sigmaL*(L/lambda);
L_W  = sigmaL*(L/W); 
L_WT = sigmaL*L*(1-alphaL)/WT; 
L_WN = sigmaL*L*alphaL/WN; 
L_K  = (L_WT*WT_K) + (L_WN*WN_K); 
L_P  = (L_WT*WT_P) + (L_WN*WN_P);
L_ZT = (L_WT*WT_ZT) + (L_WN*WN_ZT); 
L_ZN = (L_WT*WT_ZN) + (L_WN*WN_ZN);

% Solution for C as function C=C(lambda,P) 
C_lambda  = -sigmaC*(C/lambda); 
C_P       = -alphaC*sigmaC*(C/P); 

% Solution for W as function W=W(WT,WN,ZT,ZN) 
W_WT      = (W/WT)*(1-alphaL); 
W_WN      = (W/WN)*alphaL; 
W_K       = (W_WT*WT_K) + (W_WN*WN_K); 
W_P       = (W_WT*WT_P) + (W_WN*WN_P);
W_ZT      = (W_WT*WT_ZT) + (W_WN*WN_ZT); 
W_ZN      = (W_WT*WT_ZN) + (W_WN*WN_ZN);
W_lambda  = (W_WT*WT_lambda) + (W_WN*WN_lambda);

% Capital rental rates
RKT = (1-thetaT)*(YT/KT); 
RKN = P*(1-thetaN)*(YN/KN);

% GDP and output shares in real terms
Y   = YT+(P*YN);

% Solution for Y as function Y=Y(K,P,lambda,ZT,ZN) 
Y_P       = YT_P + (P*YN_P) + YN; 
Y_K       = YT_K + (P*YN_K); 
Y_lambda  = YT_lambda + (P*YN_lambda); 
Y_ZT      = YT_ZT + (P*YN_ZT);
Y_ZN      = YT_ZN + (P*YN_ZN);

% Investment function I/K = v(Q/PI(P))+delta_K
v_Q = 1/(kappa*PI); 
v_P = -alphaI/(kappa*P); 

% Solution for R as function R=R(K,P,lambda,ZT,ZN) 
RK    = PI*(r+deltaK); 
R_K  = -RK*thetaT*(kT_K/kT); 
R_P  = -RK*thetaT*(kT_P/kT); 
R_ZT = (RK/ZT) - RK*thetaT*(kT_ZT/kT); 
R_ZN = -RK*thetaT*(kT_ZN/kT); 
R_lambda = -RK*thetaT*(kT_lambda/kT);

% Solving for the relative price P=P(lambda,K,Q,GN)
PsiP  = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime) - K*v_P; 
P_K   = -(1/PsiP)*( (YN_K/PIprime) - deltaK ); 
P_Q   = (K/PsiP)*v_Q; 
P_ZT  = -(YN_ZT/PIprime)*(1/PsiP); 
P_ZN  = -(YN_ZN/PIprime)*(1/PsiP);

% Eigenvalues and Eigenvectors 
Upsilon_K = ( (YN_K/PIprime) - deltaK);                                                                        
Upsilon_P = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime); 
Sigma_K   = -R_K; 
Sigma_P   = -(R_P + (PI*kappa*v_P*deltaK)); 
Sigma_Q   = (r+deltaK) - (PI*kappa*v_Q*deltaK); 
 
x11 = Upsilon_K + (Upsilon_P*P_K);                                                                         
x12 = (Upsilon_P*P_Q);                                                                                                                                                                                                                     
x21 = Sigma_K + (Sigma_P*P_K);                        
x22 = Sigma_Q + (Sigma_P*P_Q);   

J = [x11 x12; x21 x22];
[V,nu]=eig(J)
[sorted idx] = sort(diag(nu));
nu_sorted = diag(sorted);
V_sorted = V(:,idx);
nu1 = nu_sorted(1,1); 
nu2 = nu_sorted(2,2); 
omega11 = V_sorted(1,1)/V_sorted(1,1); 
omega21 = V_sorted(2,1)/V_sorted(1,1); 
omega12 = V_sorted(1,2)/V_sorted(1,2); 
omega22 = V_sorted(2,2)/V_sorted(1,2); 
TrJ = trace(J); 
DetJ = det(J); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q);
% Xi_Q=0
Xi_K  = (YT_K - ((1-alphaI)/alphaI)*P*YN_K); 
Xi_P  = ( (YT_P-CT_P) - ((1-alphaI)/alphaI)*P*(YN_P-CN_P) - phiI*((1-alphaI)/alphaI)*IN ); 
B_K   = (Xi_K + (Xi_P*P_K)); 
B_Q   = (Xi_P*P_Q); 
N1    = (B_K + (B_Q*omega21));
H1    = N1/(nu1-r); 

% Government spending 
G  = GT+ (P*GN);   

% TFP
a  = (1/(alphaI+(1-alphaI)*(thetaT/thetaN))); 
b  = a*(thetaT/thetaN); 
Z  = (ZT^a)/(ZN^b); 

% Investment 
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
I = deltaK*K; 
EI = PI*I; 
omegaI = PI*I/Y; 

% Net exports, current account and saving
NX  = YT-CT-GT-IT; 
CA  = (r*B) + YT - CT - GT - IT; 
A   = B + (PI*K); 
Tax = GT + (P*GN); 
Sav = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC  = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;
RKPC = RK/PC;

% Labor income and Capital income shares
EL      = W*L; 
omegaL  = EL/Y; 
EK      = RK*K; 
omegaK  = EK/Y;
alphaK  = (RKN*KN)/(RK*K); 

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT); 
YTYN  = (YT/YN); 
LTLN  = (LT/LN);

% Consumption 
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 

% L_T, L_N and FOC for LT and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LT^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_T     = ((vartheta)^(-1/epsilon))*(LT/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Sectoral ratios
omegaINYN = IN/YN; 
omegaITYT = IT/YT; 
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;
omegaYT   =  YT / Y;
omegaYN   =  (P)*YN/Y; 
omegaLT   =  LT / L;
omegaLN   =  LN / L; 

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Check the closure of the model
cond1  = (1-thetaT)*(YT/KT)-RK;                               
cond2  = P*(1-thetaN)*(YN/KN)-RK;                             
cond3  = thetaT*(YT/LT)-WT;                                   
cond4  = P*thetaN*(YN/LN)-WN;                                 
cond5  = (LT*kT)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI;                                    
cond7  = YN-CN-GN-IN;                                         
cond8  = YT-CT-GT-IT+(r*B);                                   
cond9  = (B-B0) - H1*(K-K0);                                  
cond10  = DetJ - (nu1*nu2);                                   
cond11 = TrJ - (nu1+nu2);                                     
cond12 = (LT/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);  
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);               
cond14 = (PC*C) - (CT+(P*CN));                                
cond15 = (W*L) - ((WT*LT)+(WN*LN));                           
cond16 = gammaL*(L^(1/sigmaL))*L_T - (lambda*WT);               
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);               
cond18 = Y - (PC*C) - G - (PI*I) + (r*B);                     
cond19 = Sav;                                                 
cond20 = (PC*C) - (CT+(P*CN));                                
cond21 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);            
cond22 = (PI*I) - (IT+(P*IN));                                
cond23 = (RK*K) - ((RKT*KT)+(RKN*KN));                        
cond24 = 1 - (omegaK + omegaL);                               
 
disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                     Initial Steady State with kT > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f    PIprime: %9.3f',EI,PIprime));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector T');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('Profit             : %9.10f',PiT));

disp(' ');
disp('Partial derivatives CT and CN');
disp(sprintf('CN_P  :   %7.3f    CT_P    : %9.3f',CN_P,CT_P));

disp('Partial derivatives LT and LN');
disp(sprintf('LN_WT       :   %7.3f  LT_WT      : %9.3f',LN_WT,LT_WT));
disp(sprintf('LN_WN       :   %7.3f  LT_WN      : %9.3f',LN_WN,LT_WN));
disp(sprintf('LN_lamb     :   %7.3f  LT_lamb    : %9.3f',LN_1lamb,LT_1lamb));
disp(sprintf('LN_ZT       :   %7.3f  LT_ZT      : %9.3f',LN_ZT,LT_ZT));
disp(sprintf('LN_ZN       :   %7.3f  LT_ZN      : %9.3f',LN_ZN,LT_ZN));


disp('Partial derivatives kT and kN');
disp(sprintf('kN_P       :   %7.6f  kT_P       : %9.6f',kN_P,kT_P));   
disp(sprintf('kN_K       :   %7.6f  kT_K       : %9.6f',kN_K,kT_K));  
disp(sprintf('kN_lambda  :   %7.3f  kT_lambda  : %9.3f',kN_lambda,kT_lambda));  
disp(sprintf('kN_ZT      :   %7.6f  kT_ZT      : %9.6f',kN_ZT,kT_ZT));
disp(sprintf('kN_ZN      :   %7.6f  kT_ZN      : %9.6f',kN_ZN,kT_ZN));

disp('Partial derivatives WT and WN');
disp(sprintf('WN_P       :   %7.6f  WT_P       : %9.6f',WN_P,WT_P));     
disp(sprintf('WN_K       :   %7.6f  WT_K       : %9.6f',WN_K,WT_K));    
disp(sprintf('WN_lambda  :   %7.3f  WT_lambda  : %9.3f',WN_lambda,WT_lambda)); 
disp(sprintf('WN_ZT      :   %7.6f  WT_ZT      : %9.6f',WN_ZT,WT_ZT));
disp(sprintf('WN_ZN      :   %7.6f  WT_ZN      : %9.6f',WN_ZN,WT_ZN));


disp('Partial derivatives LT and LN');
disp(sprintf('LN_P       :   %7.6f  LT_P       : %9.6f',LN_P,LT_P));
disp(sprintf('LN_K       :   %7.6f  LT_K       : %9.6f',LN_K,LT_K));
disp(sprintf('LN_lambda  :   %7.3f  LT_lambda  : %9.3f',LN_lambda,LT_lambda));
disp(sprintf('LN_ZT      :   %7.6f  LT_ZT      : %9.6f',LN_ZT,LT_ZT));
disp(sprintf('LN_ZN      :   %7.6f  LT_ZN      : %9.6f',LN_ZN,LT_ZN));

disp('Partial derivatives C');
disp(sprintf('YN_P       :   %7.6f  YT_P       : %9.6f',YN_P,YT_P));
disp(sprintf('YN_K       :   %7.6f  YT_K       : %9.6f',YN_K,YT_K));
disp(sprintf('YN_lambda  :   %7.3f  YT_lambda  : %9.3f',YN_lambda,YT_lambda));
disp(sprintf('YN_ZT      :   %7.6f  YT_ZT      : %9.6f',YN_ZT,YT_ZT));
disp(sprintf('YN_ZN      :   %7.6f  YT_ZN      : %9.6f',YN_ZN,YT_ZN));

disp('Partial derivatives of Y');
disp(sprintf('Y_P        :   %7.3f  Y_K        : %9.3f',Y_P,Y_K));
disp(sprintf('Y_ZT       :   %7.3f  Y_ZN       : %9.3f',Y_ZT,Y_ZN));
disp(sprintf('Y_lambda   : %9.3f',Y_lambda));

disp('Partial derivatives of L');
disp(sprintf('L_T        :   %7.3f  L_N        : %9.3f',L_T,L_N));

disp('Partial derivatives of L');
disp(sprintf('L_WT       :   %7.3f  L_WN       : %9.3f',W_WT,W_WN));
disp(sprintf('L_P        :   %7.3f  L_K        : %9.3f',L_P,L_K));
disp(sprintf('L_ZT       :   %7.3f  L_ZN       : %9.3f',L_ZT,L_ZN));
disp(sprintf('L_lambda   :   %7.3f  W_lambda   : %9.3f',L_lambda,W_lambda));

disp('Partial derivatives of W');
disp(sprintf('W_WT       :   %7.3f  W_WN       : %9.3f',W_WT,W_WN));
disp(sprintf('W_P        :   %7.3f  W_K        : %9.3f',W_P,W_K));
disp(sprintf('W_ZT       :   %7.3f  W_ZN       : %9.3f',W_ZT,W_ZN));

disp(' ');
disp('Wealth');
disp(sprintf('K      :   %5.3f    B  :   %5.6f',K,B));
disp(sprintf('lambda :   %5.15f   A  :   %5.3f',lambda,A));
disp(sprintf('Sav    :   %5.10f   CA :   %5.10f',Sav,CA));

disp(' ');
disp('Linearization');
disp(sprintf('R_lambda  :  %5.4f  R_K       : %5.4f   R_P     : %5.4f',R_lambda,R_K,R_P));
disp(sprintf('R_ZT      :  %5.4f  R_ZN      : %5.4f',R_ZT,R_ZN));
disp(sprintf('PsiP      :  %5.4f  P_K       : %5.4f   P_Q     : %5.4f',PsiP,P_K,P_Q));
disp(sprintf('P_ZT      :  %5.4f  P_ZN      : %5.4f',P_ZT,P_ZN));
disp(sprintf('v_P       :  %5.4f  v_Q       : %5.4f',v_P,v_Q));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_P : %5.4f',Upsilon_K,Upsilon_P));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_P   : %5.4f   Sigma_Q : %5.4f',Sigma_K,Sigma_P,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu1,nu2));
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega11,omega12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega21,omega22));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));

disp(' ');
disp(sprintf('Marginal product of KT = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LT = WT       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LT/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLT) = lambda*WT     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));

kT_0 = kT;  kN_0 = kN; P_0 = P; LT_0 = LT; K_0 = K; C_0 = C;  
LN_0  = LN; L_0 = L; W_0 = W; f_0 = f; h_0   = h; 
YT_0  = YT; YN_0  = YN; Y_0  = Y; KT_0  = KT; KN_0  = KN; G_0 = G;     
PC_0 = PC; alphaC_0 = alphaC; CN_0 = CN; CT_0 = CT;  
ZT_0 = ZT; ZN_0 = ZN; Z_0 = Z; GT_0 = GT; GN_0 = GN; 
LT_0 = LT; LN_0 = LN; KT_0 = KT; KN_0 = KN; WT_0 = WT; WN_0 = WN; 
Omega_0 = Omega; YTYN_0 = YTYN; LTLN_0 = LTLN;

CA_0 = CA; Sav_0 = Sav; NX_0 = NX; I_0 = I; lambda_0  = lambda; A_0 = A; 
B_0 = B; IN_0 = IN; IT_0 = IT; PI_0 = PI; alphaI_0 = alphaI; PIprime_0 = PIprime; EI_0 = EI; 
WPC_0 = WPC; WTPC_0 = WTPC; WNPC_0 = WNPC; alphaL_0 = alphaL; RK_0 = RK; PT_0 = 1; PN_0 = P; 

omegaL_0 = omegaL; omegaK_0 = omegaK; omegaI_0 = omegaI; omegaINYN_0 = omegaINYN;
omegaITYT_0 = omegaITYT; omegaGTYT_0 = omegaGTYT; omegaGNYN_0 = omegaGNYN; omegaGN_0 = omegaGN;
omegaYT_0 = omegaYT; omegaYN_0 = omegaYN; omegaLT_0 = omegaLT; omegaLN_0 = omegaLN; 
omegaC_0 =omegaC; omegaNX_0 =omegaNX; omegaG_0 =omegaG; omegaB_0 =omegaB; omegaKY_0 = omegaKY; 
alphaL_0 = alphaL; alphaK_0 = alphaK; alphaC_0 = alphaC; alphaI_0 = alphaI; 
sLT_0 = sLT; sLN_0 = sLN; kappa_cac = kappa; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Permanent Technology Shock                      %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
B0       = B_0;
K0       = K_0; 
GT       = GT_0; 
GN       = GN_0; 
%% Endogenous response of the ratio ZT/ZN to an exogenous technology shock 
%%%%%%%%%%%%%%%%%%% Calibration shock %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
filename = 'Calibration-file'; 
sheet    = 21;
xlRange  = 'B22:I39';
datac = xlsread(filename,sheet,xlRange)
param_OECD = [datac(18,8)/100  datac(18,4)/100 datac(18,7)/100 datac(18,3)/100 datac(18,1) datac(18,2)];
parameters = param_OECD;
gz       = parameters(1);      
gzT      = parameters(2);      
gzN      = ((a*gzT)-gz)/b;     
gz0      = parameters(3);      
gzT0     = parameters(4);      
gzN0     = ((a*gzT0)-gz0)/b;   
barzN    = gzN - gzN0;         
barzT    = gzT - gzT0;         
xiT      = parameters(5);      
xiN      = parameters(6);      
ZT       = ZT_0*(1+gzT);       
ZN       = ZN_0*(1+gzN);       
aT       = -ZT_0*barzT;        
aN       = -ZN_0*barzN;                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 =[C_0 L_0 kT_0 WT_0 WN_0 W_0 kN_0 P_0 K_0 B_0 CN_0 CT_0 PC_0 IN_0 IT_0 PI_0 LT_0 LN_0 lambda_0];
[x,fval,exitflag]=fsolve('TECH_IML_CAC_perm',x0,optimset('display','off','TolFun',1e-011));
C         = x(1)  ; % Consumption 
L         = x(2)  ; % Labor supply 
kT        = x(3)  ; % Capital-labor ratio in sector T
WT        = x(4)  ; % Wage rate in sector T
WN        = x(5)  ; % Wage rate in sector N
W         = x(6)  ; % Aggregate wage index
kN        = x(7)  ; % Capital-labor ratio in sector N
P         = x(8)  ; % Relative price of non tradables
K         = x(9)  ; % Stock of capital
B         = x(10) ; % Stock of Traded Bonds
CN        = x(11) ; % Consumption in non tradables 
CT        = x(12) ; % Consumption in tradables 
PC        = x(13) ; % Consumption price index
IN        = x(14) ; % Non tradable investment
IT        = x(15) ; % Tradable investment 
PI        = x(16) ; % Investment price index
LT        = x(17) ; % Labor in sector T
LN        = x(18) ; % Labor in sector N  
lambda    = x(19) ; % Marginal utility of wealth lambda

% Sectoral outputs and sectoral profits   
KT  = LT*kT;  
YT  = ZT*(LT^thetaT)*(KT^(1-thetaT));  
RK  = (1-thetaT)*(YT/KT); 
PiT = YT - (RK*KT) - (WT*LT);
  
KN  = LN*kN;  
YN  = ZN*(LN^thetaN)*(KN^(1-thetaN));   
PiN = (P*YN) - (RK*KN) - (WN*LN);

% Capital rental rates
RK  = PI*(r+deltaK); 
RKT = (1-thetaT)*(YT/KT); 
RKN = (P)*(1-thetaN)*(YN/KN); 

% Labor income share in the traded good and non traded good sector
sLT = WT*LT/(YT);
sLN = WN*LN/(P*YN); 

% GDP and shares in real terms
Y  = YT + (P*YN); 
YR = YT + (P_0*YN);
omegaYTR = YT/YR; 
omegaYNR = (P_0*YN)/YR; 

% Government spending 
G = GT+ (P*GN);   

% TFP
a  = (1/(alphaI+(1-alphaI)*(thetaT/thetaN))); 
b  = a*(thetaT/thetaN); 
Z  = (ZT^a)/(ZN^b); 

% Investment 
I_check = ( (varphiI^(1/phiI))*(IT^((phiI-1)/phiI)) + ((1-varphiI)^(1/phiI))*(IN^((phiI-1)/phiI)) )^(phiI/(phiI-1)); 
I       = deltaK*K; 
EI      = PI*I; 
omegaI  = PI*I/Y; 

% Shares
alphaC = P*CN/(PC*C); 
alphaI = P*IN/(PI*I); 
alphaL = WN*LN/(W*L); 
PIprime = (1-varphiI)*(P/PI)^(-phiI);

% Net exports, current account and saving
NX   = YT-CT-GT-IT; 
CA   = (r*B) + YT - CT - GT - IT; 
A    = B + (PI*K); 
Tax  = GT + (P*GN); 
Sav  = (r*A) + (W*L) - (PC*C) - Tax; 

% Real Aggregate Wage 
WPC = W/PC;
WTPC = WT/PC;
WNPC = WN/PC;

% Relative Wage, Relative Production, Relative Labor
Omega = (WN/WT); 
YTYN  = (YT/YN); 
LTLN  = (LT/LN);

% Consumption 
C_check = ( (varphi^(1/phi))*(CT^((phi-1)/phi)) + ((1-varphi)^(1/phi))*(CN^((phi-1)/phi)) )^(phi/(phi-1)); 
% Partial derivatives CT=CT(P), CN=CN(P)
CT_P = alphaC*(CT/P)*(phi-sigmaC);
CN_P = - (CN/P)*(phi*(1-alphaC)+ (sigmaC*alphaC));

% L_T, L_N and FOC for LT and LN 
Vut     = ( (vartheta^(-1/epsilon))*(LT^((epsilon+1)/epsilon)) + ((1-vartheta)^(-1/epsilon))*(LN^((epsilon+1)/epsilon)) ); 
L_check = Vut^(epsilon/(epsilon+1)); 
L_T     = ((vartheta)^(-1/epsilon))*(LT/L)^(1/epsilon); 
L_N     = ((1-vartheta)^(-1/epsilon))*(LN/L)^(1/epsilon);

% Intertemporal solvency condition - lambda 
% Partial derivatives LT(WT,WN), LN(WT,WN)
LT_WT = (LT/WT)*( (epsilon*alphaL) + sigmaL*(1-alphaL) ); 
LT_WN = (LT/WN)*alphaL*(sigmaL-epsilon); 
LN_WT = (LN/WT)*(1-alphaL)*(sigmaL-epsilon); 
LN_WN = (LN/WN)*( epsilon*(1-alphaL) + (sigmaL*alphaL) ); 

% Solutions for kT, kN, LT, LN as functions of P,K 
Psi_WT   = ( (kT*LT_WT) + (kN*LN_WT) );
Psi_WN   = ( (kT*LT_WN) + (kN*LN_WN) );

d11 = -(thetaT/kT); 
d12 = (thetaN/kN);
d13 = 0;
d14 = 0;
d21 = ((1-thetaT)/kT); 
d22 = 0;  
d23 = -(1/WT); 
d24 = 0; 
d31 = 0; 
d32 = ((1-thetaN)/kN);
d33 = 0; 
d34 = -(1/WN);
d41 = LT; 
d42 = LN; 
d43 = Psi_WT; 
d44 = Psi_WN; 

e11 = (1/P); 
e12 = 0;
e13 = -(1/ZT);
e14 = (1/ZN); 
e21 = 0; 
e22 = 0; 
e23 = -(1/ZT); 
e24 = 0; 
e31 = -(1/P); 
e32 = 0; 
e33 = 0; 
e34 = -(1/ZN); 
e41 = 0; 
e42 = 1; 
e43 = 0; 
e44 = 0; 
    
M = [d11 d12 d13 d14; d21 d22 d23 d24; d31 d32 d33 d34; d41 d42 d43 d44];
X = [e11 e12 e13 e14; e21 e22 e23 e24; e31 e32 e33 e34; e41 e42 e43 e44];
JST = inv(M);
MST = JST*X;
kT_P = MST(1,1); kT_K = MST(1,2); kT_ZT = MST(1,3); kT_ZN = MST(1,4);
kN_P = MST(2,1); kN_K = MST(2,2); kN_ZT = MST(2,3); kN_ZN = MST(2,4);
WT_P = MST(3,1); WT_K = MST(3,2); WT_ZT = MST(3,3); WT_ZN = MST(3,4);
WN_P = MST(4,1); WN_K = MST(4,2); WN_ZT = MST(4,3); WN_ZN = MST(4,4);  

% Solutions for sectoral labor and sectoral output Lj=Lj(lambda,P,K),
% Yj=Yj(lambda,P,K)
LT_P = (LT_WT*WT_P) + (LT_WN*WN_P); 
LN_P = (LN_WT*WT_P) + (LN_WN*WN_P); 
LT_K = (LT_WT*WT_K) + (LT_WN*WN_K); 
LN_K = (LN_WT*WT_K) + (LN_WN*WN_K);
YT_P = YT*( (LT_P/LT) + (1-thetaT)*(kT_P/kT) ); 
YN_P = YN*( (LN_P/LN) + (1-thetaN)*(kN_P/kN) ); 
YT_K = YT*( (LT_K/LT) + (1-thetaT)*(kT_K/kT) ); 
YN_K = YN*( (LN_K/LN) + (1-thetaN)*(kN_K/kN) ); 

LT_ZT = (LT_WT*WT_ZT) + (LT_WN*WN_ZT); 
LN_ZT = (LN_WT*WT_ZT) + (LN_WN*WN_ZT);
YT_ZT = YT*( (1/ZT) + (LT_ZT/LT) + (1-thetaT)*(kT_ZT/kT) ); 
YN_ZT = YN*( (LN_ZT/LN) + (1-thetaN)*(kN_ZT/kN) ); 

LT_ZN = (LT_WT*WT_ZN) + (LT_WN*WN_ZN);               
LN_ZN = (LN_WT*WT_ZN) + (LN_WN*WN_ZN);               
YT_ZN = YT*( (LT_ZN/LT) + (1-thetaT)*(kT_ZN/kT) );  
YN_ZN = YN*( (1/ZN) + (LN_ZN/LN) + (1-thetaN)*(kN_ZN/kN) ); 

% Solution for Y as function Y=Y(K,P,lambda,ZT,ZN) 
Y_P       = YT_P + (P*YN_P) + YN; 
Y_K       = YT_K + (P*YN_K); 
Y_ZT      = YT_ZT + (P*YN_ZT);
Y_ZN      = YT_ZN + (P*YN_ZN);

% Solution for L as function L=L(K,lambda,P)
L_W  = sigmaL*(L/W); 
L_WT = sigmaL*L*(1-alphaL)/WT; 
L_WN = sigmaL*L*alphaL/WN; 
L_K  = (L_WT*WT_K) + (L_WN*WN_K); 
L_P  = (L_WT*WT_P) + (L_WN*WN_P);
L_ZT = (L_WT*WT_ZT) + (L_WN*WN_ZT); 
L_ZN = (L_WT*WT_ZN) + (L_WN*WN_ZN);

% Solution for C as function C=C(lambda,P) 
C_lambda  = -sigmaC*(C/lambda); 
C_P       = -alphaC*sigmaC*(C/P); 

% Solution for W as function W=W(WT,WN) 
W_WT      = (W/WT)*(1-alphaL); 
W_WN      = (W/WN)*alphaL; 
W_K       = (W_WT*WT_K) + (W_WN*WN_K); 
W_P       = (W_WT*WT_P) + (W_WN*WN_P);
W_ZT      = (W_WT*WT_ZT) + (W_WN*WN_ZT); 
W_ZN      = (W_WT*WT_ZN) + (W_WN*WN_ZN);

% Investment function I/K = v(Q/PI(P))+delta_K
v_Q = 1/(kappa*PI); 
v_P = -alphaI/(kappa*P); 

% Solution for R as function R=R(K,P,lambda,ZT,ZN) 
RK    = PI*(r+deltaK); 
R_K  = -RK*thetaT*(kT_K/kT); 
R_P  = -RK*thetaT*(kT_P/kT); 
R_ZT = (RK/ZT) - RK*thetaT*(kT_ZT/kT); 
R_ZN = -RK*thetaT*(kT_ZN/kT); 

% Solving for the relative price P=P(lambda,K,Q,GN)
PsiP  = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime) - K*v_P; 
P_K   = -(1/PsiP)*( (YN_K/PIprime) - deltaK ); 
P_Q   = (K/PsiP)*v_Q; 
P_ZT  = -(YN_ZT/PIprime)*(1/PsiP); 
P_ZN  = -(YN_ZN/PIprime)*(1/PsiP);

% Eigenvalues and Eigenvectors 
Upsilon_K   = ( (YN_K/PIprime) - deltaK);                                                                        
Upsilon_P   = ( (YN_P-CN_P) + (IN/P)*phiI*(1-alphaI) )*(1/PIprime); 
Upsilon_ZT  = (YN_ZT/PIprime); 
Upsilon_ZN  = (YN_ZN/PIprime); 
Sigma_K     = -R_K; 
Sigma_P     = -(R_P + (PI*kappa*v_P*deltaK)); 
Sigma_Q     = (r+deltaK) - (PI*kappa*v_Q*deltaK); 
Sigma_ZT    = - R_ZT; 
Sigma_ZN    = - R_ZN;
 
x11   = Upsilon_K + (Upsilon_P*P_K);                                                                         
x12   = (Upsilon_P*P_Q);     
x13   = Upsilon_ZT + Upsilon_P*P_ZT; 
x14   = Upsilon_ZN + Upsilon_P*P_ZN; 
x21   = Sigma_K + (Sigma_P*P_K);                        
x22   = Sigma_Q + (Sigma_P*P_Q);
x23   = Sigma_ZT + Sigma_P*P_ZT; 
x24   = Sigma_ZN + Sigma_P*P_ZN; 
x31   = 0; 
x32   = 0; 
x33   = -xiT; 
x34   = 0; 
x41   = 0; 
x42   = 0; 
x43   = 0; 
x44   = -xiN; 

J = [x11 x12 x13 x14; x21 x22 x23 x24; x31 x32 x33 x34; x41 x42 x43 x44];
% Eigenvalue and Eigenvectors 
[V,nu]=eig(J);
%[ order] = sort(diag(),'descend');  %# sort eigenvalues in descending order V = V(:,order); )
%V = V(:,order);
nu_1 = nu(1,1);             
nu_2 = nu(2,2);             
nu_3 = nu(3,3);             
nu_4 = nu(4,4);             
                            
omega_11 = V(1,1)/V(1,1);   
omega_21 = V(2,1)/V(1,1);   
omega_31 = V(3,1)/V(1,1);   
omega_41 = V(4,1)/V(1,1);   
                            
omega_12 = V(1,2)/V(1,2);   
omega_22 = V(2,2)/V(1,2);   
omega_32 = V(3,2)/V(1,2);   
omega_42 = V(4,2)/V(1,2);   
                            
omega_13 = V(1,3)/V(3,3);   
omega_23 = V(2,3)/V(3,3);   
omega_33 = V(3,3)/V(3,3);   
omega_43 = V(4,3)/V(3,3);   
                            
omega_14 = V(1,4)/V(4,4);   
omega_24 = V(2,4)/V(4,4);   
omega_34 = V(3,4)/V(4,4);   
omega_44 = V(4,4)/V(4,4);   

TrJ = trace(J); 
DetJ = det(J); 

J1 = [x11 x12; x21 x22];
TrJ1 = trace(J1); 
DetJ1 = det(J1);

% Check for Eigenvectors
omega13 = -( x13*(x22+xiT) - (x12*x23) )/( (nu_1+xiT)*(nu_2+xiT) ); 
omega14 = -( x14*(x22+xiN) - (x12*x24) )/( (nu_1+xiN)*(nu_2+xiN) );
omega23 =  ( (x13*x21) - (x11+xiT)*x23 )/( (nu_1+xiT)*(nu_2+xiT) );
omega24 =  ( (x14*x21) - (x11+xiN)*x24 )/( (nu_1+xiN)*(nu_2+xiN) );

% Solve for Arbitrary Constants 
D3 = aT; 
D4 = aN; 
D1 = (K0 - K) - (omega_13*D3) - (omega_14*D4); 

% Intertemporal solvency condition - lambda - dotB = Xi(lambda,K,P,Q,ZT,ZN);
% Xi_Q=0
Xi_K         = (YT_K - ((1-alphaI)/alphaI)*P*YN_K); 
Xi_P         = ( (YT_P-CT_P) - ((1-alphaI)/alphaI)*P*(YN_P-CN_P) - phiI*((1-alphaI)/alphaI)*IN ); 
Xi_ZT        = (YT_ZT - ((1-alphaI)/alphaI)*P*YN_ZT);
Xi_ZN        = (YT_ZN - ((1-alphaI)/alphaI)*P*YN_ZN);
B_K          = (Xi_K + (Xi_P*P_K)); 
B_Q          = (Xi_P*P_Q); 
B_ZT         = (Xi_ZT + (Xi_P*P_ZT)); 
B_ZN         = (Xi_ZN + (Xi_P*P_ZN)); 
N1           = (B_K + (B_Q*omega_21)); 
N2           = ((B_K*omega_13) + (B_Q*omega_23) + B_ZT); 
N3           = ((B_K*omega_14) + (B_Q*omega_24) + B_ZN); 
wB1          = N1/(r-nu_1); 
wBT          = N2/(r+xiT); 
wBN          = N3/(r+xiN);
%B            = B0 + (wB1*D1) + (wBT*aT) + (wBN*aN); 

% Solution for the stock of financial wealth
A0        = B0 + (PI*K0); 
Lambda_K  = (W_K*L)+(W*L_K); 
Lambda_P  = (((W_P*L)+(W*L_P)) - (CN + (PC*C_P) + GN)); 
Lambda_ZT = (W_ZT*L)+(W*L_ZT);
Lambda_ZN = (W_ZN*L)+(W*L_ZN);
A_K       = (Lambda_K + (Lambda_P*P_K)); 
A_Q       = (Lambda_P*P_Q); 
A_ZT      = (Lambda_ZT + (Lambda_P*P_ZT)); 
A_ZN      = (Lambda_ZN + (Lambda_P*P_ZN)); 
M1        = A_K + (A_Q*omega_21); 
M2        = ((A_K*omega_13) + (A_Q*omega_23) + A_ZT); 
M3        = ((A_K*omega_14) + (A_Q*omega_24) + A_ZN); 
wA1       = M1/(r-nu_1); 
wAT       = M2/(r+xiT); 
wAN       = M3/(r+xiN);
A         = A0 + (wA1*D1) + (wAT*D3) + (wAN*D4); 

% Solution for the labor income share sLj=sLj(K,P,ZH,ZN)               
sLT_K  = sLT*( (WT_K/WT) + (LT_K/LT) - (YT_K/YT) );                    
sLT_P  = sLT*( (WT_P/WT) + (LT_P/LT) - (YT_P/YT) );                    
sLT_ZT = sLT*( (WT_ZT/WT) + (LT_ZT/LT) - (YT_ZT/YT) );                 
sLT_ZN = sLT*( (WT_ZN/WT) + (LT_ZN/LT) - (YT_ZN/YT) );                 
                                                                       
sLN_K  = sLN*( (WN_K/WN) + (LN_K/LN) - (YN_K/YN) );         
sLN_P  = sLN*( (WN_P/WN) + (LN_P/LN) - (1/P) - (YN_P/YN) );         
sLN_ZT = sLN*( (WN_ZT/WN) + (LN_ZT/LN) - (YN_ZT/YN) );     
sLN_ZN = sLN*( (WN_ZN/WN) + (LN_ZN/LN) - (YN_ZN/YN) );    

% Sectoral ratios
omegaINYN = IN/YN; 
omegaITYT = IT/YT; 
omegaGTYT =  GT / YT;
omegaGNYN =  GN / (YN);
omegaGN   =  (P*GN) / G;
omegaYT   =  YT / Y;
omegaYN   =  (P*YN)/Y; 
omegaLT   =  LT / L;
omegaLN   =  LN / L; 

% Targeted ratios
omegaC    =  (PC*C) / Y;
omegaNX   =  NX / Y; 
omegaG    =  (GT+P*GN)/Y;
omegaB    = (r*B)/Y; 
omegaKY   = K/Y; 

% Confirmation
cond1  = (1-thetaT)*(YT/KT)-RK;                               
cond2  = P*(1-thetaN)*(YN/KN)-RK;                             
cond3  = thetaT*(YT/LT)-WT;                                   
cond4  = P*thetaN*(YN/LN)-WN;                                 
cond5  = (LT*kT)+(LN*kN)-K;                                   
cond6  = RK-(deltaK+r)*PI; 
cond7  = YN-CN-GN-IN;
cond8  = YT-CT-GT-IT+(r*B);
cond9  = (B-B0) - (wB1*D1) - (wBT*D3) - (wBN*D4);
cond10  = DetJ1 - (nu_1*nu_2);
cond11 = TrJ1 - (nu_1+nu_2); 
cond12 = (LT/LN) - (vartheta/(1-vartheta))*Omega^(-epsilon);
cond13 = (CT/CN) - (varphi/(1-varphi))*P^(phi);
cond14 = (PC*C) - (CT+(P*CN)); 
cond15 = (W*L) - ((WT*LT)+(WN*LN)); 
cond16 = gammaL*(L^(1/sigmaL))*L_T - (lambda*WT); 
cond17 = gammaL*(L^(1/sigmaL))*L_N - (lambda*WN);
cond18 = Y - (PC*C) - G - (PI*I) + (r*B); 
cond19 = Sav; 
cond20 = (PC*C) - (CT+(P*CN)); 
cond21 = (IT/IN) - (varphiI/(1-varphiI))*P^(phiI);
cond22 = (PI*I) - (IT+(P*IN)); 
cond23 = (RK*K) - ((RKT*KT)+(RKN*KN));
cond24 = 1 - (omegaK + omegaL); 
cond25 = omega_13 - omega13; 
cond26 = omega_14 - omega14; 
cond27 = omega_23 - omega23; 
cond28 = omega_24 - omega24; 
cond29 = nu_3 + xiT; 
cond30 = nu_4 + xiN; 

% Define New steady-state values
kT_imlcac = kT; kN_imlcac = kN; P_imlcac = P; LT_imlcac = LT; K_imlcac = K; C_imlcac = C;  
LN_imlcac = LN; L_imlcac  = L; W_imlcac = W; f_imlcac   = f; h_imlcac   = h; 
YT_imlcac = YT; YN_imlcac = YN; Y_imlcac = Y; KT_imlcac  = KT; KN_imlcac  = KN; G_imlcac = G;     
PC_imlcac = PC; alphaC_imlcac = alphaC; CN_imlcac = CN; CT_imlcac = CT;  
GT_imlcac = GT; GN_imlcac = GN; ZT_imlcac = ZT; ZN_imlcac = ZN; Z_imlcac = Z; 
LT_imlcac = LT; LN_imlcac = LN; KT_imlcac = KT; KN_imlcac = KN; WT_imlcac = WT; WN_imlcac = WN; 
Omega_imlcac = Omega; WPC_imlcac = WPC; WTPC_imlcac = WTPC; WNPC_imlcac = WNPC;

YTYN_imlcac = YTYN; LTLN_imlcac = LTLN; IT_imlcac = IT; IN_imlcac = IN; PI_imlcac = PI; 
PIprime_imlcac = PIprime; EI_imlcac = EI; 
CA_imlcac = CA; Sav_imlcac = Sav; NX_imlcac = NX; I_imlcac = I; A_imlcac = A; 
B_imlcac = B; lambda_imlcac  = lambda; RK_imlcac = RK; YR_imlcac = YR; 

omegaL_imlcac = omegaL; omegaK_imlcac = omegaK; omegaI_imlcac = omegaI; omegaINYN_imlcac = omegaINYN;
omegaITYT_imlcac = omegaITYT; omegaGTYT_imlcac = omegaGTYT; omegaGNYN_imlcac = omegaGNYN; omegaGN_imlcac = omegaGN;
omegaYT_imlcac = omegaYT; omegaYN_imlcac = omegaYN; omegaLT_imlcac = omegaLT; omegaLN_imlcac = omegaLN; 
omegaC_imlcac =omegaC; omegaNX_imlcac =omegaNX; omegaG_imlcac =omegaG; omegaB_imlcac =omegaB; omegaKY_imlcac = omegaKY; 
alphaL_imlcac = alphaL; alphaK_imlcac = alphaK; alphaC_imlcac = alphaC; alphaI_imlcac = alphaI; 
omegaYTR_imlcac = omegaYTR; omegaYNR_imlcac = omegaYNR;
sLT_imlcac = sLT; sLN_imlcac = sLN; 
% Steady-State Changes
dC       = C_imlcac - C_0; % Steady-state change of real consumption 
dK       = K_imlcac - K_0; % Steady-state change of real capital 
dL       = L_imlcac - L_0; % Steady-state change of employment 
dP       = P_imlcac - P_0; % Steady-state change of real exchange rate 
dB       = B_imlcac - B_0; % Steady-state change of traded bonds holding 
dlambda  = lambda_imlcac - lambda_0; % Steady-state change of marginal utility of wealth 
dY       = (YT_imlcac+(P_imlcac*YN_imlcac)) - (YT_0+(P_0*YN_0)); % Steady-state change of real GDP 
dY_check = Y_imlcac - Y_0; % Steady-state change of real GDP - Check
dA       = A_imlcac - A_0; % Steady-state change of financial wealth 
dW       = W_imlcac - W_0; % Steady-state change of the wage rate 
dWPC     = WPC_imlcac - WPC_0; % Steady-state change of the real aggregate wage W/PC 
dOmega   = Omega_imlcac - Omega_0; % Steady-state change of the sector wage ratio

dCT   = CT_imlcac - CT_0; % Steady-state change of cT
dCN   = CN_imlcac - CN_0; % Steady-state change of cT
dLT   = LT_imlcac - LT_0; % Steady-state change of real capital 
dLN   = LN_imlcac - LN_0; % Steady-state change of employment 
dKT   = KT_imlcac - KT_0; % Steady-state change of real capital 
dKN   = KN_imlcac - KN_0; % Steady-state change of employment 
dYT   = YT_imlcac - YT_0; % Steady-state change of YT
dYN   = YN_imlcac - YN_0; % Steady-state change of YN
dWT   = WT_imlcac - WT_0; % Steady-state change of WT
dWN   = WN_imlcac - WN_0; % Steady-state change of WN
dWTPC = WTPC_imlcac - WTPC_0; % Steady-state change of WT/PC
dWNPC = WNPC_imlcac - WNPC_0; % Steady-state change of WN/PC
dkT   = kT_imlcac - kT_0; % Steady-state change of kT 
dkN   = kN_imlcac - kN_0; % Steady-state change of kN
dLTLN = LTLN_imlcac - LTLN_0; % Steady-state change of LT/LN
dYTYN = YTYN_imlcac - YTYN_0; % Steady-state change of LT/LN

dZT   = ZT_imlcac - ZT_0; 
dZN   = ZN_imlcac - ZN_0; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
% Solution for investment PI*K, 
EK_1  = PI + (K*omega_21); % Q(t)*K(t) - Q*K = EK1*X1(t) + EK2*X2(t)
EK_T  = (PI*omega_13) + (K*omega_23);
EK_N  = (PI*omega_14) + (K*omega_24);
 
% Solution for the Relative Price of Non tradables P=P(lambda,K,Q,ZT,ZN)
wP_1  = P_K + (P_Q*omega_21); 
wP_T  = (P_K*omega_13) + (P_Q*omega_23) + P_ZT;
wP_N  = (P_K*omega_14) + (P_Q*omega_24) + P_ZN;

% Solution for the Relative Price of tradables PT = fixed
wPT_1 = 0; 
wPT_T = 0;
wPT_N = 0;

% Solution for Q(t)/PI(P(t))
wQPI_1 = (omega_21/PI) - (alphaI/P)*wP_1; 
wQPI_T = (omega_23/PI) - (alphaI/P)*wP_T;
wQPI_N = (omega_24/PI) - (alphaI/P)*wP_N;

% Solution for Consumption C=C(lambda,P)
wC_1 = (C_P*wP_1); 
wC_T = (C_P*wP_T); 
wC_N = (C_P*wP_N); 

% Solution for the Aggregate Wage Index W=W(K,P,ZT,ZN)
wW_1  = W_K + (W_P*wP_1); 
wW_T  = (W_K*omega_13) + (W_P*wP_T) + W_ZT; 
wW_N  = (W_K*omega_14) + (W_P*wP_N) + W_ZN;  

% Solution for the Aggregate Capital Rental Rate RK=R(K,P,ZT,ZN)
wR_1  = R_K + (R_P*wP_1); 
wR_T  = (R_K*omega_13) + (R_P*wP_T) + R_ZT; 
wR_N  = (R_K*omega_14) + (R_P*wP_N) + R_ZN; 

% Solution for the Real Wage W(K,P,ZT,ZN)/PC(P)
wWPC_1 = WPC*( (wW_1/W)-(alphaC/P)*wP_1 ); 
wWPC_T = WPC*( (wW_T/W)-(alphaC/P)*wP_T );
wWPC_N = WPC*( (wW_N/W)-(alphaC/P)*wP_N );

% Solution for the Labor L=L(lambda,W)=L(lambda,K,P,ZT,ZN)
wL_1  = L_W*wW_1; 
wL_T  = L_W*wW_T; ;
wL_N  = L_W*wW_N; 

% Solutions for the Sectoral Labor kj=kj(lambda,K,P,ZT,ZN)
wkT_1  = kT_K + (kT_P*wP_1); 
wkT_T  = (kT_K*omega_13) + (kT_P*wP_T) + kT_ZT;
wkT_N  = (kT_K*omega_14) + (kT_P*wP_N) + kT_ZN; 

wkN_1  = kN_K + (kN_P*wP_1); 
wkN_T  = (kN_K*omega_13) + (kN_P*wP_T) + kN_ZT;
wkN_N  = (kN_K*omega_14) + (kN_P*wP_N) + kN_ZN; 

% Solutions for the Sectoral Labor Lj=Lj(lambda,K,P,ZT,ZN)
wLT_1  = LT_K + (LT_P*wP_1); 
wLT_T  = (LT_K*omega_13) + (LT_P*wP_T) + LT_ZT;
wLT_N  = (LT_K*omega_14) + (LT_P*wP_N) + LT_ZN;

wLN_1  = LN_K + (LN_P*wP_1); 
wLN_T  = (LN_K*omega_13) + (LN_P*wP_T) + LN_ZT;
wLN_N  = (LN_K*omega_14) + (LN_P*wP_N) + LN_ZN;

% Solution for GDP Y=Y(lambda,K,P,ZT,ZN)
wY_1   = Y_K + (Y_P*wP_1);  
wY_T   = (Y_K*omega_13) + (Y_P*wP_T) + Y_ZT;
wY_N   = (Y_K*omega_14) + (Y_P*wP_N) + Y_ZN;

wYR_1  = YT_K + (P_0*YN_K) + (YT_P + (P_0*YN_P))*wP_1;  
wYR_T  = (YT_K + (P_0*YN_K))*omega_13 + (YT_P + (P_0*YN_P))*wP_T + (YT_ZT + (P_0*YN_ZT));
wYR_N  = (YT_K + (P_0*YN_K))*omega_14 + (YT_P + (P_0*YN_P))*wP_N + (YT_ZN + (P_0*YN_ZN));

% Solutions for the Sectoral Output Yj=Yj(lambda,K,P,ZT,ZN)
wYT_1  = YT_K + (YT_P*wP_1); 
wYT_T  = (YT_K*omega_13) + (YT_P*wP_T) + YT_ZT;
wYT_N  = (YT_K*omega_14) + (YT_P*wP_N) + YT_ZN;

wYN_1  = YN_K + (YN_P*wP_1); 
wYN_T  = (YN_K*omega_13) + (YN_P*wP_T) + YN_ZT;
wYN_N  = (YN_K*omega_14) + (YN_P*wP_N) + YN_ZN;

% Solutions for the Sectoral Wages Wj=Wj(K,P,ZT,ZN)
wWT_1  = WT_K + (WT_P*wP_1);                    
wWT_T  = (WT_K*omega_13) + (WT_P*wP_T) + WT_ZT;  
wWT_N  = (WT_K*omega_14) + (WT_P*wP_N) + WT_ZN; 
                                              
wWN_1  = WN_K + (WN_P*wP_1);                    
wWN_T  = (WN_K*omega_13) + (WN_P*wP_T) + WN_ZT; 
wWN_N  = (WN_K*omega_14) + (WN_P*wP_N) + WN_ZN; 

% Solutions for the Real Sectoral Wages Wj(K,P)/PC(P) 
wWTPC_1 = WTPC*( (wWT_1/WT)-(alphaC/P)*wP_1 );
wWTPC_T = WTPC*( (wWT_T/WT)-(alphaC/P)*wP_T );
wWTPC_N = WTPC*( (wWT_N/WT)-(alphaC/P)*wP_N );
                                           
wWNPC_1 = WNPC*( (wWN_1/WN)-(alphaC/P)*wP_1 );
wWNPC_T = WNPC*( (wWN_T/WN)-(alphaC/P)*wP_T );
wWNPC_N = WNPC*( (wWN_N/WN)-(alphaC/P)*wP_N );

% Solution for Omega = WN(K,P)/WT(K,P)
wOmega_1 = Omega*((wWN_1/WN) - (wWT_1/WT)); 
wOmega_T = Omega*((wWN_T/WN) - (wWT_T/WT)); 
wOmega_N = Omega*((wWN_N/WN) - (wWT_N/WT)); 

% Solution for YT(lambda,K,P,ZT,ZN)/YN(lambda,K,P,ZT,ZN)
wYTYN_1 = YTYN*((wYT_1/YT) - (wYN_1/YN));  
wYTYN_T = YTYN*((wYT_T/YT) - (wYN_T/YN));  
wYTYN_N = YTYN*((wYT_N/YT) - (wYN_N/YN));  

% Solution for LT(lambda,K,P,ZT,ZN)/LN(lambda,K,P,ZT,ZN)
wLTLN_1 = LTLN*((wLT_1/LT) - (wLN_1/LN));  
wLTLN_T = LTLN*((wLT_T/LT) - (wLN_T/LN));  
wLTLN_N = LTLN*((wLT_N/LT) - (wLN_N/LN));  

% Solutions for the Real Sectoral Output Yj/YR=(Yj/YR)(lambda,K,P,ZT,ZN)
wYTS_1  = omegaYTR*((wYT_1/YT)-(wYR_1/YR)); 
wYTS_T  = omegaYTR*((wYT_T/YT)-(wYR_T/YR)); 
wYTS_N  = omegaYTR*((wYT_N/YT)-(wYR_N/YR)); 
                                         
wYNS_1  = omegaYNR*((wYN_1/YN)-(wYR_1/YR)); 
wYNS_T  = omegaYNR*((wYN_T/YN)-(wYR_T/YR)); 
wYNS_N  = omegaYNR*((wYN_N/YN)-(wYR_N/YR)); 

% Solutions for the employment shares Lj/L=(Lj/L)(lambda,K,P,ZT,ZN)
wLTS_1  = omegaLT*((wLT_1/LT)-(wL_1/L)); 
wLTS_T  = omegaLT*((wLT_T/LT)-(wL_T/L)); 
wLTS_N  = omegaLT*((wLT_N/LT)-(wL_N/L)); 
                                      
wLNS_1  = omegaLN*((wLN_1/LN)-(wL_1/L)); 
wLNS_T  = omegaLN*((wLN_T/LN)-(wL_T/L)); 
wLNS_N  = omegaLN*((wLN_N/LN)-(wL_N/L)); 

% Solutions for the employment shares sLj=LISj(lambda,K,Q,ZT,ZN) -    
% sLj = Wj*Lj/(Pj*Yj) -                                               
wLIST_1 = sLT_K + (sLT_P*wP_1);                                   
wLIST_T = (sLT_K*omega_13) + (sLT_P*wP_T) + sLT_ZT;               
wLIST_N = (sLT_K*omega_14) + (sLT_P*wP_N) + sLT_ZN;               
                                                                      
wLISN_1 = sLN_K + (sLN_P*wP_1);                                   
wLISN_T = (sLN_K*omega_13) + (sLN_P*wP_T) + sLN_ZT;               
wLISN_N = (sLN_K*omega_14) + (sLN_P*wP_N) + sLN_ZN;   

% Solutions for the relative wages Wj/W: WjW=WjW(lambda,K,Q,ZT,ZN) -
wWTW_1 = (WT/W)*( (wWT_1/WT) - (wW_1/W) ); 
wWTW_T = (WT/W)*( (wWT_T/WT) - (wW_T/W) ); 
wWTW_N = (WT/W)*( (wWT_N/WT) - (wW_N/W) ); 
                                           
wWNW_1 = (WN/W)*( (wWN_1/WN) - (wW_1/W) ); 
wWNW_T = (WN/W)*( (wWN_T/WN) - (wW_T/W) ); 
wWNW_N = (WN/W)*( (wWN_N/WN) - (wW_N/W) );
                                                                      
% Transitional Paths 
time0 = [Tm:Tu:0]; % Span of time t= [-20..0[ 
pathdZT0    = (ZT_0 - ZT_0) + 0*time0;
pathdZN0    = (ZN_0 - ZN_0) + 0*time0;
pathdZ0     = (Z_0 - Z_0) + 0*time0;
pathCY0     = (C_0 - C_0) + 0*time0;
pathdP0     = (P_0 - P_0) + 0*time0;
pathCAY0    = CA_0 + 0*time0;
pathdL0     = (L_0 - L_0) + 0*time0;
pathdLTL0   = (LN_0 - LN_0) + 0*time0;
pathdLNL0   = (LT_0 - LT_0) + 0*time0;
pathIY0     = (I_0 - I_0) + 0*time0;
pathSY0     = CA_0 + 0*time0;
pathdW0     = (W_0 - W_0) + 0*time0;
pathdY0     = (Y_0 - Y_0) + 0*time0;
pathdWT0    = (WT_0 - WT_0) + 0*time0;
pathdWN0    = (WN_0 - WN_0) + 0*time0;
pathdOmega0 = (Omega_0 - Omega_0) + 0*time0;
pathdYTYN0  = (YTYN_0 - YTYN_0) + 0*time0;
pathdLTLN0  = (LTLN_0 - LTLN_0) + 0*time0;
pathdITY0   = (IN_0 - IN_0) + 0*time0;
pathdINY0   = (IT_0 - IT_0) + 0*time0;
pathdWPC0   = (WPC_0 - WPC_0) + 0*time0;
pathdQ0     = (PI_0 - PI_0) + 0*time0; 
pathdR0     = (RK_0 - RK_0) + 0*time0; 
pathdLIST0  = (sLT_0 - sLT_0) + 0*time0;
pathdLISN0  = (sLN_0 - sLN_0) + 0*time0;

time1        = [0:Tu:Tg]; % span of time t = [0..10]
X1           = D1*exp(nu_1*time1); 
XT           = aT*exp(-xiT*time1);
XN           = aN*exp(-xiN*time1);
%%%%%%%%% Transitional paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pathdZT1     = (( (ZT_imlcac-ZT_0) +  XT )/ZT_0)*100;
pathdZN1     = (( (ZN_imlcac-ZN_0) +  XN )/ZN_0)*100;
pathdZ1       = a*( (((ZT_imlcac-ZT_0) + XT)/ZT_0) - b*(((ZN_imlcac-ZN_0) + XN)/ZN_0) )*100; 
pathdQ1      = (((PI_imlcac-PI_0) + (omega_21*X1) + (omega_23*XT) + (omega_23*XT))/PI_0)*100;
pathdP1      = (((P_imlcac-P_0) + (wP_1*X1) + (wP_T*XT) + (wP_N*XN) )/P_0)*100;
pathCY1      = ( PC_0*((C_imlcac-C_0) + (wC_1*X1) + (wC_T*XT) + (wC_N*XN) )/Y_0 )*100;
pathdQPI1    = ( (wQPI_1*X1) + (wQPI_T*XT) + (wQPI_N*XN) )*100;
pathdL1      = (((L_imlcac-L_0)  + (wL_1*X1) + (wL_T*XT) + (wL_N*XN) )/L_0)*100;
pathdLTL1    = ( (1-alphaL_0)*((LT_imlcac-LT_0) + (wLT_1*X1) + (wLT_T*XT) + (wLT_N*XN) )/LT_0)*100;
pathdLNL1    = ( alphaL_0*((LN_imlcac-LN_0) + (wLN_1*X1) + (wLN_T*XT) + (wLN_N*XN) )/LN_0)*100;
pathdkTK1    = ( LT_0*((kT_imlcac-kT_0) + (wkT_1*X1) + (wkT_T*XT) + (wkT_N*XN) )/K_0)*100;
pathdkNK1    = ( LN_0*((kN_imlcac-kN_0) + (wkN_1*X1) + (wkN_T*XT) + (wkN_N*XN) )/K_0)*100;
pathdW1      = (((W_imlcac-W_0) + (wW_1*X1) + (wW_T*XT) + (wW_N*XN) )/W_0)*100;
pathdR1      = (((RK_imlcac-RK_0) + (wR_1*X1) + (wR_T*XT) + (wR_N*XN) )/RK_0)*100;                    
pathdWPC1    = (((WPC_imlcac-WPC_0) + (wWPC_1*X1) + (wWPC_T*XT) + (wWPC_N*XN) )/WPC_0)*100;           
pathdY1      = (((Y_imlcac-Y_0) + (wY_1*X1) + (wY_T*XT) + (wY_N*XN) )/Y_0)*100;                       
pathdYR1     = (((YR_imlcac-Y_0) + (wYR_1*X1) + (wYR_T*XT) + (wYR_N*XN) )/Y_0)*100;                   
pathdYTY1    = (((YT_imlcac-YT_0) + (wYT_1*X1) + (wYT_T*XT) + (wYT_N*XN) )/Y_0)*100;                  
pathdYNY1    = (P_0*((YN_imlcac-YN_0) + (wYN_1*X1) + (wYN_T*XT) + (wYN_N*XN) )/Y_0)*100;            
pathdWT1     = (((WT_imlcac-WT_0) + (wWT_1*X1) + (wWT_T*XT) + (wWT_N*XN) )/WT_0)*100;                 
pathdWN1     = (((WN_imlcac-WN_0) + (wWN_1*X1) + (wWN_T*XT) + (wWN_N*XN) )/WN_0)*100;                 
pathdWTPC1   = (((WTPC_imlcac-WTPC_0) + (wWTPC_1*X1) + (wWTPC_T*XT) + (wWTPC_N*XN) )/WTPC_0)*100;     
pathdWNPC1   = (((WNPC_imlcac-WNPC_0) + (wWNPC_1*X1) + (wWNPC_T*XT) + (wWNPC_N*XN) )/WNPC_0)*100;     
pathdWTW1    = (( ((WT_imlcac/W_imlcac)-(WT_0/W_0)) + (wWTW_1*X1) + (wWTW_T*XT) + (wWTW_N*XN) )/(WT_0/W_0) )*100; 
pathdWNW1    = (( ((WN_imlcac/W_imlcac)-(WN_0/W_0)) + (wWNW_1*X1) + (wWNW_T*XT) + (wWNW_N*XN) )/(WN_0/W_0) )*100; 

pathCAY1     = (( -(nu_1*wB1*X1) + (xiT*wBT*XT) + (xiN*wBN*XN) )/Y_0 )*100;
pathSY1      = (( -(nu_1*wA1*X1) + (xiT*wAT*XT) + (xiN*wAN*XN) )/Y_0 )*100;
pathIY1      = (( (nu_1*EK_1*X1) - (xiT*EK_T*XT) - (xiN*EK_N*XN) )/Y_0)*100; 

pathdOmega1  = (((Omega_imlcac-Omega_0) + (wOmega_1*X1) + (wOmega_T*XT) + (wOmega_N*XN) )/Omega_0)*100; 
pathdYTYN1   = (1/P_0)*( (YTYN_imlcac-YTYN_0) + (wYTYN_1*X1) + (wYTYN_T*XT) + (wYTYN_N*XN) )*100;
pathdLTLN1   = ( (LTLN_imlcac-LTLN_0) + (wLTLN_1*X1) + (wLTLN_T*XT) + (wLTLN_N*XN) )*100;

%pathdLTS1    = ( (omegaLT_imlcac-omegaLT_0) + (wLTS_1*X1) + (wLTS_T*XT) + (wLTS_N*XN) )*100;    
%pathdLNS1    = ( (omegaLN_imlcac-omegaLN_0) + (wLNS_1*X1) + (wLNS_T*XT) + (wLNS_N*XN) )*100; 
pathdLTS1    = (1-alphaL_0)*(( (omegaLT_imlcac-omegaLT_0) + (wLTS_1*X1) + (wLTS_T*XT) + (wLTS_N*XN) )/omegaLT_0)*100;    
pathdLNS1    = alphaL_0*(( (omegaLN_imlcac-omegaLN_0) + (wLNS_1*X1) + (wLNS_T*XT) + (wLNS_N*XN) )/omegaLN_0)*100;  
pathdYTS1    = ( (omegaYTR_imlcac-omegaYT_0) + (wYTS_1*X1) + (wYTS_T*XT) + (wYTS_N*XN) )*100;   
pathdYNS1    = ( (omegaYNR_imlcac-omegaYN_0) + (wYNS_1*X1) + (wYNS_T*XT) + (wYNS_N*XN) )*100;   

pathdLIST1   = ( (sLT_imlcac-sLT_0) + (wLIST_1*X1) + (wLIST_T*XT) + (wLIST_N*XN) )*100;
pathdLISN1   = ( (sLN_imlcac-sLN_0) + (wLISN_1*X1) + (wLISN_T*XT) + (wLISN_N*XN) )*100;

pathdPT1     = (((P_0-P_0) + (wPT_1*X1) + (wPT_T*XT) + (wPT_N*XN) )/P_0)*100; % TOT

% Temporal paths over entire period
timeperm = [time0 time1];
pathdZT_imlcac    = [pathdZT0  pathdZT1];
pathdZN_imlcac    = [pathdZN0  pathdZN1];
pathdZ_imlcac     = [pathdZ0   pathdZ1];
pathdQ_imlcac     = [pathdQ0  pathdQ1];
pathdQPI_imlcac   = [pathdQ0  pathdQPI1];
pathdP_imlcac     = [pathdP0  pathdP1]; 
pathdPT_imlcac    = [pathdP0  pathdPT1]; 
pathCY_imlcac     = [pathCY0  pathCY1];                                             
pathdL_imlcac     = [pathdL0  pathdL1];                
pathdLTL_imlcac   = [pathdLTL0 pathdLTL1];             
pathdLNL_imlcac   = [pathdLNL0 pathdLNL1]; 
pathdkTK_imlcac   = [pathdLTL0 pathdkTK1];             
pathdkNK_imlcac   = [pathdLNL0 pathdkNK1]; 
pathdW_imlcac     = [pathdW0 pathdW1]; 
pathdR_imlcac     = [pathdR0 pathdR1]; 
pathdWPC_imlcac   = [pathdWPC0 pathdWPC1]; 
pathdY_imlcac     = [pathdY0 pathdY1]; 
pathdYR_imlcac    = [pathdY0 pathdYR1];
pathdYTY_imlcac   = [pathdY0 pathdYTY1];               
pathdYNY_imlcac   = [pathdY0 pathdYNY1];               
pathdWT_imlcac    = [pathdWT0  pathdWT1];              
pathdWN_imlcac    = [pathdWN0  pathdWN1]; 
pathdWTPC_imlcac  = [pathdWT0 pathdWTPC1];
pathdWNPC_imlcac  = [pathdWN0 pathdWNPC1];
pathdWTW_imlcac   = [pathdWT0 pathdWTW1];   
pathdWNW_imlcac   = [pathdWN0 pathdWNW1];   

pathIY_imlcac     = [pathIY0  pathIY1];                        
pathCAY_imlcac    = [pathCAY0 pathCAY1];               
pathSY_imlcac     = [pathSY0  pathSY1];

pathdOmega_imlcac = [pathdOmega0 pathdOmega1];         
pathdYTYN_imlcac  = [pathdYTYN0 pathdYTYN1];           
pathdLTLN_imlcac  = [pathdLTLN0 pathdLTLN1];

pathdLTS_imlcac   = [pathdLTL0 pathdLTS1];             
pathdLNS_imlcac   = [pathdLNL0 pathdLNS1];
pathdYTS_imlcac   = [pathdY0 pathdYTS1];             
pathdYNS_imlcac   = [pathdY0 pathdYNS1];

pathdLIST_imlcac  = [pathdLIST0 pathdLIST1];             
pathdLISN_imlcac  = [pathdLISN0 pathdLISN1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Dynamic and steadty-state effects of a Permanent increase in ZT/ZN %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Impact Effects of an Unanticipated Rise in dZT(0) = aT and dZN(0) = aN
X10           = D1; 
XT0           = aT;
XN0           = aN;

pathZTtime0       = ZT_imlcac + XT0;  % initial level of TFP in the traded sector                                                                    
pathZNtime0       = ZN_imlcac + XN0;  % initial level of TFP in the non traded sector                                                                
pathQtime0        = PI_imlcac + (omega_21*X10) + (omega_23*XT0) + (omega_24*XN0);  % initial level of the shadow value of investment                                                       
pathCYtime0       = C_imlcac + (wC_1*X10) + (wC_T*XT0) + (wC_N*XN0);  % initial level of real consumption                                            
pathLtime0        = L_imlcac + (wL_1*X10) + (wL_T*XT0) + (wL_N*XN0);  % initial level of employment                                                  
pathLTtime0       = LT_imlcac + (wLT_1*X10) + (wLT_T*XT0) + (wLT_N*XN0);  % initial level of employment in sector T                                  
pathLNtime0       = LN_imlcac + (wLN_1*X10) + (wLN_T*XT0) + (wLN_N*XN0);  % initial level of employment in sector N                                  
pathPtime0        = P_imlcac + (wP_1*X10) + (wP_T*XT0) + (wP_N*XN0);  % initial level of real exchange rate                                          
pathWtime0        = W_imlcac + (wW_1*X10) + (wW_T*XT0) + (wW_N*XN0);  % initial level of the wage rate                                               
pathWPCtime0      = WPC_imlcac + (wWPC_1*X10) + (wWPC_T*XT0) + (wWPC_N*XN0);  % initial level of W/PC                                                
pathYtime0        = Y_imlcac + (wY_1*X10) + (wY_T*XT0) + (wY_N*XN0);  % initial level of Y                                                           
pathYRtime0       = YR_imlcac + (wYR_1*X10) + (wYR_T*XT0) + (wYR_N*XN0);  % initial level of Y once non tradable inflation is controlled for         
pathYTtime0       = YT_imlcac + (wYT_1*X10) + (wYT_T*XT0) + (wYT_N*XN0);  % initial level of YT                                                      
pathYNtime0       = YN_imlcac + (wYN_1*X10) + (wYN_T*XT0) + (wYN_N*XN0);  % initial level of YN                                                      
pathWTtime0       = WT_imlcac + (wWT_1*X10) + (wWT_T*XT0) + (wWT_N*XN0);  % initial level of WT                                                      
pathWNtime0       = WN_imlcac + (wWN_1*X10) + (wWN_T*XT0) + (wWN_N*XN0);  % initial level of WN                                                      
pathWTPCtime0     = WTPC_imlcac + (wWTPC_1*X10) + (wWTPC_T*XT0) + (wWTPC_N*XN0);  % initial level of WTPC                                            
pathWNPCtime0     = WNPC_imlcac + (wWNPC_1*X10) + (wWNPC_T*XT0) + (wWNPC_N*XN0);  % initial level of WNPC   
pathdkTKtime0     = kT_imlcac + (wkT_1*X10) + (wkT_T*XT0) + (wkT_N*XN0);
pathdkNKtime0     = kN_imlcac + (wkN_1*X10) + (wkN_T*XT0) + (wkN_N*XN0);
pathWTWtime0      = (WT_imlcac/W_imlcac) + (wWTW_1*X10) + (wWTW_T*XT0) + (wWTW_N*XN0);  % initial level of WT/W 
pathWNWtime0      = (WN_imlcac/W_imlcac) + (wWNW_1*X10) + (wWNW_T*XT0) + (wWNW_N*XN0);  % initial level of WN/W 
                                                                                                                                                    
pathOmegatime0    = Omega_imlcac + (wOmega_1*X10) + (wOmega_T*XT0) + (wOmega_N*XN0);  % initial level of the sector wage ratio                       
pathYTYNtime0     = YTYN_imlcac + (wYTYN_1*X10) + (wYTYN_T*XT0) + (wYTYN_N*XN0);  % initial level of ratio YT/YN                                     
pathLTLNtime0     = LTLN_imlcac + (wLTLN_1*X10) + (wLTLN_T*XT0) + (wLTLN_N*XN0);  % initial level of ratio LT/LN                                     
                                                                                                                                                    
pathLTStime0      =  omegaLT_imlcac + (wLTS_1*X10) + (wLTS_T*XT0) + (wLTS_N*XN0);                                                                    
pathLNStime0      =  omegaLN_imlcac + (wLNS_1*X10) + (wLNS_T*XT0) + (wLNS_N*XN0);                                                                    
pathYTStime0      =  omegaYTR_imlcac + (wYTS_1*X10) + (wYTS_T*XT0) + (wYTS_N*XN0);                                                                   
pathYNStime0      =  omegaYNR_imlcac + (wYNS_1*X10) + (wYNS_T*XT0) + (wYNS_N*XN0);   

pathLISTtime0      =  sLT_imlcac + (wLIST_1*X10) + (wLIST_T*XT0) + (wLIST_N*XN0);      
pathLISNtime0      =  sLN_imlcac + (wLISN_1*X10) + (wLISN_T*XT0) + (wLISN_N*XN0);      
                                                                                                                                                    
pathYtime0_check  = YT_imlcac + (P_imlcac*YN_imlcac) + ((wYT_1*X10) + (wYT_T*XT0) + (wYT_N*XN0)) + (P_imlcac)*((wYN_1*X10) + (wYN_T*XT0) + (wYN_N*XN0)) + (YN_imlcac)*((wP_1*X10) + (wP_T*XT0) + (wP_N*XN0));  % initial level of Y

dZTtime0_imlcac      = ((pathZTtime0 - ZT_0)/ZT_0)*100;  % initial response of TFP in the traded sector
dZNtime0_imlcac      = ((pathZNtime0 - ZN_0)/ZN_0)*100;  % initial response of TFP in the non traded sector
dZtime0_imlcac       = (a*((pathZTtime0 - ZT_0)/ZT_0) - b*((pathZNtime0 - ZN_0)/ZN_0))*100;  % initial response of the productivity differential
dCYtime0_imlcac      = (PC_0*(pathCYtime0 - C_0)/Y_0)*100;  % initial response of real consumption 
dLtime0_imlcac       = ((pathLtime0 - L_0)/L_0)*100; % initial response of employment
dLTtime0_imlcac      = ((1-alphaL_0)*(pathLTtime0 - LT_0)/LT_0)*100; % initial response of employment in sector T 
dLNtime0_imlcac      = (alphaL_0*(pathLNtime0 - LN_0)/LN_0)*100; % initial response of employment in sector N 
dLTLNtime0_imlcac    = (pathLTLNtime0 - LTLN_0)*100; % initial response of ratio LT/LN 
dPtime0_imlcac       = ((pathPtime0 - P_0)/P_0)*100; % initial response of real exchange rate
dWtime0_imlcac       = ((pathWtime0 - W_0)/W_0)*100; % initial response of W 
dWPCtime0_imlcac     = ((pathWPCtime0 - WPC_0)/WPC_0)*100; % initial response of W/PC 
dYtime0_imlcac       = ((pathYtime0 - Y_0)/Y_0)*100; % initial response of Y
dYRtime0_imlcac      = ((pathYRtime0 - Y_0)/Y_0)*100; % initial response of real GDP 
dYTtime0_imlcac      = ((pathYTtime0 - YT_0)/Y_0)*100; % initial response of YT
dYNtime0_imlcac      = (P_0*(pathYNtime0 - YN_0)/Y_0)*100; % initial response of YN
dYTYNtime0_imlcac    = (1/P_0)*((pathYTYNtime0 - YTYN_0))*100; % initial response of ratio YT/YN 
dWTtime0_imlcac      = ((pathWTtime0 - WT_0)/WT_0)*100; % initial response of wage in sector T 
dWNtime0_imlcac      = ((pathWNtime0 - WN_0)/WN_0)*100; % initial response of wage in sector N 
dWTPCtime0_imlcac    = ((pathWTPCtime0 - WTPC_0)/WTPC_0)*100; % initial response of real wage in sector T 
dWNPCtime0_imlcac    = ((pathWNPCtime0 - WNPC_0)/WNPC_0)*100; % initial response of real wage in sector N 
dOmegatime0_imlcac   = ((pathOmegatime0 - Omega_0)/Omega_0)*100; % initial response of the sector wage ratio
dYtime0_check_imlcac = ((pathYtime0_check - Y_0)/Y_0)*100; % initial response of Y - Check with sectoral output responses
dkTKtime0_imlcac     = (LT_0*(pathdkTKtime0-kT_0)/K_0)*100;
dkNKtime0_imlcac     = (LN_0*(pathdkNKtime0-kN_0)/K_0)*100;
dPTtime0_imlcac      = ((P_0 - P_0)/P_0)*100; % initial response of TOT
dPNtime0_imlcac      = ((pathPtime0 - P_0)/P_0)*100; % initial response of the relative price of non tradables
dLISTtime0_imlcac    = (pathLISTtime0-sLT_0)*100;
dLISNtime0_imlcac    = (pathLISNtime0-sLN_0)*100;
dWTWtime0_imlcac     = ((pathWTWtime0 - (WT_0/W_0))/(WT_0/W_0))*100; % initial response of WT/W 
dWNWtime0_imlcac     = ((pathWNWtime0 - (WN_0/W_0))/(WN_0/W_0))*100; % initial response of WN/W 

dCAYtime0_imlcac     = (( -(nu_1*wB1*X10) + (xiT*wBT*XT0) + (xiN*wBN*XN0) )/Y_0 )*100; % initial response of current account dot{B}(0)
dSYtime0_imlcac      = (( -(nu_1*wA1*X10) + (xiT*wAT*XT0) + (xiN*wAN*XN0) )/Y_0 )*100; % initial response of saving dot{A}(0)
dIYtime0_imlcac      = (( (nu_1*EK_1*X10) - (xiT*EK_T*XT0) - (xiN*EK_N*XN0) )/Y_0)*100; % initial response of investment dot{Q*K}(0)

dCAYtime0_imlcac_check = dSYtime0_imlcac - dIYtime0_imlcac; 

%dLTStime0_imlcac     = (pathLTStime0-omegaLT_0)*100; % Initial response of LT/L
%dLNStime0_imlcac     = (pathLNStime0-omegaLN_0)*100; % Initial response of LN/L
dLTStime0_imlcac     = ((pathLTStime0-omegaLT_0)/omegaLT_0)*(1-alphaL_0)*100; % Initial response of LT/L
dLNStime0_imlcac     = ((pathLNStime0-omegaLN_0)/omegaLN_0)*alphaL_0*100; % Initial response of LN/L
dYTStime0_imlcac     = (pathYTStime0-omegaYT_0)*100; % Initial response of YT/Y
dYNStime0_imlcac     = (pathYNStime0-omegaYN_0)*100; % Initial response of YN/Y

% Changes at t=10                                                                                                             
hatt        = 10; % span of time t = [0..10]                                                                                  
X1_10           = D1*exp(nu_1*hatt);                                                                                          
XT_10          = aT*exp(-xiT*hatt);                                                                                           
XN_10          = aN*exp(-xiN*hatt);                                                                                           
                                                                                                                                                                                                                                                          
pathLTtime10     = LT_imlcac + (wLT_1*X1_10) + (wLT_T*XT_10) + (wLT_N*XN_10);  %  level of employment in sector T             
pathLNtime10     = LN_imlcac + (wLN_1*X1_10) + (wLN_T*XT_10) + (wLN_N*XN_10);  %  level of employment in sector N             
pathYTtime10     = YT_imlcac + (wYT_1*X1_10) + (wYT_T*XT_10) + (wYT_N*XN_10);  %  level of YT                                 
pathYNtime10     = YN_imlcac + (wYN_1*X1_10) + (wYN_T*XT_10) + (wYN_N*XN_10);  %  level of YN                                                                
pathPtime10      = P_imlcac + (wP_1*X1_10) + (wP_T*XT_10) + (wP_N*XN_10);  %  level of  PN                                    
pathLTStime10    = omegaLT_imlcac + (wLTS_1*X1_10) + (wLTS_T*XT_10) + (wLTS_N*XN_10);  % Tome traded labor sTare              
pathYTStime10    = omegaYTR_imlcac + (wYTS_1*X1_10) + (wYTS_T*XT_10) + (wYTS_N*XN_10); % Tome traded output sTare             
pathdkTKtime10   = kT_imlcac + (wkT_1*X1_10) + (wkT_T*XT_10) + (wkT_N*XN_10);                                                 
pathdkNKtime10   = kN_imlcac + (wkN_1*X1_10) + (wkN_T*XT_10) + (wkN_N*XN_10);                                                 
pathLISTtime10   = sLT_imlcac + (wLIST_1*X1_10) + (wLIST_T*XT_10) + (wLIST_N*XN_10);  % Tome traded labor income sTare        
pathLISNtime10   = sLN_imlcac + (wLISN_1*X1_10) + (wLISN_T*XT_10) + (wLISN_N*XN_10);  % Non traded labor income sTare         
pathWTWtime10    = (WT_imlcac/W_imlcac) + (wWTW_1*X1_10) + (wWTW_T*XT_10) + (wWTW_N*XN_10);  % level of WT/W                  
pathWNWtime10    = (WN_imlcac/W_imlcac) + (wWNW_1*X1_10) + (wWNW_T*XT_10) + (wWNW_N*XN_10);  % level of WN/W                  
                                                                                                                              
dLTtime10_imlcac      = ((1-alphaL_0)*(pathLTtime10 - LT_0)/LT_0)*100; %  response of employment in sector T                  
dLNtime10_imlcac      = (alphaL_0*(pathLNtime10 - LN_0)/LN_0)*100; %  response of employment in sector N                      
dYTtime10_imlcac      = (PT_0*(pathYTtime10 - YT_0)/Y_0)*100; %  response of YT                                               
dYNtime10_imlcac      = (PN_0*(pathYNtime10 - YN_0)/Y_0)*100; % response of YN at time t=10 in % of GDP                       
dPTtime10_imlcac      = ((PT_0 - PT_0)/PT_0)*100; %  response of PT                                                   
dPtime10_imlcac       = ((pathPtime10 - P_0)/P_0)*100; %  response of PN/PT                                                   
dLTStime10_imlcac     = ((pathLTStime10-omegaLT_0)/omegaLT_0)*(1-alphaL_0)*100; %  response of LT/L                           
dYTStime10_imlcac     = (pathYTStime10-omegaYT_0)*100; %  response of YT/Y                                                    
dkTKtime10_imlcac     = (LT_0*(pathdkTKtime10-kT_0)/K_0)*100;                                                                 
dkNKtime10_imlcac     = (LN_0*(pathdkNKtime10-kN_0)/K_0)*100;                                                                 
dLISTtime10_imlcac    = (pathLISTtime10-sLT_0)*100;                                                                           
dLISNtime10_imlcac    = (pathLISNtime10-sLN_0)*100;                                                                           
dWTWtime10_imlcac     = ((pathWTWtime0 - (WT_0/W_0))/(WT_0/W_0))*100; % response of WT/W                                      
dWNWtime10_imlcac     = ((pathWNWtime0 - (WN_0/W_0))/(WN_0/W_0))*100; % response of WN/W                                      
                                                                                                                              
% Steady-state changes and impact effects - scaled to their initial values 
hatlambda_imlcac       = (dlambda/lambda_0)*100; 
dCoverY_imlcac         = ((PC_0*dC)/Y_0)*100; % Rate of change of the real consumption
hatZN_imlcac           = (dZN/ZN_0)*100; % Rate of change of the TFP in the non traded sector
hatZT_imlcac           = (dZT/ZT_0)*100; % Rate of change of the TFP in the traded sector
hatZ_imlcac            = (a*(dZT/ZT_0) - b*(dZN/ZN_0)); % Rate of change of the productivity differential
hatL_imlcac            = (dL/L_0)*100; % Rate of change of employment
hatK_imlcac            = (dK/K_0)*100; % Rate of change of the stock of foreign assets
dLToverL_imlcac        = (dLT/L_0)*100; % Rate of change of LT
dLNoverL_imlcac        = (dLN/L_0)*100; % Rate of change of LN
dLTLN_imlcac           =  dLTLN*100; %  Change of LT/LN
hatP_imlcac            = (dP/P_0)*100; % Rate of change of the real exchange rate
hatPN_imlcac           = (dP/P_0)*100; % Rate of change of the relative price of non tradables
hatPT_imlcac           = ((dP-dP)/P_0)*100; % Rate of change of the TOT
dBoverY_imlcac         = (dB/Y_0)*100; % Rate of change of the stock of foreign assets
dAoverY_imlcac         = (dA/Y_0)*100; % Rate of change of the stock of financial assets
hatW_imlcac            = (dW/W_0)*100; % Rate of change of wage
hatWPC_imlcac          = (dWPC/WPC_0)*100; % Rate of change of Real Aggregate Wage W/pc
hatY_imlcac            = (dY/Y_0)*100; % Rate of change of GDP
hatYR_imlcac           = ((YR_imlcac-Y_0)/Y_0)*100; % Rate of change of Real GDP
hatY_check_imlcac      = (dY_check/Y_0)*100; % Rate of change of output
dYToverY_imlcac        = (dYT/Y_0)*100; % Rate of change of YT
dYNoverY_imlcac        = ((P_0*dYN)/Y_0)*100; % Rate of change of YN
dYTYN_imlcac           = (dYTYN)*100; % Rate of change of YT/YN
hatWT_imlcac           = (dWT/WT_0)*100; % Rate of change of WT
hatWN_imlcac           = (dWN/WN_0)*100; % Rate of change of WN
hatOmega_imlcac        = (dOmega/Omega_0)*100; % Rate of change of omega
hatWTPC_imlcac         = (dWTPC/WTPC_0)*100; % Rate of change of WT/PC
hatWNPC_imlcac         = (dWNPC/WNPC_0)*100; % Rate of change of WN/PC
dkT_imlcac             = LT_0*(dkT/K_0)*100; % Rate of change of kT
dkN_imlcac             = LN_0*(dkN/K_0)*100; % Rate of change of kN
domegaLT_imlcac        = (omegaLT_imlcac-omegaLT_0)*100; % change in  the labor share of T
domegaLN_imlcac        = (omegaLN_imlcac-omegaLN_0)*100; % change in the labor share of NT
domegaYTS_imlcac       = (omegaYTR_imlcac-omegaYT_0)*100; % change in the output share of T
domegaYNS_imlcac       = (omegaYNR_imlcac-omegaYN_0)*100; % change in the output share of NT
dLIST_imlcac           = (sLT_imlcac-sLT_0)*100; % Change in the labor income share T
dLISN_imlcac           = (sLN_imlcac-sLN_0)*100; % Change in the labor income share N
dWTW_imlcac            = (((WT_imlcac/W_imlcac)-(WT_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage T   
dWNW_imlcac            = (((WN_imlcac/W_imlcac)-(WN_0/W_0))/((WT_0/W_0)))*100; % Change in the relative wage N   


disp(' ');
disp('-------------------------------------------------------------------------- ');
disp('                    Final Steady State with kT > kN');
disp('                           The Benchmark: ');
disp('-------------------------------------------------------------------------- ');
disp(' ');
disp(' ');
disp('The structural parameters (benchmark)');
disp('The structural parameters (benchmark)');
disp(sprintf('thetaT  : %5.2f   thetaN   : %5.2f',thetaT,thetaN));
disp(sprintf('sigmaC  : %5.2f   phi      : %5.2f  varphi : %5.2f',sigmaC,phi,varphi));
disp(sprintf('sigmaL  : %5.2f   gamma    : %5.2f ',sigmaL,gammaL));
disp(sprintf('epsilon : %5.2f   vartheta : %5.2f',epsilon,vartheta));
disp(sprintf('K0      : %5.2f   B0       : %5.2f',K0,B0));
disp(sprintf('r       : %5.2f   deltaK   : %5.2f',r,deltaK));
disp(sprintf('ZT      : %5.2f   ZN       : %5.2f',ZT,ZN));
disp(sprintf('a       : %5.2f   b        : %5.2f  Z      : %5.2f',a,b,Z));
disp(sprintf('GT      : %5.2f   GN       : %5.2f  G      : %5.2f',GT,GN,G));
disp(' ');

disp(' ');
disp('The production side (benchmark)');
disp(sprintf('kT       : %9.3f    kN   : %9.3f',kT,kN));
disp(sprintf('LT       : %9.3f    LN   : %9.3f',LT,LN));
disp(sprintf('KT       : %9.3f    KN   : %9.3f',KT,KN));
disp(sprintf('YT       : %9.3f    YN   : %9.3f',YT,YN));
disp(sprintf('Y        : %9.3f   ',Y));
disp(sprintf('P        : %9.3f   ',P));
disp(sprintf('W        : %9.3f   ',W));
disp(sprintf('RK       : %9.3f   ',RK));
disp(sprintf('L        : %9.3f   ',L));
disp(sprintf('L_check  : %9.3f   ',L_check));
disp(sprintf('alphaL   : %9.3f   ',alphaL));

disp(' ');
disp('The demand side (benchmark)');
disp(sprintf('C        :   %7.3f   C_check : %9.3f',C,C_check));
disp(sprintf('PC       :   %7.3f    alphac : %9.3f',PC,alphaC));
disp(sprintf('CT       :   %7.3f    CN     : %9.3f',CT,CN));

disp('The demand side (benchmark)');
disp(sprintf('I        :   %7.3f   I_check : %9.3f',I,I_check));
disp(sprintf('PI       :   %7.3f    alphaI : %9.3f',PI,alphaI));
disp(sprintf('IT       :   %7.3f    IN     : %9.3f',IT,IN));
disp(sprintf('EI       :   %7.3f    PIprime: %9.3f',EI,PIprime));

disp(' ');
disp('sector N');
disp(sprintf('Gross output (YN)  : %9.3f',YN));
disp(sprintf('WN                 : %9.3f',WN));
disp(sprintf('Profit             : %9.10f',PiN));

disp('sector T');
disp(sprintf('Gross output (YT)  : %9.3f',YT));
disp(sprintf('WT                 : %9.3f',WT));
disp(sprintf('Profit             : %9.10f',PiT));


disp('Relative Price P=P(lambda,K,Q,GN)');
disp(sprintf('PsiP     :   %7.3f ',PsiP));
disp(sprintf('P_K      :   %7.3f    P_Q    : %9.3f',P_K,P_Q));
disp(sprintf('P_ZT     :   %7.3f    P_ZN   : %9.3f',P_ZT,P_ZN));

disp('Linearization');
disp(sprintf('R_K       : %5.4f   R_P       : %5.4f',R_K,R_P));
disp(sprintf('R_ZT      :  %5.4f  R_ZN      : %5.4f',R_ZT,R_ZN));
disp(sprintf('PsiP      :  %5.4f  P_K       : %5.4f   P_Q     : %5.4f',PsiP,P_K,P_Q));
disp(sprintf('P_ZT      :  %5.4f  P_ZN      : %5.4f',P_ZT,P_ZN));
disp(sprintf('v_P       :  %5.4f  v_Q       : %5.4f',v_P,v_Q));
disp(sprintf('Upsilon_K :  %5.4f  Upsilon_P : %5.4f',Upsilon_K,Upsilon_P));
disp(sprintf('Sigma_K   :  %5.4f  Sigma_P   : %5.4f   Sigma_Q : %5.4f',Sigma_K,Sigma_P,Sigma_Q));
disp(sprintf('B_K       :  %5.4f  B_Q       : %5.4f',B_K,B_Q));

disp(' ');
disp('Eigenvalues and Eigenvectors');
disp(sprintf('x11        :   %5.6f  x12        : %5.6f',x11,x12));
disp(sprintf('x21        :   %5.6f  x22        : %5.6f',x21,x22));
disp(sprintf('nu1        :   %5.6f  nu2        : %5.6f',nu_1,nu_2));
disp(sprintf('nu3        :   %5.6f  nu4        : %5.6f',nu_3,nu_4));
disp(sprintf('N1         :   %5.6f    H1       : %5.6f',N1,H1));
disp(sprintf('TrJ        :   %5.6f  DetJ       : %5.6f',TrJ,DetJ));
disp(sprintf('TrJ1        :   %5.6f  DetJ1     : %5.6f',TrJ1,DetJ1));

disp('Eigenvectors');
disp(sprintf('omega11    :   %5.6f  omega12    : %5.6f',omega_11,omega_12));
disp(sprintf('omega21    :   %5.6f  omega22    : %5.6f',omega_21,omega_22));
disp(sprintf('omega13    :   %5.6f  omega14    : %5.6f',omega_13,omega_14));
disp(sprintf('omega23    :   %5.6f  omega24    : %5.6f',omega_23,omega_24));
disp(sprintf('omega31    :   %5.6f  omega32    : %5.6f',omega_31,omega_32));
disp(sprintf('omega41    :   %5.6f  omega42    : %5.6f',omega_41,omega_42));
disp(sprintf('omega33    :   %5.6f  omega34    : %5.6f',omega_33,omega_34));
disp(sprintf('omega43    :   %5.6f  omega44    : %5.6f',omega_43,omega_44));

disp('solutions at time t = 0 X10 X20');
disp(sprintf('X10       :   %5.3f  X20     : %5.3f XN0   : %5.3f',X10,XT0,XN0));
disp(sprintf('D1        :   %5.3f  D3      : %5.3f D4    : %5.3f',D1,D3,D4));

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT,omegaYN));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT,omegaLN));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC,omegaNX));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI,omegaG));

disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT,omegaGNYN,omegaGN));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN,omegaITYT,omegaB));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL,alphaK));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI,alphaC));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL,omegaK));
disp(sprintf('K/Y       :  %5.3f',omegaKY));
disp(' ');
disp(sprintf('Marginal product of KT = RT       : %9.16f   ',cond1));
disp(sprintf('Marginal product of KN = RN       : %9.16f   ',cond2));
disp(sprintf('Marginal product of LT = WT       : %9.16f   ',cond3));
disp(sprintf('Marginal product of LN = WN       : %9.16f   ',cond4));
disp(sprintf('Resource contraint for capital    : %9.16f   ',cond5));
disp(sprintf('Arbitrage condition               : %9.16f   ',cond6));
disp(sprintf('Market clearing condition good N  : %9.16f   ',cond7));
disp(sprintf('Market clearing condition good T  : %9.16f   ',cond8));
disp(sprintf('Intertemporal solvency constraint : %9.16f   ',cond9));
disp(sprintf('Det J    - (nu1*nu2)              : %9.16f   ',cond10));
disp(sprintf('TrJ      - (nu1+nu2)              : %9.16f   ',cond11));
disp(sprintf('Relative labor  LT/LN             : %9.16f   ',cond12));
disp(sprintf('relative consumption  CT/CN       : %9.16f   ',cond13));
disp(sprintf('Consumption expenditure PC*C      : %9.16f   ',cond14));
disp(sprintf('Labor income W*L                  : %9.16f   ',cond15));
disp(sprintf('FOC -V_L*(dL/dLT) = lambda*WT     : %9.16f   ',cond16));
disp(sprintf('FOC -V_L*(dL/dLN) = lambda*WN     : %9.16f   ',cond17));
disp(sprintf('Global market clearing condition  : %9.16f   ',cond18));
disp(sprintf('Private Savings                   : %9.16f   ',cond19));
disp(sprintf('Consumption expenditure check     : %9.16f   ',cond20));
disp(sprintf('Relative investment IT/IN         : %9.16f   ',cond21));
disp(sprintf('Investment expenditure check      : %9.16f   ',cond22));
disp(sprintf('Capital income R*K                : %9.16f   ',cond23));
disp(sprintf('omegaK + omegaL = 1               : %9.16f   ',cond24));
disp(sprintf('omega_13 - omega13                : %9.16f   ',cond25));
disp(sprintf('omega_14 - omega14                : %9.16f   ',cond26));
disp(sprintf('omega_23 - omega23                : %9.16f   ',cond27));
disp(sprintf('omega_24 - omega24                : %9.16f   ',cond28));
disp(sprintf('nu_3 + xiT                        : %9.16f   ',cond29));
disp(sprintf('nu_4 + xiN                        : %9.16f   ',cond30));



disp('-------------------------------------------------------------------------------------------------------- ');
disp('                       Increase in gN : Impact and Steady State Changes (after a rise in gN)     ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('-------------------------------------------------------------------------------------------------------- ');
disp('                               |     Temporary   |');
disp('-------------------------------------------------------------------------------------------------------- ');
disp(' ');

disp(' ');
disp(' Steady State Deviations ( = (x-x0)/x0 where x0 is the value of x at the initial steady state)  ');
disp(sprintf('hatlambda_imlcac        :         |           |%10.3f',hatlambda_imlcac));
disp(sprintf('dZoverZ_imlcac          :         |           |%10.3f',hatZ_imlcac));
disp(sprintf('dZToverZT_imlcac        :         |           |%10.3f',hatZT_imlcac));
disp(sprintf('dZNoverZN_imlcac        :         |           |%10.3f',hatZN_imlcac));
disp(sprintf('dCoverY_imlcac          :         |           |%10.3f',dCoverY_imlcac));
disp(sprintf('dLoverL_imlcac          :         |           |%10.3f',hatL_imlcac));
disp(sprintf('dYoverY_imlcac          :         |           |%10.3f',hatY_imlcac));
disp(sprintf('dYoverY_check_imlcac    :         |           |%10.3f',hatY_check_imlcac));
disp(sprintf('dYRoverY_imlcac         :         |           |%10.3f',hatYR_imlcac));
disp(sprintf('dKoverK_imlcac          :         |           |%10.3f',hatK_imlcac));
disp(sprintf('dLToverL_imlcac         :         |           |%10.3f',dLToverL_imlcac));
disp(sprintf('dLNover_imlcac          :         |           |%10.3f',dLNoverL_imlcac));
disp(sprintf('dLTLN_imlcac            :         |           |%10.3f',dLTLN_imlcac));
disp(sprintf('dYToverY_imlcac         :         |           |%10.3f',dYToverY_imlcac));
disp(sprintf('dYNoverY_imlcac         :         |           |%10.3f',dYNoverY_imlcac));
disp(sprintf('dYTYN_imlcac            :         |           |%10.3f',dYTYN_imlcac));
disp(sprintf('hatP_imlcac             :         |           |%10.3f',hatP_imlcac));
disp(sprintf('hatPT_imlcac            :         |           |%10.3f',hatPT_imlcac));
disp(sprintf('hatPN_imlcac            :         |           |%10.3f',hatPN_imlcac));
disp(sprintf('dBoverY_imlcac          :         |           |%10.3f',dBoverY_imlcac));
disp(sprintf('dAoverY_imlcac          :         |           |%10.3f',dAoverY_imlcac));
disp(sprintf('dWoverW_imlcac          :         |           |%10.3f',hatW_imlcac));
disp(sprintf('dWPCoverWPC_imlcac      :         |           |%10.3f',hatWPC_imlcac));
disp(sprintf('dWToverWT_imlcac        :         |           |%10.3f',hatWT_imlcac));
disp(sprintf('dWNoverWN_imlcac        :         |           |%10.3f',hatWN_imlcac));
disp(sprintf('hatOmega_imlcac         :         |           |%10.3f',hatOmega_imlcac));
disp(sprintf('dWTPCoverWTPC_imlcac    :         |           |%10.3f',hatWTPC_imlcac));
disp(sprintf('dWNPCoverWNPC_imlcac    :         |           |%10.3f',hatWNPC_imlcac));
disp(sprintf('dkToverK_imlcac         :         |           |%10.3f',dkT_imlcac));
disp(sprintf('dkNoverK_imlcac         :         |           |%10.3f',dkN_imlcac));
disp(sprintf('domegaLT_imlcac         :         |           |%10.3f',domegaLT_imlcac));
disp(sprintf('domegaLN_imlcac         :         |           |%10.3f',domegaLN_imlcac));
disp(sprintf('domegaYTS_imlcac        :         |           |%10.3f',domegaYTS_imlcac));
disp(sprintf('domegaYNS_imlcac        :         |           |%10.3f',domegaYNS_imlcac));
disp(sprintf('dLIST_imlcac            :         |           |%10.3f',dLIST_imlcac));   
disp(sprintf('dLISN_imlcac            :         |           |%10.3f',dLISN_imlcac));   
disp(sprintf('dWTW_imlcac             :         |           |%10.3f',dWTW_imlcac));    
disp(sprintf('dWNW_imlcac             :         |           |%10.3f',dWNW_imlcac)); 

%disp(' ');
disp('                                           Initial responses ');
disp(sprintf('dZtime0_imlcac         :                |                 |%10.3f',dZtime0_imlcac));
disp(sprintf('dZTtime0_imlcac        :                |                 |%10.3f',dZTtime0_imlcac));
disp(sprintf('dZNtime0_imlcac        :                |                 |%10.3f',dZNtime0_imlcac));
disp(sprintf('dCYtime0_imlcac        :                |                 |%10.3f',dCYtime0_imlcac));
disp(sprintf('dLtime0_imlcac         :                |                 |%10.3f',dLtime0_imlcac));
disp(sprintf('dLTtime0_imlcac        :                |                 |%10.3f',dLTtime0_imlcac));
disp(sprintf('dLNtime0_imlcac        :                |                 |%10.3f',dLNtime0_imlcac));
disp(sprintf('dLTLNtime0_imlcac      :                |                 |%10.3f',dLTLNtime0_imlcac));
disp(sprintf('dYtime0_imlcac         :                |                 |%10.3f',dYtime0_imlcac));
disp(sprintf('dYtime0_check          :                |                 |%10.3f',dYtime0_check_imlcac));
disp(sprintf('dYRtime0_imlcac        :                |                 |%10.3f',dYRtime0_imlcac));
disp(sprintf('dYTtime0_imlcac        :                |                 |%10.3f',dYTtime0_imlcac));
disp(sprintf('dYNtime0_imlcac        :                |                 |%10.3f',dYNtime0_imlcac));
disp(sprintf('dYTYNtime0_imlcac      :                |                 |%10.3f',dYTYNtime0_imlcac));
disp(sprintf('dPtime0_imlcac         :                |                 |%10.3f',dPtime0_imlcac));
disp(sprintf('dSYtime0_imlcac        :                |                 |%10.3f',dSYtime0_imlcac));
disp(sprintf('dIYtime0_imlcac        :                |                 |%10.3f',dIYtime0_imlcac));
disp(sprintf('dCAYtime0_imlcac       :                |                 |%10.5f',dCAYtime0_imlcac)); 
disp(sprintf('dCAYtime0_imlcac_check :                |                 |%10.5f',dCAYtime0_imlcac_check)); 
disp(sprintf('dWtime0_imlcac         :                |                 |%10.3f',dWtime0_imlcac));
disp(sprintf('dWPCtime0_imlcac       :                |                 |%10.3f',dWPCtime0_imlcac));
disp(sprintf('dWTtime0_imlcac        :                |                 |%10.3f',dWTtime0_imlcac));
disp(sprintf('dWNtime0_imlcac        :                |                 |%10.3f',dWNtime0_imlcac));
disp(sprintf('dOmegatime0_imlcac     :                |                 |%10.3f',dOmegatime0_imlcac));
disp(sprintf('dWTPCtime0_imlcac      :                |                 |%10.3f',dWTPCtime0_imlcac));
disp(sprintf('dWNPCtime0_imlcac      :                |                 |%10.3f',dWNPCtime0_imlcac));
disp(sprintf('dPTtime0_imlcac        :                |                 |%10.3f',dPTtime0_imlcac));
disp(sprintf('dPNtime0_imlcac        :                |                 |%10.3f',dPNtime0_imlcac));
disp(sprintf('dkTKtime0_imlcac       :                |                 |%10.3f',dkTKtime0_imlcac));
disp(sprintf('dkNKtime0_imlcac       :                |                 |%10.3f',dkNKtime0_imlcac));
disp(sprintf('dLTStime0_imlcac       :                |                 |%10.3f',dLTStime0_imlcac));
disp(sprintf('dLNStime0_imlcac       :                |                 |%10.3f',dLNStime0_imlcac));
disp(sprintf('dYTStime0_imlcac       :                |                 |%10.3f',dYTStime0_imlcac));
disp(sprintf('dYNStime0_imlcac       :                |                 |%10.3f',dYNStime0_imlcac))
disp(sprintf('dLISTtime0_imlcac      :                |                 |%10.3f',dLISTtime0_imlcac));
disp(sprintf('dLISNtime0_imlcac      :                |                 |%10.3f',dLISNtime0_imlcac));
disp(sprintf('dWTWtime0_imlcac       :                |                 |%10.3f',dWTWtime0_imlcac));       
disp(sprintf('dWNWtime0_imlcac       :                |                 |%10.3f',dWNWtime0_imlcac));       
disp(sprintf('dLISTtime0_imlcac      :                |                 |%10.3f',dLISTtime0_imlcac));      
disp(sprintf('dLISNtime0_imlcac      :                |                 |%10.3f',dLISNtime0_imlcac));  

disp(' ');
disp('Steady State Equilibrium ratios (benchmark)');
disp(sprintf('kappa_cac  : %5.3f',kappa_cac));
disp(sprintf('YT / Y    :  %5.3f      P*YN / Y  : %5.3f',omegaYT_0,omegaYN_0));
disp(sprintf('LT / L    :  %5.3f      LN / L    : %5.3f',omegaLT_0,omegaLN_0));
disp(sprintf('PC*C / Y  :  %5.3f      NX  / Y   : %5.3f',omegaC_0,omegaNX_0));
disp(sprintf('P*I / Y   :  %5.3f      G / Y     : %5.3f',omegaI_0,omegaG_0));
disp(' ');
disp(sprintf('GT / YT   :  %5.3f  GN / YN  : %5.3f  (P*GN)/G  : %5.3f',omegaGTYT_0,omegaGNYN_0,omegaGN_0));
disp(sprintf('IN / YN   :  %5.3f  IT / YT  :  %5.3f  (r*B)/Y  : %5.3f',omegaINYN_0,omegaITYT_0,omegaB_0));
disp(sprintf('WN*LN/W*L :  %5.3f RN*KN/R*K :  %5.3f',alphaL_0,alphaK_0));
disp(sprintf('P*IN/PI*I :  %5.3f P*CN/PC*C :  %5.3f',alphaI_0,alphaC_0));
disp(sprintf('W*L/P*Y   :  %5.3f R*K/P*Y   :  %5.3f',omegaL_0,omegaK_0));
disp(sprintf('K/Y       :  %5.3f',omegaKY_0));
